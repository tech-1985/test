package com.ford.gpcse.bo;

public record ReleaseStatusDetails(String statusDescription, String statusValue) {
}
