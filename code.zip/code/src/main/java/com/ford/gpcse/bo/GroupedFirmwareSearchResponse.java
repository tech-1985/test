package com.ford.gpcse.bo;

import java.util.List;

public record GroupedFirmwareSearchResponse(String releaseType, String releaseUsage, String concern,
                                            String wersConcernDescription, List<FirmwareResponse> firmwareResponses) {
}
