package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.Email;
import com.ford.gpcse.bo.SupplierEnrollmentRequest;
import com.ford.gpcse.exception.UnableToSendEmailNotification;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.service.EnrollmentService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.StringJoiner;

/**
 * Implementation of the EnrollmentService interface. This service handles
 * supplier enrollment requests, primarily by sending emails.
 */
@Service
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EmailService emailService;

    public EnrollmentServiceImpl(EmailService emailService) {
        super();
        this.emailService = emailService;
    }

    /**
     * Handles the supplier enrollment process.
     *
     * @param supplierEnrollmentRequest the request containing supplier enrollment
     *                                  details
     * @return a message indicating the status of the enrollment
     * @throws UnableToSendEmailNotification if there is an error sending the email
     */
    @Override
    public String supplierEnrollment(SupplierEnrollmentRequest supplierEnrollmentRequest) {
        if (sendSupplierEnrollmentEmail(supplierEnrollmentRequest)) {
            return "Your request has been submitted.";
        } else {
            throw new UnableToSendEmailNotification("Your request not submitted due to SMTP failure");
        }
    }

    /**
     * Constructs and sends the supplier enrollment email.
     *
     * @param supplierEnrollmentRequest the request containing supplier details
     * @return true if the email was sent successfully, false otherwise
     */
    private boolean sendSupplierEnrollmentEmail(SupplierEnrollmentRequest supplierEnrollmentRequest) {
        StringJoiner emailBodyJoiner = new StringJoiner("", "<HTML><HEAD></HEAD><BODY>", "</BODY></HTML>");
        emailBodyJoiner.add("<P>User ID: " + supplierEnrollmentRequest.userId() + "</P>")
                .add("<P>First Name: " + supplierEnrollmentRequest.firstName() + "</P>")
                .add("<P>Last Name: " + supplierEnrollmentRequest.lastName() + "</P>")
                .add("<P>Email Address: " + supplierEnrollmentRequest.emailAddress() + "</P>")
                .add("<P>Comments: " + supplierEnrollmentRequest.comments() + "</P>");

        String emailBody = emailBodyJoiner.toString();

        return emailService.sendMail(new Email(List.of(""), // To Email
                "Firmware User", emailBody, "" // From Email
        ));
    }

}
