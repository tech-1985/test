package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.*;
import com.ford.gpcse.common.Constants;
import com.ford.gpcse.dto.*;
import com.ford.gpcse.entity.*;
import com.ford.gpcse.exception.ProgramSearchLimitExceedException;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.repository.*;
import com.ford.gpcse.service.SearchDataService;
import com.ford.gpcse.util.DateFormatterUtility;
import com.ford.gpcse.util.NoticeFormatterUtility;
import jakarta.persistence.criteria.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SearchDataServiceImpl implements SearchDataService {

    private static final String NO_PARTS_FOUND = "No Parts to display";
    private static final String MODULE_TYPE = "moduleType";
    private static final String MODULE_TYP_C = "moduleTypC";
    private static final String NEW_PN_REQUEST = "NewPnRequest";
    private static final String N_A = "N/A";
    private static final String TBD = "TBD";
    private static final String[] TABLE_HEADER = {"LINEAGE", "OLD CAL", "OLD PN---", "OLD CW", "NEW CAL", "NEW PN---",
            "NEW CW"};
    private final PartRepository partRepository;
    private final ReleaseRequestRepository releaseRequestRepository;
    private final PartFirmwareRepository partFirmwareRepository;
    private final ProgramDescriptionRepository programDescriptionRepository;
    private final ProgramPartRepository programPartRepository;
    private final SignoffRepository signoffRepository;
    private final FirmwareRepository firmwareRepository;

    public SearchDataServiceImpl(PartRepository partRepository, ReleaseRequestRepository releaseRequestRepository,
                                 PartFirmwareRepository partFirmwareRepository, ProgramDescriptionRepository programDescriptionRepository,
                                 ProgramPartRepository programPartRepository, SignoffRepository signoffRepository,
                                 FirmwareRepository firmwareRepository) {
        super();
        this.partRepository = partRepository;
        this.releaseRequestRepository = releaseRequestRepository;
        this.partFirmwareRepository = partFirmwareRepository;
        this.programDescriptionRepository = programDescriptionRepository;
        this.programPartRepository = programPartRepository;
        this.signoffRepository = signoffRepository;
        this.firmwareRepository = firmwareRepository;
    }

    public static String getStatusDescription(String statC) {
        return switch (statC) {
            case "" -> "";
            case NEW_PN_REQUEST -> "New Part Number Request";
            case "PeadEdit", "PeadComplete" -> "Module Base Info Edit";
            case "FirmwareEdit" -> "Firmware Edit";
            case "SoftLock" -> "Soft Lock";
            case "HardLock" -> "Hard Lock";
            case "Complete" -> "Release Complete";
            default -> statC;
        };
    }

    @Override
    @Transactional(readOnly = true)
    public List<GroupedFirmwareSearchResponse> fetchFirmwareDetailsByWersConcern(String wersConcern) {
        var optionalFirmwares = partRepository.fetchFirmwareDetailsByWersConcern(wersConcern);
        if (optionalFirmwares.isEmpty()) {
            throw new ResourceNotFoundException("No Release was found. Please try again.");
        } else {
            return groupFirmwareResponses(convertToFirmwareResponse(optionalFirmwares.get()));
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<GroupedFirmwareSearchResponse> fetchFirmwareDetailsByWersNotice(String wersNotice) {
        var optionalFirmwares = partRepository
                .fetchFirmwareDetailsByWersNotice(NoticeFormatterUtility.formatWersNotice(wersNotice));
        if (optionalFirmwares.isEmpty()) {
            throw new ResourceNotFoundException("No Release was found.  Please try again.");
        } else {
            return groupFirmwareResponses(convertToFirmwareResponse(optionalFirmwares.get()));
        }
    }

    public List<GroupedFirmwareSearchResponse> groupFirmwareResponses(List<FirmwareResponse> firmwareResponses) {
        return firmwareResponses.stream()
                .collect(Collectors.groupingBy(firmwareResponse -> Arrays.asList(firmwareResponse.releaseType(),
                        firmwareResponse.releaseUsage(), firmwareResponse.concern(),
                        firmwareResponse.wersConcernDescription())))
                .entrySet().stream().map(entry -> {
                    List<FirmwareResponse> groupedResponses = entry.getValue();
                    return new GroupedFirmwareSearchResponse(entry.getKey().get(0), entry.getKey().get(1),
                            entry.getKey().get(2), entry.getKey().get(3), groupedResponses);
                }).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<FirmwareResponse> fetchFirmwareDetailsByPrograms(List<Long> programKeys) {
        if (programKeys.size() >= 10) {
            throw new ProgramSearchLimitExceedException("Please select less than 10 programs.");
        }
        var optionalFirmwares = partRepository.fetchFirmwareDetailsByPrograms(programKeys);
        if (optionalFirmwares.isEmpty()) {
            throw new ResourceNotFoundException("No Programs");
        } else {
            return convertToFirmwareResponse(optionalFirmwares.get());
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(
            PartNumberSearchRequest partNumberSearchRequest) {
        var spec = byCriteriaForPartNumber(partNumberSearchRequest);
        List<Part> parts = partRepository.findAll(spec, PageRequest.of(0, 499)).getContent();
        if (parts.isEmpty()) {
            throw new ResourceNotFoundException(NO_PARTS_FOUND);
        }
        Map<String, List<PartDetail>> groupedByConcernNumber = parts.stream()
                .map(part -> new PartDetail(part.getPartR(), part.getHardwarePartR(), part.getSupplier().getSuplX(),
                        part.getCatchWordC(), part.getCalibR(), part.getStatC(),
                        DateFormatterUtility.dateTimeStringConcern(part.getConcernY()),
                        part.getReleaseType().getRelTypC(), part.getReleaseUsage().getRelUsgC(), part.getCmtX(),
                        part.getConcernC(), part.getSwDlSpecR(), part.getProcCmtX(), part.getBldLvlC(), part.getPrtyC(),
                        part.getPrtyDtlX()))
                .collect(Collectors.groupingBy(PartDetail::concernNumber));

        return groupedByConcernNumber.entrySet().stream().sorted(Map.Entry.comparingByKey())
                .map(entry -> new PartNumberSearchResponse(entry.getKey(), entry.getValue())).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public String fetchWersTextByConcern(String wersConcern) {
        var optionalPartNumbers = partRepository.fetchPartNumbersByConcern(wersConcern);

        if (optionalPartNumbers.isEmpty()) {
            throw new ResourceNotFoundException(NO_PARTS_FOUND);
        }
        var partNumbers = optionalPartNumbers.get();
        var partsData = partRepository.fetchParts(partNumbers);
        var partProgramsMap = mapPartToPrograms(partNumbers);
        var wersTextPartDtos = mapPartsDataToDtos(partsData, partProgramsMap);
        var wersTextPartDescriptionDtos = programDescriptionRepository.fetchPartsWithProgramDescription(partNumbers);
        var wersTextPartCalibDtos = partRepository.fetchPartsWithCalib(partNumbers);
        return buildWersText(wersTextPartDtos, wersTextPartDescriptionDtos, wersTextPartCalibDtos);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReleaseStatusConcernResponse> fetchReleaseStatusDetailsByWersConcern(String wersConcern) {
        var optionalReleaseStatusConcerns = partRepository.fetchReleaseStatusDetailsByWersConcern(wersConcern);
        if (optionalReleaseStatusConcerns.isEmpty()) {
            throw new ResourceNotFoundException("No Records were found.");
        } else {
            var releaseStatusConcerns = optionalReleaseStatusConcerns.get();

            return releaseStatusConcerns.stream().map(releaseStatusConcern -> new ReleaseStatusConcernResponse(
                            releaseStatusConcern.partR(), releaseStatusConcern.calibR(), releaseStatusConcern.engineerCdsidC(),
                            releaseStatusConcern.hardwarePartR(), releaseStatusConcern.coreHardwarePartR(),
                            releaseStatusConcern.microTypX(), releaseStatusConcern.stratCalibPartR(),
                            releaseStatusConcern.stratRelC(), releaseStatusConcern.chipD(),
                            programDescriptionRepository.fetchProgramDescriptionByPartNumber(releaseStatusConcern.partR()),
                            releaseStatusConcern.partNumX(), new ReleaseStatusDetails(
                            getStatusDescription(releaseStatusConcern.statC()), getStatusValue(releaseStatusConcern))))
                    .toList();

        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductionPartNumberSearchResponse> fetchProductionPartNumber(
            ProductionPartNumberSearchRequest productionPartNumberSearchRequest) {
        var pageable = PageRequest.of(0, 500);
        var parts = partRepository
                .findAll(buildFindProductionPartNumberSpecification(productionPartNumberSearchRequest), pageable)
                .getContent();
        if (parts.isEmpty()) {
            throw new ResourceNotFoundException(NO_PARTS_FOUND);
        }
        return parts.stream()
                .map(part -> new ProductionPartNumberSearchResponse(part.getPartR(), part.getCatchWordC(),
                        part.getCalibR(), part.getStratCalibPartR(), part.getHardwarePartR(),
                        part.getMicroType() != null ? part.getMicroType().getMicroTypX() : "", part.getWersNtcR()))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReleaseRequestOutput> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput) {
        var releaseRequests = releaseRequestRepository
                .findAll(findByCriteriaForReleaseRequests(releaseRequestSearchInput));
        if (releaseRequests.isEmpty()) {
            throw new ResourceNotFoundException("No Release Requests");
        }
        return releaseRequests.stream().map(releaseRequest -> new ReleaseRequestOutput(releaseRequest.getRelReqK(),
                releaseRequest.getModuleType().getModuleTypC(), releaseRequest.getCalRLevelR(),
                releaseRequest.getProgramReleaseRequests() != null
                        && !releaseRequest.getProgramReleaseRequests().isEmpty()
                        ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getMdlYrR()
                        : null,
                releaseRequest.getProgramReleaseRequests() != null
                        && !releaseRequest.getProgramReleaseRequests().isEmpty()
                        ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getPgmN()
                        : null,
                releaseRequest.getProgramReleaseRequests() != null
                        && !releaseRequest.getProgramReleaseRequests().isEmpty()
                        ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getEngN()
                        : null,
                releaseRequest.getStatusC(),
                releaseRequest.getCreateS().format(DateTimeFormatter.ofPattern("MMM dd, yyyy")),
                releaseRequest.getCreateUserC())).toList();
    }

    public String getStatusValue(ReleaseStatusConcernDto releaseStatusConcernDto) {
        return switch (releaseStatusConcernDto.statC()) {
            case "PeadEdit" -> "<li>Waiting for Edit Module Base.</li>";
            case "PeadComplete" -> fetchPeadCompleteStatusValue(releaseStatusConcernDto.partR());
            case "FirmwareEdit" ->
                    fetchFirmwareEditStatusValue(releaseStatusConcernDto.partR(), releaseStatusConcernDto.suplC(),
                            releaseStatusConcernDto.relTypC(), releaseStatusConcernDto.stratRelC());
            case "SoftLock" ->
                    fetchSoftLockStatusValue(releaseStatusConcernDto.partR(), releaseStatusConcernDto.suplC());
            case "HardLock" ->
                    fetchHardLockStatusValue(releaseStatusConcernDto.partR(), releaseStatusConcernDto.suplC());
            default -> "";
        };

    }

    private String fetchHardLockStatusValue(String partR, String suplC) {
        var signoffProcessText = signoffProcess(partR, "Waiting for Hard Lock Process",
                List.of("VBFUL", "DCUUL", "P2LOC", "SWWER", "SWBLD", "PRDWL", "PRBLD", "SWAPR", "SWDRW", "SRPUL",
                        "IVSSB", "IVSAB", "TELGR", "IVSSA", "IVSAA", "EOLPT", "EOLVO"),
                suplC);
        if (signoffProcessText.isEmpty()) {
            return "<li>Waiting for other parts to complete.</li>";
        } else {
            return signoffProcessText;
        }
    }

    private String fetchSoftLockStatusValue(String partR, String suplC) {
        var signoffProcessText = signoffProcess(partR, "Waiting for Review Process",
                List.of("SUPPR", "PEERR", "PEERA", "HWPER", "IVSEM"), suplC);
        if (signoffProcessText.isEmpty()) {
            return "<li>Waiting for Hard Lock.</li>";
        } else {
            return signoffProcessText;
        }
    }

    private String signoffProcess(String partR, String displayText, List<String> signOffTypes, String suplC) {
        var optionalSignoffDetails = signoffRepository.findSignoffDetails(partR, signOffTypes);

        if (optionalSignoffDetails.isEmpty()) {
            return "";
        }

        var signoffDetails = optionalSignoffDetails.get();

        var strHtm = new StringBuilder();
        strHtm.append("<li>").append(displayText).append("<ul>");

        for (Object[] detail : signoffDetails) {
            String signoffTypeX = getDetailAsString(detail[0]);
            String signoffTypeC = getDetailAsString(detail[1]);
            String runTimeInMin = getDetailAsString(detail[2]);

            if (isAutomationSignoff(signoffTypeX)) {
                appendAutomationSignoffHtml(strHtm, signoffTypeX, runTimeInMin);
            } else {
                appendSignoffHtmlWithLink(strHtm, partR, signoffTypeC, suplC, signoffTypeX);
            }
        }

        strHtm.append("</ul></li>");

        return strHtm.toString();
    }

    private String getDetailAsString(Object detail) {
        return detail != null ? detail.toString() : "";
    }

    private boolean isAutomationSignoff(String signoffType) {
        return signoffType.toLowerCase().contains("automation");
    }

    private void appendAutomationSignoffHtml(StringBuilder strHtm, String signoffTypeX, String runTimeInMin) {
        strHtm.append("<li>").append(signoffTypeX).append("</li>\n");
        strHtm.append("<li>Running for ").append(runTimeInMin).append(" minutes</li>\n");
    }

    private void appendSignoffHtmlWithLink(StringBuilder strHtm, String partR, String signoffTypeC, String suplC,
                                           String signoffTypeX) {
        strHtm.append("<li><a href=\"#\" onclick=\"OpenSignoffLookupForm('").append(partR).append("','")
                .append(signoffTypeC).append("','").append(suplC).append("'); return false;\">").append(signoffTypeX)
                .append("</a></li>\n");
    }

    private String fetchFirmwareEditStatusValue(String partR, String suplC, String relTypC, String stratRelC) {
        var strHtm = new StringBuilder();
        fetchFirmwareHtm(partR, suplC, strHtm);
        strHtm.append(signoffProcess(partR, "Waiting for Calibration Review",
                List.of("CALUP", "CLSUP", "CLOBD", "SUDEP", "CLDEP", "PCDEP", "SUDEV", "CLDEV", "PCDEV"), suplC));
        strHtm.append(signoffProcess(partR, "Waiting for WERS Peer Review", List.of("PEERW"), suplC));

        if (strHtm.isEmpty()) {
            if (relTypC.equals("AFD") || relTypC.equals("AREUL") || relTypC.equals("PSUPR") || relTypC.equals("RC")
                    || relTypC.equals("PROT") || stratRelC.isEmpty() || stratRelC.length() > 5) {
                var countByPartRHasReviewSignOff = partFirmwareRepository.countByPartRHasReviewSignOff(partR);
                if (countByPartRHasReviewSignOff > 0) {
                    return "<li>Waiting to Send for Soft Lock.</li>";
                } else {
                    return "<li>Waiting to Send for Hard Lock.</li>";
                }
            } else {
                return "<li>Waiting for CFX Release or CART Sign-off.</li>";
            }
        } else {
            return strHtm.toString();
        }
    }

    private void fetchFirmwareHtm(String partR, String suplC, StringBuilder strHtm) {

        var optionalFirmwareDetails = firmwareRepository.findFirmwareDetails(partR);

        if (optionalFirmwareDetails.isEmpty()) {
            strHtm.setLength(0);
        } else {
            var firmwareDetails = optionalFirmwareDetails.get();
            strHtm.append("<li>Waiting for Firmware");
            strHtm.append("<ul>");

            for (Object[] detail : firmwareDetails) {
                var firmwareK = detail[1] != null ? detail[1].toString() : "";
                var firmwareN = detail[0] != null ? detail[0].toString() : "";
                strHtm.append("<li><a href=\"#\" onclick=\"OpenFirmwareLookupForm('").append(partR).append("','")
                        .append(firmwareK).append("','").append(suplC).append("'); return false;\">").append(firmwareN)
                        .append("</a></li>");
            }
            strHtm.append("</ul></li>");
        }
    }

    private String fetchPeadCompleteStatusValue(String partR) {
        var countByPartR = partFirmwareRepository.countByPartR(partR);
        var countByPartRHasReviewSignOff = partFirmwareRepository.countByPartRHasReviewSignOff(partR);
        if (countByPartR > 0) {
            return "<li>Waiting to send for Firmware.</li>";
        } else if (countByPartRHasReviewSignOff > 0) {
            return "<li>Waiting to send for Soft Lock.</li>";
        } else {
            return "<li>Waiting to send for Hard Lock.</li>";
        }
    }

    private Specification<Part> buildFindProductionPartNumberSpecification(
            ProductionPartNumberSearchRequest productionPartNumberSearchRequest) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            addDynamicFilter(predicates, cb, root.get(Constants.PART_R),
                    productionPartNumberSearchRequest.partNumber());
            addDynamicFilter(predicates, cb, root.get("stratCalibPartR"),
                    productionPartNumberSearchRequest.softwarePartNumber());
            addDynamicFilter(predicates, cb, root.get("catchWordC"), productionPartNumberSearchRequest.catchWord());
            addDynamicFilter(predicates, cb, root.get("calibR"), productionPartNumberSearchRequest.calibrationNumber());
            addDynamicFilter(predicates, cb, root.get("wersNtcR"),
                    NoticeFormatterUtility.wersNoticeFormatDatabase(productionPartNumberSearchRequest.wersNotice()));
            addDynamicFilter(predicates, cb, root.get("stratRelC"), productionPartNumberSearchRequest.stratRelName());
            addDynamicFilter(predicates, cb, root.get("chipD"), productionPartNumberSearchRequest.chipId());
            predicates.add(cb.equal(root.get("archF"), "N"));
            predicates.add(cb.isNotNull(root.get(MODULE_TYPE).get(MODULE_TYP_C)));
            predicates.add(cb.isNotNull(root.get("releaseType").get("relTypC")));
            Predicate finalPredicate = cb.and(predicates.toArray(new Predicate[0]));
            if (query != null) {
                Join<Object, Object> microTypeJoin = root.join("microType", JoinType.LEFT);
                query.orderBy(cb.asc(microTypeJoin.get("microTypX")), cb.asc(root.get("hardwarePartR")),
                        cb.asc(root.get(Constants.PART_R)));
            }

            return finalPredicate;
        };
    }

    private void addDynamicFilter(List<Predicate> predicates, CriteriaBuilder cb, Path<String> field, String value) {
        if (value != null && !value.isEmpty()) {
            predicates.add(cb.like(cb.upper(field), "%" + value.toUpperCase() + "%"));
        }
    }

    private Specification<Part> byCriteriaForPartNumber(PartNumberSearchRequest request) {
        return (Root<Part> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
            var predicate = cb.conjunction();

            predicate = addPredicate(predicate, cb, cb.equal(root.get("archF"), "N"));
            predicate = addPredicate(predicate, cb, cb.notEqual(root.get("statC"), NEW_PN_REQUEST));

            Join<Part, ReleaseType> releaseTypeJoin = root.join("releaseType", JoinType.INNER);
            Join<Part, ModuleType> moduleTypeJoin = root.join(MODULE_TYPE, JoinType.INNER);
            Join<Part, RelUsg> releaseUsageJoin = root.join("releaseUsage", JoinType.INNER);

            predicate = addReleaseTypeFilter(predicate, cb, releaseTypeJoin, request.releaseTypes());
            predicate = addModuleTypeFilter(predicate, cb, moduleTypeJoin, request.moduleType());
            predicate = addReleaseUsageFilter(predicate, cb, releaseUsageJoin, request.releaseUsage());

            predicate = addStringFilter(predicate, cb, root.get(Constants.PART_R), request.assemblyPN());
            predicate = addStringFilter(predicate, cb, root.get("hardwarePartR"), request.hardwarePN());
            predicate = addStringFilter(predicate, cb, root.get("swDlSpecR"), request.softwarePN());
            predicate = addStringFilter(predicate, cb, root.get("engineerCdsidC"), request.appEng());
            predicate = addStringFilter(predicate, cb, root.get("catchWordC"), request.catchWord());
            predicate = addStringFilter(predicate, cb, root.get("calibR"), request.calibrationNum());
            predicate = addStringFilter(predicate, cb, root.get("stratRelC"), request.mainStrategy());
            predicate = addStringFilter(predicate, cb, root.get("concernC"), request.concernNumber());

            predicate = addDateFilter(predicate, cb, root, "createS", request.createdDateFrom(),
                    request.createdDateTo());
            predicate = addDateFilter(predicate, cb, root, "reldY", request.releasedDateFrom(),
                    request.releasedDateTo());

            if (query != null) {
                query.orderBy(cb.asc(root.get("concernC")), cb.asc(root.get(Constants.PART_R)));
            }

            return predicate;
        };
    }

    private Predicate addPredicate(Predicate predicate, CriteriaBuilder cb, Predicate condition) {
        return condition != null ? cb.and(predicate, condition) : predicate;
    }

    private Predicate addReleaseTypeFilter(Predicate predicate, CriteriaBuilder cb,
                                           Join<Part, ReleaseType> releaseTypeJoin, List<String> releaseTypes) {
        if (releaseTypes != null && !releaseTypes.isEmpty() && !releaseTypes.contains("All")) {
            return addPredicate(predicate, cb, releaseTypeJoin.get("relTypX").in(releaseTypes));
        }
        return predicate;
    }

    private Predicate addModuleTypeFilter(Predicate predicate, CriteriaBuilder cb,
                                          Join<Part, ModuleType> moduleTypeJoin, String moduleType) {
        if (moduleType != null && !moduleType.isEmpty()) {
            return addPredicate(predicate, cb, cb.equal(moduleTypeJoin.get(MODULE_TYP_C), moduleType));
        }
        return predicate;
    }

    private Predicate addReleaseUsageFilter(Predicate predicate, CriteriaBuilder cb,
                                            Join<Part, RelUsg> releaseUsageJoin, String releaseUsage) {
        if (releaseUsage != null && !releaseUsage.isEmpty() && !releaseUsage.equals("All")) {
            return addPredicate(predicate, cb, cb.equal(releaseUsageJoin.get("relUsgX"), releaseUsage));
        }
        return predicate;
    }

    private Predicate addStringFilter(Predicate predicate, CriteriaBuilder cb, Path<String> path, String value) {
        if (value != null && !value.isEmpty()) {
            return addPredicate(predicate, cb, cb.like(path, "%" + value + "%"));
        }
        return predicate;
    }

    private Predicate addDateFilter(Predicate predicate, CriteriaBuilder cb, Root<Part> root, String field,
                                    String dateFrom, String dateTo) {
        if (dateFrom != null && !dateFrom.isEmpty()) {
            LocalDateTime fromDate = LocalDateTime.of(LocalDate.parse(dateFrom), LocalTime.MIN);
            predicate = cb.and(predicate, cb.greaterThanOrEqualTo(root.get(field), fromDate));
        }
        if (dateTo != null && !dateTo.isEmpty()) {
            LocalDateTime toDate = LocalDateTime.of(LocalDate.parse(dateTo), LocalTime.MAX);
            predicate = cb.and(predicate, cb.lessThanOrEqualTo(root.get(field), toDate));
        }
        return predicate;
    }

    private Specification<ReleaseRequest> findByCriteriaForReleaseRequests(
            ReleaseRequestSearchInput releaseRequestSearchInput) {
        return (Root<ReleaseRequest> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            var predicate = criteriaBuilder.conjunction();
            predicate = applyIdFilter(root, criteriaBuilder, predicate, releaseRequestSearchInput.id());
            predicate = applyModuleTypeCodeFilter(root, criteriaBuilder, predicate,
                    releaseRequestSearchInput.moduleTypeCode());
            predicate = applyCalibrationLevelFilter(root, criteriaBuilder, predicate,
                    releaseRequestSearchInput.calibrationLevel());
            predicate = applyStatusFilter(root, criteriaBuilder, predicate, releaseRequestSearchInput.status());
            predicate = applyOwnerFilter(root, criteriaBuilder, predicate, releaseRequestSearchInput.owner());
            predicate = applyModelYearProgramEngineFilter(root, query, criteriaBuilder, predicate,
                    releaseRequestSearchInput);
            return predicate;
        };
    }

    private Predicate applyIdFilter(Root<ReleaseRequest> root, CriteriaBuilder criteriaBuilder, Predicate predicate,
                                    Long id) {
        if (id != -1) {
            predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get(Constants.REL_REQ_K), id));
        }
        return predicate;
    }

    private Predicate applyModuleTypeCodeFilter(Root<ReleaseRequest> root, CriteriaBuilder criteriaBuilder,
                                                Predicate predicate, String moduleTypeCode) {
        if (StringUtils.isNotBlank(moduleTypeCode)) {
            predicate = criteriaBuilder.and(predicate,
                    criteriaBuilder.like(root.get(MODULE_TYPE).get(MODULE_TYP_C), "%" + moduleTypeCode + "%"));
        }
        return predicate;
    }

    private Predicate applyCalibrationLevelFilter(Root<ReleaseRequest> root, CriteriaBuilder criteriaBuilder,
                                                  Predicate predicate, String calibrationLevel) {
        if (StringUtils.isNotBlank(calibrationLevel)) {
            predicate = criteriaBuilder.and(predicate,
                    criteriaBuilder.like(root.get("calRLevelR"), "%" + calibrationLevel + "%"));
        }
        return predicate;
    }

    private Predicate applyStatusFilter(Root<ReleaseRequest> root, CriteriaBuilder criteriaBuilder, Predicate predicate,
                                        String status) {
        if (StringUtils.isNotBlank(status)) {
            predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(root.get("statusC"), "%" + status + "%"));
        }
        return predicate;
    }

    private Predicate applyOwnerFilter(Root<ReleaseRequest> root, CriteriaBuilder criteriaBuilder, Predicate predicate,
                                       String owner) {
        if (StringUtils.isNotBlank(owner)) {
            predicate = criteriaBuilder.and(predicate,
                    criteriaBuilder.like(root.get("createUserC"), "%" + owner + "%"));
        }
        return predicate;
    }

    private Predicate applyModelYearProgramEngineFilter(Root<ReleaseRequest> root, CriteriaQuery<?> query,
                                                        CriteriaBuilder criteriaBuilder, Predicate predicate, ReleaseRequestSearchInput releaseRequestSearchInput) {
        String modelYear = releaseRequestSearchInput.modelYear();
        String program = releaseRequestSearchInput.program();
        String engine = releaseRequestSearchInput.engine();

        if (StringUtils.isNotBlank(modelYear) || StringUtils.isNotBlank(program) || StringUtils.isNotBlank(engine)) {
            var subquery = createPgmReleaseRequestSubquery(query, criteriaBuilder, modelYear, program, engine);
            predicate = criteriaBuilder.and(predicate, root.get(Constants.REL_REQ_K).in(subquery));
        }
        return predicate;
    }

    private Subquery<Long> createPgmReleaseRequestSubquery(CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder,
                                                           String modelYear, String program, String engine) {
        var subquery = query.subquery(Long.class);
        var subRoot = subquery.from(PgmReleaseRequest.class);
        subquery.select(subRoot.get("releaseRequest").get(Constants.REL_REQ_K));
        var join = subRoot.join("programDescription");
        var subPredicate = criteriaBuilder.conjunction();
        if (StringUtils.isNotBlank(modelYear)) {
            subPredicate = criteriaBuilder.and(subPredicate,
                    criteriaBuilder.like(join.get("mdlYrR"), "%" + modelYear + "%"));
        }
        if (StringUtils.isNotBlank(program)) {
            subPredicate = criteriaBuilder.and(subPredicate,
                    criteriaBuilder.like(join.get("pgmN"), "%" + program + "%"));
        }
        if (StringUtils.isNotBlank(engine)) {
            subPredicate = criteriaBuilder.and(subPredicate,
                    criteriaBuilder.like(join.get("engN"), "%" + engine + "%"));
        }
        subquery.where(subPredicate);
        return subquery;
    }

    private List<FirmwareResponse> convertToFirmwareResponse(List<FirmwareDto> firmwareDtos) {
        return firmwareDtos.stream()
                .map(firmwareDto -> new FirmwareResponse(firmwareDto.partR(), firmwareDto.calibR(),
                        firmwareDto.catchWordC(), firmwareDto.engineerCdsidC(),
                        NoticeFormatterUtility.formatWersNotice(firmwareDto.wersNtcR()), firmwareDto.relUsgX(),
                        firmwareDto.hardwarePartR(), firmwareDto.coreHardwarePartR(), firmwareDto.microTypX(),
                        firmwareDto.suplX(), firmwareDto.coreHardwareCdsidC(), firmwareDto.stratCalibPartR(),
                        firmwareDto.stratRelC(), firmwareDto.chipD(), firmwareDto.pwrtrnCalibCdsidC(),
                        programDescriptionRepository.fetchProgramDescriptionByPartNumber(firmwareDto.partR()),
                        firmwareDto.partNumX(),
                        groupFirmwares(partFirmwareRepository.fetchPartFirmwareByPartNumber(firmwareDto.partR())),
                        firmwareDto.relTypX(), firmwareDto.concernC(), firmwareDto.cmtX()))
                .toList();
    }

    private List<GroupedFirmwareResponse> groupFirmwares(List<LookupPartFirmwareDto> firmwares) {
        var grouped = firmwares.stream().collect(Collectors.groupingBy(LookupPartFirmwareDto::firmwareCatgN));

        return grouped.entrySet().stream().map(entry -> new GroupedFirmwareResponse(entry.getKey(), entry.getValue()))
                .toList();
    }

    private Map<String, String> mapPartToPrograms(List<String> partNumbers) {
        var partProgramsMap = new HashMap<String, String>();
        var programParts = programPartRepository.findByPart_PartRIn(partNumbers);
        for (ProgramPart programPart : programParts) {
            partProgramsMap.compute(programPart.getPart().getPartR(),
                    (key, existing) -> (existing == null ? "" : existing + ", ") + programPart.getPgmK());
        }
        return partProgramsMap;
    }

    private List<WersTextPartDto> mapPartsDataToDtos(List<Object[]> partsData, Map<String, String> partProgramsMap) {
        var wersTextPartDtos = new ArrayList<WersTextPartDto>();

        for (Object[] partData : partsData) {
            var partR = (String) partData[0];
            var relTypeC = (String) partData[1];
            var backwardCompatC = (String) partData[2];
            var hardwarePartR = (String) partData[3];
            var releaseUsageC = (String) partData[4];
            var programs = partProgramsMap.getOrDefault(partR, "");
            wersTextPartDtos
                    .add(new WersTextPartDto(partR, relTypeC, backwardCompatC, hardwarePartR, releaseUsageC, programs));
        }

        return wersTextPartDtos;
    }

    private String buildWersText(List<WersTextPartDto> wersTextPartDtos,
                                 List<WersTextPartDescriptionDto> wersTextPartDescriptionDtos,
                                 List<WersTextPartCalibDto> wersTextPartCalibDtos) {

        var strText = new StringBuilder();
        for (WersTextPartDto partDto : wersTextPartDtos) {
            appendProgramsToText(strText, partDto);
            appendPartDetailsToText(strText, partDto);
            appendPartDescriptionTableToText(strText, wersTextPartDescriptionDtos);
        }
        strText.append(generateLineageTable(wersTextPartCalibDtos)).append("<br>");
        return strText.toString();
    }

    private void appendProgramsToText(StringBuilder strText, WersTextPartDto partDto) {
        var programs = partDto.programs();
        if (programs != null && !programs.isEmpty()) {
            strText.append(programs).append("<br>");
        }
    }

    private void appendPartDetailsToText(StringBuilder strText, WersTextPartDto partDto) {
        strText.append(wordWrap(getDisplayValue(partDto.relTypeC()) + " - " + getDisplayValue(partDto.releaseUsageC()),
                79, "<br>")).append("<br>");
        strText.append(wordWrap(getDisplayValue(partDto.backwardCompatC()), 79, "<br>")).append("<br>");
        strText.append("HARDWARE: ").append(partDto.hardwarePartR()).append("<br>");
        strText.append("RELATED MODULES:<br>");
    }

    private void appendPartDescriptionTableToText(StringBuilder strText,
                                                  List<WersTextPartDescriptionDto> wersTextPartDescriptionDtos) {
        strText.append(wersTable(wersTextPartDescriptionDtos)).append("<br>");
    }

    private String wersTable(List<WersTextPartDescriptionDto> descriptions) {
        var strHtm = new StringBuilder();
        var tableRows = new ArrayList<String[]>();
        for (WersTextPartDescriptionDto desc : descriptions) {
            tableRows.add(new String[]{String.valueOf(desc.pgmK()), desc.mdlYrR(), desc.pgmN(), desc.platN(),
                    desc.engN(), desc.transN()});
        }
        for (String[] row : tableRows) {
            for (String cell : row) {
                strHtm.append(cell).append("  ");
            }
            strHtm.setLength(strHtm.length() - 2);
            strHtm.append("<br>");
        }
        return strHtm.toString();
    }

    private String generateLineageTable(List<WersTextPartCalibDto> parts) {
        StringBuilder htmlOutput = new StringBuilder();

        String[][] tableData = new String[parts.size() + 1][TABLE_HEADER.length];

        System.arraycopy(TABLE_HEADER, 0, tableData[0], 0, TABLE_HEADER.length);

        for (int i = 0; i < parts.size(); i++) {
            WersTextPartCalibDto part = parts.get(i);

            tableData[i + 1][0] = part.partNumX();

            tableData[i + 1][1] = getValidValue(part.oldCal());

            tableData[i + 1][2] = getValidValue(part.replacedPartR());

            tableData[i + 1][3] = getValidValue(part.oldCw());

            tableData[i + 1][4] = getValidValue(part.calibR());

            if (NEW_PN_REQUEST.equals(part.statC())) {
                tableData[i + 1][5] = TBD;
                tableData[i + 1][6] = TBD;
            } else {
                tableData[i + 1][5] = getValidValue(part.partR());
                tableData[i + 1][6] = getValidValue(part.catchwordC());
            }
        }

        for (String[] row : tableData) {
            StringJoiner rowJoiner = new StringJoiner("  ");
            for (String cell : row) {
                rowJoiner.add(cell);
            }
            htmlOutput.append(rowJoiner.toString()).append("<br>");
        }

        return htmlOutput.toString();
    }

    private String getValidValue(String value) {
        return (value == null || value.isEmpty()) ? N_A : value;
    }

    private String getDisplayValue(String code) {
        return code != null ? code : "Unknown";
    }

    private String wordWrap(String text, int width, String lineBreak) {
        var words = text.split(" ");
        var wrappedText = new StringBuilder();
        var line = new StringBuilder();

        for (String word : words) {
            if (line.length() + word.length() > width) {
                wrappedText.append(line).append(lineBreak);
                line.setLength(0);
            }
            line.append(word).append(" ");
        }
        wrappedText.append(line);

        return wrappedText.toString().trim();
    }

}