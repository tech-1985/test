package com.ford.gpcse.service;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import org.springframework.core.io.Resource;

public interface FirmwareXmlExportV7Service {
    Resource generateFirmwareV7Xml(ExportFirmwareXmlRequest exportFirmwareXmlRequest);
}
