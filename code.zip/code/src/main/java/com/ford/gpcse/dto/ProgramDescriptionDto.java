package com.ford.gpcse.dto;

public record ProgramDescriptionDto(Long programKey, String mdlYrR, String pgmN, String platN, String engN,
                                    String transN) {
}
