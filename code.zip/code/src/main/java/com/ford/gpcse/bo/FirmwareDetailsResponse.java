package com.ford.gpcse.bo;

import com.ford.gpcse.dto.UserRoleDto;

import java.util.List;

public record FirmwareDetailsResponse(String firmwareType, String description, String independentVerifier,
                                      List<UserRoleDto> owners) {
}
