package com.ford.gpcse.service;

import com.ford.gpcse.bo.ProductionPartNumber;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

public interface PrismPartNumberSearchExcelService {
    ByteArrayInputStream exportPrismPartsByPartNumbers(List<ProductionPartNumber> productionPartNumbers)
            throws IOException;
}
