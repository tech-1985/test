package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ProductionPartNumber;
import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.service.ExportToExcelService;
import com.ford.gpcse.service.PartNumberSearchExcelService;
import com.ford.gpcse.service.PrismPartNumberSearchExcelService;
import com.ford.gpcse.service.ReleaseRequestSearchExcelService;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ExportToExcelServiceImpl implements ExportToExcelService {

    private final PartNumberSearchExcelService partNumberSearchExcelService;
    private final ReleaseRequestSearchExcelService releaseRequestSearchExcelService;
    private final PrismPartNumberSearchExcelService prismPartNumberSearchExcelService;

    public ExportToExcelServiceImpl(PartNumberSearchExcelService partNumberSearchExcelService,
                                    ReleaseRequestSearchExcelService releaseRequestSearchExcelService,
                                    PrismPartNumberSearchExcelService prismPartNumberSearchExcelService) {
        super();
        this.partNumberSearchExcelService = partNumberSearchExcelService;
        this.releaseRequestSearchExcelService = releaseRequestSearchExcelService;
        this.prismPartNumberSearchExcelService = prismPartNumberSearchExcelService;
    }

    @Override
    public ByteArrayInputStream exportPartsByPartNumbers(List<String> partNumbers) throws IOException {
        return partNumberSearchExcelService.exportPartsByPartNumbers(partNumbers);
    }

    @Override
    public ByteArrayInputStream exportPrismPartsByPartNumbers(List<ProductionPartNumber> productionPartNumbers)
            throws IOException {
        return prismPartNumberSearchExcelService.exportPrismPartsByPartNumbers(productionPartNumbers);
    }

    @Override
    public ByteArrayInputStream exportReleaseRequestDetails(ReleaseRequestSearchInput releaseRequestSearchInput)
            throws IOException {
        return releaseRequestSearchExcelService.exportReleaseRequestDetails(releaseRequestSearchInput);
    }

}
