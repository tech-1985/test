package com.ford.gpcse.bo;

public record SupplierView(String supplierName, String supplierCode) {
}
