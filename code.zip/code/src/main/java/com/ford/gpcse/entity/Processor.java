package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "WPCMF16_PROC")
public class Processor {

    @Id
    @Column(name = "PCMF16_PROC_D")
    private String procD;

    @Column(name = "PCMF16_PROC_N")
    private String procN;

    @Column(name = "PCMF16_SPD_NUM_X")
    private String spdNumX;

    @Column(name = "PCMF16_FLASH_SIZE_NUM_X")
    private String flashSizeNumX;

    @Column(name = "PCMF16_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMF16_ACTV_F")
    private String actvF;

    @Column(name = "PCMR16_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR16_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR16_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR16_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    public String getProcD() {
        return procD;
    }

    public void setProcD(String procD) {
        this.procD = procD;
    }

    public String getProcN() {
        return procN;
    }

    public void setProcN(String procN) {
        this.procN = procN;
    }

    public String getSpdNumX() {
        return spdNumX;
    }

    public void setSpdNumX(String spdNumX) {
        this.spdNumX = spdNumX;
    }

    public String getFlashSizeNumX() {
        return flashSizeNumX;
    }

    public void setFlashSizeNumX(String flashSizeNumX) {
        this.flashSizeNumX = flashSizeNumX;
    }

    public Long getSortOrdR() {
        return sortOrdR;
    }

    public void setSortOrdR(Long sortOrdR) {
        this.sortOrdR = sortOrdR;
    }

    public String getActvF() {
        return actvF;
    }

    public void setActvF(String actvF) {
        this.actvF = actvF;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }

}
