package com.ford.gpcse.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app")
public class AppConfig {

    private String openApiTitle;
    private String openApiDescription;
    private String vsemUrl;
    private String oauthUrl;
    private String clientId;
    private String clientSecret;
    private String resource;
    private Database database;

    public String getOpenApiTitle() {
        return openApiTitle;
    }

    public void setOpenApiTitle(String openApiTitle) {
        this.openApiTitle = openApiTitle;
    }

    public String getOpenApiDescription() {
        return openApiDescription;
    }

    public void setOpenApiDescription(String openApiDescription) {
        this.openApiDescription = openApiDescription;
    }

    public String getVsemUrl() {
        return vsemUrl;
    }

    public void setVsemUrl(String vsemUrl) {
        this.vsemUrl = vsemUrl;
    }

    public String getOauthUrl() {
        return oauthUrl;
    }

    public void setOauthUrl(String oauthUrl) {
        this.oauthUrl = oauthUrl;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }


    public Database getDatabase() {
        return database;
    }

    public void setDatabase(Database database) {
        this.database = database;
    }


}

class Database {
    private String url;
    private String username;
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}



