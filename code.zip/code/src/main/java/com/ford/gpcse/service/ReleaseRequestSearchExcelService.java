package com.ford.gpcse.service;

import com.ford.gpcse.bo.ReleaseRequestSearchInput;

import java.io.ByteArrayInputStream;
import java.io.IOException;

public interface ReleaseRequestSearchExcelService {
    ByteArrayInputStream exportReleaseRequestDetails(ReleaseRequestSearchInput releaseRequestSearchInput)
            throws IOException;

}
