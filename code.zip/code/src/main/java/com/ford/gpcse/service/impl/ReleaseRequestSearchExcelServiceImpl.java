package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.entity.ReleaseRequest;
import com.ford.gpcse.repository.ReleaseRequestRepository;
import com.ford.gpcse.service.ReleaseRequestSearchExcelService;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ReleaseRequestSearchExcelServiceImpl implements ReleaseRequestSearchExcelService {

    private static final String[] HEADERS = {"ID", "MY", "Prog.", "Engine", "Owner", "Status", "Module", "Priority",
            "Priority Description", "Reason", "R Level", "Coordination", "Strategy", "Back Compat", "Build Level",
            "Cal Release Date", "Project Control", "Previous Concern", "Release Usage", "Release Title", "Cal In CCM",
            "Sw Coordination", "Coordination Details", "Alert Req", "Alert Details", "Change Usage",
            "Change Usage Details", "Build Start Date", "Supplier VBF Delivery Date", "App DR Eng Cds", "Cal Eng Cds",
            "Cal Rel Support Cds", "Hardware Part Number", "Ipf Inst Part Number", "Service Part Number", "Concern",
            "Alert", "Created"};
    private final ReleaseRequestRepository releaseRequestRepository;

    public ReleaseRequestSearchExcelServiceImpl(ReleaseRequestRepository releaseRequestRepository) {
        super();
        this.releaseRequestRepository = releaseRequestRepository;
    }

    public static Specification<ReleaseRequest> filterByCriteria(ReleaseRequestSearchInput searchInput) {
        var id = searchInput.id();
        var moduleTypeCode = searchInput.moduleTypeCode();
        var calibrationLevel = searchInput.calibrationLevel();
        var modelYear = searchInput.modelYear();
        var program = searchInput.program();
        var engine = searchInput.engine();
        var status = searchInput.status();
        var owner = searchInput.owner();
        return (Root<ReleaseRequest> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
            Predicate predicate = cb.conjunction();
            predicate = applyBasicFilters(root, cb, predicate, id, calibrationLevel, status, owner);
            if (isAnyComplexFieldPresent(moduleTypeCode, modelYear, program, engine)) {
                predicate = applyProgramModuleFilters(root, cb, predicate, moduleTypeCode, modelYear, program, engine);
            }
            return predicate;
        };
    }

    private static Predicate applyBasicFilters(Root<ReleaseRequest> root, CriteriaBuilder cb, Predicate predicate,
                                               Long id, String calibrationLevel, String status, String owner) {
        if (id != null && id != -1) {
            predicate = cb.and(predicate, cb.equal(root.get("relReqK"), id));
        }
        if (isNotBlank(calibrationLevel)) {
            predicate = cb.and(predicate, cb.like(root.get("calRLevelR"), "%" + calibrationLevel + "%"));
        }
        if (isNotBlank(status)) {
            predicate = cb.and(predicate, cb.like(root.get("statusC"), "%" + status + "%"));
        }
        if (isNotBlank(owner)) {
            predicate = cb.and(predicate, cb.like(root.get("createUserC"), "%" + owner + "%"));
        }
        return predicate;
    }

    private static boolean isAnyComplexFieldPresent(String moduleTypeCode, String modelYear, String program,
                                                    String engine) {
        return isNotBlank(moduleTypeCode) || isNotBlank(modelYear) || isNotBlank(program) || isNotBlank(engine);
    }

    private static Predicate applyProgramModuleFilters(Root<ReleaseRequest> root, CriteriaBuilder cb,
                                                       Predicate predicate, String moduleTypeCode, String modelYear, String program, String engine) {
        var join = root.join("programReleaseRequests");
        var programJoin = join.join("programDescription");
        var moduleJoin = root.join("moduleType");
        Predicate subPredicate = cb.conjunction();
        if (isNotBlank(moduleTypeCode)) {
            subPredicate = cb.and(subPredicate, cb.like(moduleJoin.get("moduleTypC"), "%" + moduleTypeCode + "%"));
        }
        if (isNotBlank(modelYear)) {
            subPredicate = cb.and(subPredicate, cb.like(programJoin.get("mdlYrR"), "%" + modelYear + "%"));
        }
        if (isNotBlank(program)) {
            subPredicate = cb.and(subPredicate, cb.like(programJoin.get("pgmN"), "%" + program + "%"));
        }
        if (isNotBlank(engine)) {
            subPredicate = cb.and(subPredicate, cb.like(programJoin.get("engN"), "%" + engine + "%"));
        }
        return cb.and(predicate, subPredicate);
    }

    private static boolean isNotBlank(String str) {
        return str != null && !str.trim().isEmpty();
    }

    private static String getSafeValue(Object value) {
        return value != null ? value.toString() : "";
    }

    @Override
    @Transactional(readOnly = true)
    public ByteArrayInputStream exportReleaseRequestDetails(ReleaseRequestSearchInput releaseRequestSearchInput)
            throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            var releaseRequestSheet = workbook.createSheet("ReleaseRequest");
            createHeaderRowForReleaseRequest(releaseRequestSheet);
            var releaseRequests = releaseRequestRepository.findAll(filterByCriteria(releaseRequestSearchInput));
            createDataRowForReleaseRequest(releaseRequests, releaseRequestSheet);
            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    private void createDataRowForReleaseRequest(List<ReleaseRequest> releaseRequests, Sheet releaseRequestSheet) {
        var rowNum = 1;
        for (ReleaseRequest relReq : releaseRequests) {
            var row = releaseRequestSheet.createRow(rowNum++);
            var curCol = 0;
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getRelReqK()));
            row.createCell(curCol++).setCellValue(
                    getSafeValue(relReq.getProgramReleaseRequests().get(0).getProgramDescription().getMdlYrR()));
            row.createCell(curCol++).setCellValue(
                    getSafeValue(relReq.getProgramReleaseRequests().get(0).getProgramDescription().getPgmN()));
            row.createCell(curCol++).setCellValue(
                    getSafeValue(relReq.getProgramReleaseRequests().get(0).getProgramDescription().getEngN()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCreateUserC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getStatusC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getModuleType().getModuleTypC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getPrtyC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getPrtyDtlX()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getRelReqReasonX()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCalRLevelR()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCoordReqF()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getStratRelC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getBackCompatF()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getBldLvlC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCalRelY()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getProjectControlC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getPrevConcernC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getReleaseUsage().getRelUsgC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getReleaseTitleX()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCalInCcmF()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getAddHwSwCoordF()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getHwSwCoordDetailX()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getAlertRequiredF()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getAlertDetailX()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getRollPartChangeUsageF()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getRollPartChangeUsageX()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getBuildStartY()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getSuppVbfDelY()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getAppDrEngC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCalEngC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCalRelSupportC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getHardwarePartR()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getIpfInstalledPartR()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getServicePartR()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getConcernC()));
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getAlertC()));
            row.createCell(curCol).setCellValue(getSafeValue(relReq.getCreateS()));
        }
    }

    private void createHeaderRowForReleaseRequest(Sheet releaseRequestSheet) {
        var headerRow = releaseRequestSheet.createRow(0);
        headerRow.setHeightInPoints(20);
        var workbook = releaseRequestSheet.getWorkbook();
        var headerStyle = workbook.createCellStyle();
        var font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        var columnIndex = 0;
        for (String header : HEADERS) {
            var cell = headerRow.createCell(columnIndex);
            cell.setCellValue(header);
            cell.setCellStyle(headerStyle);
            var columnWidth = header.length() * 512;
            releaseRequestSheet.setColumnWidth(columnIndex, columnWidth);
            columnIndex++;
        }
    }
}
