package com.ford.gpcse.bo;

public record ReleaseRequestDetail(String requestId, String owner, String status, String moduleType, String priority,
                                   String priorityDriver, String releaseConcernReason, String firmwareProgram,
                                   String calibrationRNumber,
                                   String isCoordinationRequired, String swStrategy, String isBackwardCompatChange,
                                   String buildEvent,
                                   String calibrationReleaseDateCfx, String projectControlEngineer,
                                   String firmwareReleaseUsage,
                                   String releaseTitle, String isCalibrationCCMNumber,
                                   String isAdditionalHwSwCoordRequired,
                                   String hwSwCoordDetail, String isAlertRequired, String alertDetail,
                                   String isRollingUsageRequired,
                                   String rollingUsageChanges, String buildStartDate, String suppliertVbfDeliveryDate,
                                   String appDREngineer,
                                   String calibrationEngineer, String calibrationReleaseSupport,
                                   String hardwarePartNumber,
                                   String ipfInstalledPartNumber, String servicePartNumber) {
}
