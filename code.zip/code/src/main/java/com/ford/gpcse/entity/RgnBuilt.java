package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "WPCMR40_RGN_BUILT")
public class RgnBuilt {
    @Id
    @Column(name = "PCMR40_RGN_BUILT_C", nullable = false)
    private String rgnBuiltC;

    @Column(name = "PCMR40_RGN_BUILT_X", nullable = false)
    private String rgnBuiltX;

    @Column(name = "PCMR40_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR40_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR40_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR40_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    public String getRgnBuiltC() {
        return rgnBuiltC;
    }

    public void setRgnBuiltC(String rgnBuiltC) {
        this.rgnBuiltC = rgnBuiltC;
    }

    public String getRgnBuiltX() {
        return rgnBuiltX;
    }

    public void setRgnBuiltX(String rgnBuiltX) {
        this.rgnBuiltX = rgnBuiltX;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }

}
