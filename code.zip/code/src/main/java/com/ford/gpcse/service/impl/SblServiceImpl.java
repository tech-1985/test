package com.ford.gpcse.service.impl;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.bo.CreateSblRequest;
import com.ford.gpcse.bo.Email;
import com.ford.gpcse.bo.ReplaceSblRequest;
import com.ford.gpcse.dto.ReplaceSblPartDetailsDto;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.exception.*;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.repository.*;
import com.ford.gpcse.service.ReleaseProcessService;
import com.ford.gpcse.service.SblService;
import com.ford.gpcse.util.DateFormatterUtility;
import com.ford.gpcse.util.PartNumberUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class SblServiceImpl implements SblService {

    private static final Logger log = LoggerFactory.getLogger(SblServiceImpl.class);
    private static final String NOT_FOUND = " not found.";

    private final PartRepository partRepository;
    private final EmailService emailService;
    private final PartSignoffRepository partSignoffRepository;
    private final SupplierRepository supplierRepository;
    private final MicroTypeRepository microTypeRepository;
    private final ModuleTypeRepository moduleTypeRepository;
    private final ReleaseTypeRepository releaseTypeRepository;
    private final RelUsgRepository relUsgRepository;
    private final ReleaseProcessService releaseProcessService;

    public SblServiceImpl(PartRepository partRepository, EmailService emailService,
                          PartSignoffRepository partSignoffRepository, SupplierRepository supplierRepository,
                          MicroTypeRepository microTypeRepository, ModuleTypeRepository moduleTypeRepository,
                          ReleaseTypeRepository releaseTypeRepository, RelUsgRepository relUsgRepository,
                          ReleaseProcessService releaseProcessService) {
        this.partRepository = partRepository;
        this.emailService = emailService;
        this.partSignoffRepository = partSignoffRepository;
        this.supplierRepository = supplierRepository;
        this.microTypeRepository = microTypeRepository;
        this.moduleTypeRepository = moduleTypeRepository;
        this.releaseTypeRepository = releaseTypeRepository;
        this.relUsgRepository = relUsgRepository;
        this.releaseProcessService = releaseProcessService;
    }

    @Override
    @Transactional
    public void createSbl(CreateSblRequest createSblRequest) {

        if (createSblRequest.userId() != null && createSblRequest.userId().isEmpty()) {
            throw new InvalidInputException("User Id not found in the request.");
        }

        // Fetch mandatory related entities
        var releaseUsage = relUsgRepository.findById("PROD")
                .orElseThrow(() -> new UnableToInsertException("Release Usage 'PROD' not found."));
        var releaseType = releaseTypeRepository.findById("SBL")
                .orElseThrow(() -> new UnableToInsertException("Release Type 'SBL' not found."));
        var moduleType = moduleTypeRepository.findById(createSblRequest.moduleTypeCode()).orElseThrow(
                () -> new UnableToInsertException("Module Type " + createSblRequest.moduleTypeCode() + NOT_FOUND));
        var microType = microTypeRepository.findById(createSblRequest.microTypeCode()).orElseThrow(
                () -> new UnableToInsertException("Micro Type " + createSblRequest.microTypeCode() + NOT_FOUND));
        var supplier = supplierRepository.findById(createSblRequest.supplierCode())
                .orElseThrow(() -> new UnableToInsertException("Supplier " + createSblRequest.supplierCode() + NOT_FOUND));


        var part = new Part();
        part.setPartR("-" + createSblRequest.userId()
                + DateFormatterUtility.dateTimeStringNewPart(LocalDateTime.now()) + "-SBL");
        part.setCreateUserC(createSblRequest.userId());
        part.setLastUpdtUserC(createSblRequest.userId());
        part.setReleaseUsage(releaseUsage);
        part.setReleaseType(releaseType);
        part.setModuleType(moduleType);
        part.setMicroType(microType);
        part.setSupplier(supplier);
        part.setCmtX(createSblRequest.description());
        part.setConcernY(LocalDate.now());
        part.setConcernC("SBL" + DateFormatterUtility.dateTimeStringInYYMMDD(LocalDate.now()));
        part.setStatC("NewPnRequest");
        part.setEngineerCdsidC(createSblRequest.userId());
        part.setProcCmtX(createSblRequest.leadMyProgram());
        part.setPartNumX(createSblRequest.leadMyProgram());
        var savedPart = partRepository.save(part);

        if (savedPart.getPartR() == null) {
            throw new UnableToInsertException("Unable to insert '" + part.getPartR() + "'. Internal Error 1699.");
        }
        log.info("Sbl created successfully {}", savedPart.getPartR());
        // setup signoff process
        releaseProcessService.setupSignOffProcess(savedPart.getPartR(), "SBL", "PROD", createSblRequest.userId(),
                createSblRequest.userId());

        sendNewPartEmail(savedPart, "Create");

    }

    @Override
    @Transactional
    public void replaceSbl(ReplaceSblRequest replaceSblRequest) {

        // Validate user id
        if (replaceSblRequest.userId() != null && replaceSblRequest.userId().isEmpty()) {
            throw new InvalidInputException("User Id not found in the request.");
        }


        // Validate current part number
        if (replaceSblRequest.currentPartNumber() == null) {
            throw new IllegalArgumentException("Current Part Number must not be null.");
        }


        String currentPartNumber = replaceSblRequest.currentPartNumber();
        String newPartNumber = PartNumberUtility.incrementPartNumber(currentPartNumber);

        // Verify current and new part number in the database
        var optionalResults = partRepository.fetchPartDetails(currentPartNumber, newPartNumber);
        if (optionalResults.isEmpty()) {
            throw new ResourceNotFoundException(
                    "No records found for the provided part numbers: " + currentPartNumber + " -> " + newPartNumber);
        }

        ReplaceSblPartDetailsDto partDetails = optionalResults.get().get(0);

        // Check if the new part already exists in the database
        if (partDetails.newPartCheck() > 0) {
            throw new ResourceAlreadyExistException(
                    "Part Number " + newPartNumber + " already exists in the database.");
        }

        // Fetch mandatory related entities
        var releaseUsage = relUsgRepository.findById("PROD")
                .orElseThrow(() -> new UnableToInsertException("Release Usage 'PROD' not found."));
        var releaseType = releaseTypeRepository.findById("SBL")
                .orElseThrow(() -> new UnableToInsertException("Release Type 'SBL' not found."));
        var moduleType = moduleTypeRepository.findById(partDetails.moduleTypeCode()).orElseThrow(
                () -> new UnableToInsertException("Module Type " + partDetails.moduleTypeCode() + NOT_FOUND));
        var microType = microTypeRepository.findById(partDetails.microTypeCode()).orElseThrow(
                () -> new UnableToInsertException("Micro Type " + partDetails.microTypeCode() + NOT_FOUND));
        var supplier = supplierRepository.findById(partDetails.supplierCode())
                .orElseThrow(() -> new UnableToInsertException("Supplier " + partDetails.supplierCode() + NOT_FOUND));

        // Create new part entity
        Part part = new Part();
        part.setPartR(newPartNumber);
        part.setProdnF("Y");
        part.setArchF("N");
        part.setReldF("N");
        part.setCreateS(LocalDateTime.now());
        part.setCreateUserC(replaceSblRequest.userId());
        part.setLastUpdtUserC(replaceSblRequest.userId());
        part.setLastUpdtS(LocalDateTime.now());
        part.setReleaseUsage(releaseUsage);
        part.setReleaseType(releaseType);
        part.setModuleType(moduleType);
        part.setMicroType(microType);
        part.setSupplier(supplier);
        part.setCmtX(replaceSblRequest.description());
        part.setEngineerCdsidC(replaceSblRequest.userId());
        part.setReplacedPartR(currentPartNumber);
        part.setStatC("NewPnRequest");
        part.setConcernC("SBL" + DateFormatterUtility.dateTimeStringInYYMMDD(LocalDate.now()));
        part.setConcernY(LocalDate.now());

        // Save the new part
        Part savedPart = partRepository.save(part);
        if (savedPart.getPartR() == null) {
            throw new UnableToInsertException("Unable to insert part " + newPartNumber + ". Internal error 1699.");
        }
        log.info("SBL replaced successfully: {}", savedPart.getPartR());

        // Setup signoff process
        releaseProcessService.setupSignOffProcess(savedPart.getPartR(), "SBL", "PROD", replaceSblRequest.userId(),
                replaceSblRequest.userId());

        // Update Hardlock status
        int hardLockUpdate = partRepository.updatePartStatusAndCalib(
                "SBLXX" + DateFormatterUtility.dateTimeStringNotice(LocalDateTime.now()), savedPart.getPartR());

        if (hardLockUpdate > 0) {
            log.info("Hard Lock Status update success for Part {}", savedPart.getPartR());

            // Update signoff type to DCUUL
            int partSignOffUpdate = partSignoffRepository.updateUserCdsidCForSignoffs("DCUUL", savedPart.getPartR());
            if (partSignOffUpdate == 0) {
                throw new UnableToUpdateException("Unable to update signoff type for part " + savedPart.getPartR());
            }

        } else {
            throw new UnableToUpdateException("Unable to update HardLock status for part " + savedPart.getPartR());
        }

        // Send email notification
        sendNewPartEmail(savedPart, "Replace");
    }

    @LoggingAspect
    private void sendNewPartEmail(Part savedPart, String type) {

        var description = type.equals("Create") ? " has requested parts for " : " has created parts for ";
        var emailBody = "<html><body><p>" + savedPart.getCreateUserC() + description + savedPart.getConcernC() + ".</p>"
                + "<pre>" + savedPart.getCmtX() + "</pre></body></html>";

        emailService.sendMail(new Email(List.of(""), // To Email
                savedPart.getCreateUserC() + description + savedPart.getConcernC() + " .", emailBody, "" // From Email
        ));

    }
}