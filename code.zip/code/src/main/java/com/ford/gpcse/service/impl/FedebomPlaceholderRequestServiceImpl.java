package com.ford.gpcse.service.impl;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.bo.Email;
import com.ford.gpcse.bo.FedebomPlaceholderReleasePart;
import com.ford.gpcse.bo.FedebomPlaceholderReleasePartRequest;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.enums.ReleaseTypeCode;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.repository.ModuleTypeRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.RelUsgRepository;
import com.ford.gpcse.repository.ReleaseTypeRepository;
import com.ford.gpcse.service.FedebomPlaceholderRequestService;
import com.ford.gpcse.service.ReleaseProcessService;
import com.ford.gpcse.util.DateFormatterUtility;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class FedebomPlaceholderRequestServiceImpl implements FedebomPlaceholderRequestService {

    private final PartRepository partRepository;
    private final ReleaseProcessService releaseProcessService;
    private final ModuleTypeRepository moduleTypeRepository;
    private final RelUsgRepository relUsgRepository;
    private final ReleaseTypeRepository releaseTypeRepository;
    private final EmailService emailService;

    public FedebomPlaceholderRequestServiceImpl(PartRepository partRepository,
                                                ReleaseProcessService releaseProcessService, ModuleTypeRepository moduleTypeRepository,
                                                RelUsgRepository relUsgRepository, ReleaseTypeRepository releaseTypeRepository, EmailService emailService) {
        super();
        this.partRepository = partRepository;
        this.releaseProcessService = releaseProcessService;
        this.moduleTypeRepository = moduleTypeRepository;
        this.relUsgRepository = relUsgRepository;
        this.releaseTypeRepository = releaseTypeRepository;
        this.emailService = emailService;
    }

    private static boolean isHardwareReleaseType(String pReleaseType) {
        if (pReleaseType.equals("ARNAL") || pReleaseType.equals("AREUL") || pReleaseType.equals("AFD")
                || pReleaseType.equals("AFDCX") || pReleaseType.equals("AFG")) {
            return switch (pReleaseType) {
                case "BCCMH", "BCMBH", "BCMIH", "BECMH", "HWPT", "HWUTC", "HWPUT", "HWCUT", "HARDW", "HRDCN", "PMSEH",
                     "NXTPH", "NXFGH", "NXMBH", "UCLSH", "GPCMH", "AWDHH", "HPCMH", "TCCMH", "DCUH", "GDMH", "DLCMH",
                     "GSMH", "TRCMH", "VCMH", "VCMHP", "VCMHC" -> true;
                default -> false;
            };
        }

        return false;
    }

    @Override
    @Transactional
    public String addFedebomPlaceholderReleaseParts(
            FedebomPlaceholderReleasePartRequest fedebomPlaceholderReleasePartRequest) {

        var fedebomPlaceholderReleaseParts = fedebomPlaceholderReleasePartRequest.fedebomPlaceholderReleaseParts();

        var moduleType = moduleTypeRepository.findById(fedebomPlaceholderReleasePartRequest.moduleTypeCode())
                .orElseThrow(() -> new IllegalArgumentException("ModuleType with code "
                        + fedebomPlaceholderReleasePartRequest.moduleTypeCode() + " not found"));

        var releaseType = releaseTypeRepository.findById(fedebomPlaceholderReleasePartRequest.releaseTypeCode())
                .orElseThrow(() -> new IllegalArgumentException("ReleaseType with code "
                        + fedebomPlaceholderReleasePartRequest.releaseTypeCode() + " not found"));

        var relUsg = relUsgRepository.findById("PREL")
                .orElseThrow(() -> new IllegalArgumentException("RelUsg with code 'PREL' not found"));

        var index = 0;

        for (FedebomPlaceholderReleasePart fedebomPlaceholderReleasePart : fedebomPlaceholderReleaseParts) {
            if (!isHardwareReleaseType(fedebomPlaceholderReleasePartRequest.releaseTypeCode())) {
                String microType = partRepository
                        .findMicroTypeByHardwarePart(fedebomPlaceholderReleasePart.hardwarePn());
                // Micro type must not be _IB
                if (microType != null && microType.length() > 2 && microType.endsWith("_IB")) {

                    throw new IllegalStateException(new StringBuilder().append("Error: Micro Type '").append(microType)
                            .append("' must use APP Signed release type. ")
                            .append("Please resubmit this release using the 'PCM Assembly - Ford App Signed' release type.")
                            .toString());

                }
            }

            Part part = new Part();
            part.setPartR(fedebomPlaceholderReleasePart.pnPrefix() + "-" + fedebomPlaceholderReleasePartRequest.userId()
                    + DateFormatterUtility.dateTimeStringNewPart(LocalDateTime.now()) + index++);
            part.setModuleType(moduleType);
            part.setReleaseType(releaseType);
            part.setProdnF("Y");
            part.setArchF("N");
            part.setCalibR(null);
            part.setConcernC("PAUTHORITY");
            part.setReldF("N");
            part.setEngineerCdsidC(fedebomPlaceholderReleasePartRequest.userId());
            part.setSvcModuleF("N");
            part.setPartNumX("");
            part.setReleaseUsage(relUsg);
            part.setCmtX("");
            part.setBackwardCompat(null);
            part.setConcernY(LocalDate.now());
            part.setStatC("NewPnRequest");
            part.setCatchword(null);
            part.setHardwarePartR(fedebomPlaceholderReleasePart.hardwarePn());
            part.setProcCmtX(fedebomPlaceholderReleasePartRequest.sraComment());
            part.setStratCalibPartR(null);
            part.setCreateUserC(fedebomPlaceholderReleasePartRequest.userId());
            part.setLastUpdtUserC(fedebomPlaceholderReleasePartRequest.userId());
            var savedPart = partRepository.save(part);

            // Copy Hardware Information
            copyHardwareInformation(savedPart.getPartR(), savedPart.getReleaseType().getRelTypC(),
                    savedPart.getReleaseUsage().getRelUsgC());

            // Setup signoff process
            releaseProcessService.setupSignOffProcess(savedPart.getPartR(), "SBL", "PROD",
                    fedebomPlaceholderReleasePartRequest.userId(), fedebomPlaceholderReleasePartRequest.userId());
        }

        // Send email notification
        sendPartRequestEmail(fedebomPlaceholderReleasePartRequest.userId(), "PAUTHORITY");

        return "Update Complete";

    }

    @LoggingAspect
    private void sendPartRequestEmail(String userId, String concernC) {
        var subject = userId + " has requested parts for " + concernC + ".";
        var emailBody = "<html><body><p>" + subject + "</p></body></html>";

        emailService.sendMail(new Email(List.of(""), subject, emailBody, ""));
    }

    private void copyHardwareInformation(String partNumber, String releaseTypeCode, String releaseUsageCode) {
        if (releaseTypeCode.equals("HWPT") || releaseTypeCode.equals(ReleaseTypeCode.HWPUT.name())
                || releaseTypeCode.equals(ReleaseTypeCode.VCMHP.name())) {
            // Hardware Prototype Release
            addHardwareConfigurations(partNumber, releaseTypeCode);
        } else {
            // Copy Supplier, Main Micro Type, Rom Size and HCR Number from Hardware Type
            String hardwareReleaseType = getHardwareReleaseType(releaseTypeCode, releaseUsageCode);
            String hardwareAssemblyPartNumber = partRepository.findHardwareAssemblyPartNumber(partNumber,
                    hardwareReleaseType);
            if (null != hardwareAssemblyPartNumber) {
                partRepository.updatePart(hardwareAssemblyPartNumber, partNumber);
            }
        }

    }

    public void addHardwareConfigurations(String partNumber, String releaseTypeCode) {
        String hardwarePartNumber = partRepository.findHardwarePartRByPartR(partNumber);
        if (null == hardwarePartNumber) {
            throw new ResourceNotFoundException("Error:Unable to find part");
        }
        partRepository.deleteFirmwareByPartAndReleaseType(hardwarePartNumber, partNumber, releaseTypeCode);
        partRepository.deletePartByPartAndReleaseType(hardwarePartNumber, partNumber, releaseTypeCode);

    }

    private String getHardwareReleaseType(String releaseTypeCode, String releaseUsageCode) {
        return switch (releaseTypeCode) {
            case "ARNAL", "AFG", "AFGO", "AFD", "AFDCX", "AREUL", "PSUPR" ->
                    releaseUsageCode.equals("PROT") ? "HWPT" : "HARDW";
            case "UTCU2", "TSUPS" -> releaseUsageCode.equals("PROT") ? ReleaseTypeCode.HWPUT.name() : "HWUTC";
            case "BCCMA" -> "BCCMH";
            case "BCMBA" -> "BCMBH";
            case "BCMIA" -> "BCMIH";
            case "BECMA" -> "BECMH";
            case "PMSEA" -> "PMSEH";
            case "NXTPA" -> "NXTPH";
            case "NXFGA" -> "NXFGH";
            case "NXMBA" -> "NXMBH";
            case "UCLSA" -> "UCLSH";
            case "GPCMA" -> "GPCMH";
            case "TCCMA", "TCCMS" -> "TCCMH";
            case "AWDHA", "AWDHS" -> "AWDHH";
            case "HASM", "HASMS" -> "HPCMH";
            case "DCUA" -> "DCUH";
            case "GDMA" -> "GDMH";
            case "DLCMA", "DLCMS" -> "DLCMH";
            case "TRCMA" -> "TRCMH";
            case "VCMA" -> releaseUsageCode.equals("PROT") ? ReleaseTypeCode.VCMHP.name() : "VCMH";
            default -> "";
        };
    }

}
