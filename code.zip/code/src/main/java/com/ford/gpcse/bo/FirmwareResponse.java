package com.ford.gpcse.bo;

import com.ford.gpcse.dto.LookupProgramDescriptionDto;

import java.util.List;

public record FirmwareResponse(String assemblyPN, String calibration, String catchWord, String drcdsId, String notice,
                               String releaseUsage, String hardwarePN, String coreHardwarePN, String mainMicroType,
                               String supplier,
                               String coreHwEng, String softwarePN, String mainStrategy, String chipId,
                               String calibrator,
                               List<LookupProgramDescriptionDto> programDescriptions, String lineage,
                               List<GroupedFirmwareResponse> groupedFirmwares, String releaseType, String concern,
                               String wersConcernDescription) {
}
