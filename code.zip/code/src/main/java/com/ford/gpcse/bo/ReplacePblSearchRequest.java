package com.ford.gpcse.bo;

public record ReplacePblSearchRequest(String currentPbl, String newPbl) {
}
