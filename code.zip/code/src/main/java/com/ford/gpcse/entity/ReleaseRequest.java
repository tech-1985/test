package com.ford.gpcse.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "WPCMR48_RELEASE_REQUEST")
public class ReleaseRequest {

    @Id
    @Column(name = "PCMR48_REL_REQ_K")
    private Long relReqK;

    @ManyToOne
    @JoinColumn(name = "PCMR14_MODULE_TYP_C", referencedColumnName = "PCMR14_MODULE_TYP_C")
    private ModuleType moduleType;

    @ManyToOne
    @JoinColumn(name = "PCMR24_REL_USG_C", referencedColumnName = "PCMR24_REL_USG_C")
    private RelUsg releaseUsage;

    @OneToMany(mappedBy = "releaseRequest")
    private List<PgmReleaseRequest> programReleaseRequests;

    @Column(name = "PCMR48_PRTY_C", length = 6)
    private String prtyC;

    @Column(name = "PCMR48_PRTY_DTL_X", length = 25)
    private String prtyDtlX;

    @Column(name = "PCMR48_REL_REQ_REASON_X", length = 200)
    private String relReqReasonX;

    @Column(name = "PCMR48_CAL_R_LEVEL_R", length = 10)
    private String calRLevelR;

    @Column(name = "PCMR48_COORD_REQ_F", nullable = false, length = 1)
    private String coordReqF;

    @Column(name = "PCMR48_STRAT_REL_C", length = 24)
    private String stratRelC;

    @Column(name = "PCMR48_STATUS_C", length = 30)
    private String statusC;

    @Column(name = "PCMR48_CONCERN_C", length = 10)
    private String concernC;

    @Column(name = "PCMR48_ALERT_C", length = 10)
    private String alertC;

    @Column(name = "PCMR48_BACK_COMPAT_F", nullable = false, length = 1)
    private String backCompatF;

    @Column(name = "PCMR48_BLD_LVL_C", length = 10)
    private String bldLvlC;

    @Column(name = "PCMR48_CAL_REL_Y")
    private LocalDate calRelY;

    @Column(name = "PCMR48_PROJECT_CONTROL_C", length = 8)
    private String projectControlC;

    @Column(name = "PCMR48_PREV_CONCERN_C", length = 10)
    private String prevConcernC;

    @Column(name = "PCMR48_RELEASE_TITLE_X", length = 100)
    private String releaseTitleX;

    @Column(name = "PCMR48_CAL_IN_CCM_F", nullable = false, length = 1)
    private String calInCcmF;

    @Column(name = "PCMR48_CAL_NUM_CCM_R", length = 10)
    private String calNumCcmR;

    @Column(name = "PCMR48_ADD_HW_SW_COORD_F", nullable = false, length = 1)
    private String addHwSwCoordF;

    @Column(name = "PCMR48_HW_SW_COORD_DETAIL_X", length = 100)
    private String hwSwCoordDetailX;

    @Column(name = "PCMR48_ALERT_REQUIRED_F", nullable = false, length = 1)
    private String alertRequiredF;

    @Column(name = "PCMR48_ALERT_DETAIL_X", length = 100)
    private String alertDetailX;

    @Column(name = "PCMR48_ROLL_PART_CHANGE_USAGE_F", nullable = false, length = 1)
    private String rollPartChangeUsageF;

    @Column(name = "PCMR48_ROLL_PART_CHANGE_USAGE_X", length = 100)
    private String rollPartChangeUsageX;

    @Column(name = "PCMR48_BUILD_START_Y")
    private LocalDate buildStartY;

    @Column(name = "PCMR48_SUPP_VBF_DEL_Y")
    private LocalDate suppVbfDelY;

    @Column(name = "PCMR48_APP_DR_ENG_C", length = 8)
    private String appDrEngC;

    @Column(name = "PCMR48_CAL_ENG_C", length = 8)
    private String calEngC;

    @Column(name = "PCMR48_CAL_REL_SUPPORT_C", length = 8)
    private String calRelSupportC;

    @Column(name = "PCMR48_HARDWARE_PART_R", length = 24)
    private String hardwarePartR;

    @Column(name = "PCMR48_IPF_INSTALLED_PART_R", length = 24)
    private String ipfInstalledPartR;

    @Column(name = "PCMR48_SERVICE_PART_R", length = 24)
    private String servicePartR;

    @Column(name = "PCMR48_CCM_FILE_NAME_N", length = 100)
    private String ccmFileNameN;

    @Column(name = "PCMR48_CCM_FILE_L")
    private byte[] ccmFileL;

    @Column(name = "PCMF48_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMF48_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMF48_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMF48_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    public Long getRelReqK() {
        return relReqK;
    }

    public void setRelReqK(Long relReqK) {
        this.relReqK = relReqK;
    }

    public ModuleType getModuleType() {
        return moduleType;
    }

    public void setModuleType(ModuleType moduleType) {
        this.moduleType = moduleType;
    }

    public RelUsg getReleaseUsage() {
        return releaseUsage;
    }

    public void setReleaseUsage(RelUsg releaseUsage) {
        this.releaseUsage = releaseUsage;
    }

    public List<PgmReleaseRequest> getProgramReleaseRequests() {
        return programReleaseRequests;
    }

    public void setProgramReleaseRequests(List<PgmReleaseRequest> programReleaseRequests) {
        this.programReleaseRequests = programReleaseRequests;
    }

    public String getPrtyC() {
        return prtyC;
    }

    public void setPrtyC(String prtyC) {
        this.prtyC = prtyC;
    }

    public String getPrtyDtlX() {
        return prtyDtlX;
    }

    public void setPrtyDtlX(String prtyDtlX) {
        this.prtyDtlX = prtyDtlX;
    }

    public String getRelReqReasonX() {
        return relReqReasonX;
    }

    public void setRelReqReasonX(String relReqReasonX) {
        this.relReqReasonX = relReqReasonX;
    }

    public String getCalRLevelR() {
        return calRLevelR;
    }

    public void setCalRLevelR(String calRLevelR) {
        this.calRLevelR = calRLevelR;
    }

    public String getCoordReqF() {
        return coordReqF;
    }

    public void setCoordReqF(String coordReqF) {
        this.coordReqF = coordReqF;
    }

    public String getStratRelC() {
        return stratRelC;
    }

    public void setStratRelC(String stratRelC) {
        this.stratRelC = stratRelC;
    }

    public String getStatusC() {
        return statusC;
    }

    public void setStatusC(String statusC) {
        this.statusC = statusC;
    }

    public String getConcernC() {
        return concernC;
    }

    public void setConcernC(String concernC) {
        this.concernC = concernC;
    }

    public String getAlertC() {
        return alertC;
    }

    public void setAlertC(String alertC) {
        this.alertC = alertC;
    }

    public String getBackCompatF() {
        return backCompatF;
    }

    public void setBackCompatF(String backCompatF) {
        this.backCompatF = backCompatF;
    }

    public String getBldLvlC() {
        return bldLvlC;
    }

    public void setBldLvlC(String bldLvlC) {
        this.bldLvlC = bldLvlC;
    }

    public LocalDate getCalRelY() {
        return calRelY;
    }

    public void setCalRelY(LocalDate calRelY) {
        this.calRelY = calRelY;
    }

    public String getProjectControlC() {
        return projectControlC;
    }

    public void setProjectControlC(String projectControlC) {
        this.projectControlC = projectControlC;
    }

    public String getPrevConcernC() {
        return prevConcernC;
    }

    public void setPrevConcernC(String prevConcernC) {
        this.prevConcernC = prevConcernC;
    }

    public String getReleaseTitleX() {
        return releaseTitleX;
    }

    public void setReleaseTitleX(String releaseTitleX) {
        this.releaseTitleX = releaseTitleX;
    }

    public String getCalInCcmF() {
        return calInCcmF;
    }

    public void setCalInCcmF(String calInCcmF) {
        this.calInCcmF = calInCcmF;
    }

    public String getCalNumCcmR() {
        return calNumCcmR;
    }

    public void setCalNumCcmR(String calNumCcmR) {
        this.calNumCcmR = calNumCcmR;
    }

    public String getAddHwSwCoordF() {
        return addHwSwCoordF;
    }

    public void setAddHwSwCoordF(String addHwSwCoordF) {
        this.addHwSwCoordF = addHwSwCoordF;
    }

    public String getHwSwCoordDetailX() {
        return hwSwCoordDetailX;
    }

    public void setHwSwCoordDetailX(String hwSwCoordDetailX) {
        this.hwSwCoordDetailX = hwSwCoordDetailX;
    }

    public String getAlertRequiredF() {
        return alertRequiredF;
    }

    public void setAlertRequiredF(String alertRequiredF) {
        this.alertRequiredF = alertRequiredF;
    }

    public String getAlertDetailX() {
        return alertDetailX;
    }

    public void setAlertDetailX(String alertDetailX) {
        this.alertDetailX = alertDetailX;
    }

    public String getRollPartChangeUsageF() {
        return rollPartChangeUsageF;
    }

    public void setRollPartChangeUsageF(String rollPartChangeUsageF) {
        this.rollPartChangeUsageF = rollPartChangeUsageF;
    }

    public String getRollPartChangeUsageX() {
        return rollPartChangeUsageX;
    }

    public void setRollPartChangeUsageX(String rollPartChangeUsageX) {
        this.rollPartChangeUsageX = rollPartChangeUsageX;
    }

    public LocalDate getBuildStartY() {
        return buildStartY;
    }

    public void setBuildStartY(LocalDate buildStartY) {
        this.buildStartY = buildStartY;
    }

    public LocalDate getSuppVbfDelY() {
        return suppVbfDelY;
    }

    public void setSuppVbfDelY(LocalDate suppVbfDelY) {
        this.suppVbfDelY = suppVbfDelY;
    }

    public String getAppDrEngC() {
        return appDrEngC;
    }

    public void setAppDrEngC(String appDrEngC) {
        this.appDrEngC = appDrEngC;
    }

    public String getCalEngC() {
        return calEngC;
    }

    public void setCalEngC(String calEngC) {
        this.calEngC = calEngC;
    }

    public String getCalRelSupportC() {
        return calRelSupportC;
    }

    public void setCalRelSupportC(String calRelSupportC) {
        this.calRelSupportC = calRelSupportC;
    }

    public String getHardwarePartR() {
        return hardwarePartR;
    }

    public void setHardwarePartR(String hardwarePartR) {
        this.hardwarePartR = hardwarePartR;
    }

    public String getIpfInstalledPartR() {
        return ipfInstalledPartR;
    }

    public void setIpfInstalledPartR(String ipfInstalledPartR) {
        this.ipfInstalledPartR = ipfInstalledPartR;
    }

    public String getServicePartR() {
        return servicePartR;
    }

    public void setServicePartR(String servicePartR) {
        this.servicePartR = servicePartR;
    }

    public String getCcmFileNameN() {
        return ccmFileNameN;
    }

    public void setCcmFileNameN(String ccmFileNameN) {
        this.ccmFileNameN = ccmFileNameN;
    }

    public byte[] getCcmFileL() {
        return ccmFileL;
    }

    public void setCcmFileL(byte[] ccmFileL) {
        this.ccmFileL = ccmFileL;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }

    @PrePersist
    public void prePersist() {
        this.coordReqF = "N";
        this.backCompatF = "N";
        this.calInCcmF = "N";
        this.addHwSwCoordF = "N";
        this.alertRequiredF = "N";
        this.rollPartChangeUsageF = "N";

    }
}
