package com.ford.gpcse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "WPCMR49_PGM_RELEASE_REQUEST")
public class PgmReleaseRequest {
    @Id
    @Column(name = "PCMS01_PGM_K")
    private Long pgmK;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "PCMR48_REL_REQ_K", referencedColumnName = "PCMR48_REL_REQ_K", insertable = false, updatable = false)
    private ReleaseRequest releaseRequest;

    @ManyToOne
    @JoinColumn(name = "PCMS01_PGM_K", referencedColumnName = "PCMS01_PGM_K", insertable = false, updatable = false)
    private ProgramDescription programDescription;

    @Column(name = "PCMF49_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMF49_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMF49_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMF49_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    public Long getPgmK() {
        return pgmK;
    }

    public void setPgmK(Long pgmK) {
        this.pgmK = pgmK;
    }

    public ReleaseRequest getReleaseRequest() {
        return releaseRequest;
    }

    public void setReleaseRequest(ReleaseRequest releaseRequest) {
        this.releaseRequest = releaseRequest;
    }

    public ProgramDescription getProgramDescription() {
        return programDescription;
    }

    public void setProgramDescription(ProgramDescription programDescription) {
        this.programDescription = programDescription;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }

}
