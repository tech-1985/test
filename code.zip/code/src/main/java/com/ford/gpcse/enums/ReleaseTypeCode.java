package com.ford.gpcse.enums;

public enum ReleaseTypeCode {
    AREUL, AFD, AFDCX, AFG, AFGO, ARNAL, HRDCN, HARDW, HWPT, PSUPR, GSMA, HASM, HASMS, DPS6, UTCU2, HWUTC, TSUPS, HWPUT,
    HWCUT, TRCMA, VCMA, VCMH, VCMHP, VCMHC, DCUA, DLCMA, DLCMS;
}
