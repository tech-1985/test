package com.ford.gpcse.exception;

import java.io.Serial;

public class UnableToInsertException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 9194098611016945359L;

    public UnableToInsertException(String message) {
        super(message);
    }

    public UnableToInsertException(String message, Throwable cause) {
        super(message, cause);
    }
}