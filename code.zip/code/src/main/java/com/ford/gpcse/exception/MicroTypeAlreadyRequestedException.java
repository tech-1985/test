package com.ford.gpcse.exception;

import java.io.Serial;

public class MicroTypeAlreadyRequestedException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = -4983260339540987123L;

    public MicroTypeAlreadyRequestedException(String message) {
        super(message);
    }

    public MicroTypeAlreadyRequestedException(String message, Throwable cause) {
        super(message, cause);
    }
}