package com.ford.gpcse.exception;

import java.io.Serial;

public class InvalidPartNumberException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = -6875515272487381462L;

    public InvalidPartNumberException(String message) {
        super(message);
    }

    public InvalidPartNumberException(String message, Throwable cause) {
        super(message, cause);
    }
}