package com.ford.gpcse.exception;

import java.io.Serial;

public class UnableToSendEmailNotification extends RuntimeException {

    @Serial
    private static final long serialVersionUID = -7416053165885015876L;

    public UnableToSendEmailNotification(String message) {
        super(message);
    }

    public UnableToSendEmailNotification(String message, Throwable cause) {
        super(message, cause);
    }
}
