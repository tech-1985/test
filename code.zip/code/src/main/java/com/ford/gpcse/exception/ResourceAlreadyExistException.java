package com.ford.gpcse.exception;

import java.io.Serial;

public class ResourceAlreadyExistException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 3940696391128579964L;

    public ResourceAlreadyExistException(String message) {
        super(message);
    }

    public ResourceAlreadyExistException(String message, Throwable cause) {
        super(message, cause);
    }
}