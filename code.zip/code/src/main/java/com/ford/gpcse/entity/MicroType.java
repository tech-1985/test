package com.ford.gpcse.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "WPCMR19_MICRO_TYP")
public class MicroType {
    @Id
    @Column(name = "PCMR19_MICRO_TYP_C")
    private Long microTypC;

    @Column(name = "PCMR19_MICRO_TYP_X")
    private String microTypX;

    @Column(name = "PCMR19_ARCH_F")
    private String archF;

    @Column(name = "PCMR19_MICRO_TYP_OWNR_CDSID_C")
    private String microTypOwnrCdsidC;

    @Column(name = "PCMR19_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR19_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR19_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR19_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    @ManyToOne
    @JoinColumn(name = "PCMR14_MODULE_TYP_C", referencedColumnName = "PCMR14_MODULE_TYP_C")
    private ModuleType moduleType;

    @ManyToOne
    @JoinColumn(name = "PCMR17_SUPL_C", referencedColumnName = "PCMR17_SUPL_C")
    private Supplier supplier;

    @Column(name = "PCMR19_MICRO_TYP_STAT_C")
    private String microTypStatC;

    @Column(name = "PCMR19_CAN_TYP_C")
    private String canTypC;

    @Column(name = "PCMR19_OTA_TYP_C")
    private String otaTypC;

    @Column(name = "PCMR19_SW_REFLASH_TIME_N")
    private String swReflashTimeN;

    @Column(name = "PCMR19_MICRO_PROTO_TYP_X")
    private String microProtoTypX;

    public Long getMicroTypC() {
        return microTypC;
    }

    public void setMicroTypC(Long microTypC) {
        this.microTypC = microTypC;
    }

    public String getMicroTypX() {
        return microTypX;
    }

    public void setMicroTypX(String microTypX) {
        this.microTypX = microTypX;
    }

    public String getArchF() {
        return archF;
    }

    public void setArchF(String archF) {
        this.archF = archF;
    }

    public String getMicroTypOwnrCdsidC() {
        return microTypOwnrCdsidC;
    }

    public void setMicroTypOwnrCdsidC(String microTypOwnrCdsidC) {
        this.microTypOwnrCdsidC = microTypOwnrCdsidC;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }

    public ModuleType getModuleType() {
        return moduleType;
    }

    public void setModuleType(ModuleType moduleType) {
        this.moduleType = moduleType;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public String getMicroTypStatC() {
        return microTypStatC;
    }

    public void setMicroTypStatC(String microTypStatC) {
        this.microTypStatC = microTypStatC;
    }

    public String getCanTypC() {
        return canTypC;
    }

    public void setCanTypC(String canTypC) {
        this.canTypC = canTypC;
    }

    public String getOtaTypC() {
        return otaTypC;
    }

    public void setOtaTypC(String otaTypC) {
        this.otaTypC = otaTypC;
    }

    public String getSwReflashTimeN() {
        return swReflashTimeN;
    }

    public void setSwReflashTimeN(String swReflashTimeN) {
        this.swReflashTimeN = swReflashTimeN;
    }

    public String getMicroProtoTypX() {
        return microProtoTypX;
    }

    public void setMicroProtoTypX(String microProtoTypX) {
        this.microProtoTypX = microProtoTypX;
    }

}
