package com.ford.gpcse.dto;

public record ReplaceSblPartDetailsDto(String moduleTypeCode, Long microTypeCode, String supplierCode,
                                       Long newPartCheck) {
}
