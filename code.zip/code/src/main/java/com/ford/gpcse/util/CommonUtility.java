package com.ford.gpcse.util;

public class CommonUtility {

    private CommonUtility() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    public static String getSafeValue(Object value) {
        return value != null ? value.toString() : "";
    }
}
