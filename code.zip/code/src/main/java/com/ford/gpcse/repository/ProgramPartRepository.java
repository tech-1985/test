package com.ford.gpcse.repository;

import com.ford.gpcse.entity.ProgramPart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for accessing ProgramPart entities. Extends
 * JpaRepository to provide standard CRUD operations.
 */
@Repository
public interface ProgramPartRepository extends JpaRepository<ProgramPart, Long> {

    /**
     * Finds a list of ProgramPart entities based on a list of part numbers.
     *
     * @param partNumbers a list of part references to filter by
     * @return a list of ProgramPart entities matching the specified part numbers
     */
    List<ProgramPart> findByPart_PartRIn(List<String> partNumbers);
}
