package com.ford.gpcse.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenAPIConfig {

    private final AppConfig appConfig;

    public OpenAPIConfig(AppConfig appConfig) {
        super();
        this.appConfig = appConfig;
    }

    @Bean
    OpenAPI customOpenAPI() {
        return new OpenAPI().components(new Components())
                .info(new Info().title(appConfig.getOpenApiTitle()).description(appConfig.getOpenApiDescription()));
    }

}
