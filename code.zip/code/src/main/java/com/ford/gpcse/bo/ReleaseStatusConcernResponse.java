package com.ford.gpcse.bo;

import com.ford.gpcse.dto.LookupProgramDescriptionDto;

import java.util.List;

public record ReleaseStatusConcernResponse(String assemblyPN, String calibration, String drcdsId, String hardwarePN,
                                           String coreHardwarePN, String mainMicroType, String softwarePN,
                                           String mainStrategy, String chipD,
                                           List<LookupProgramDescriptionDto> programDescriptions, String lineage,
                                           ReleaseStatusDetails statusDetails) {
}
