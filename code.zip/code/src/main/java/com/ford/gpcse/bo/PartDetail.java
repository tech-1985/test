package com.ford.gpcse.bo;

public record PartDetail(String assemblyPN, String hardwarePN, String supplier, String catchWord, String calibrationNum,
                         String status, String dateCreated, String releaseType, String releaseUsage,
                         String wersConcernDescription,
                         String concernNumber, String softwarePN, String comments, String buildLevel,
                         String releasePriority,
                         String releasePriorityDetail) {
}
