package com.ford.gpcse.dto;

public record WersTextPartDto(String partR, String relTypeC, String backwardCompatC, String hardwarePartR,
                              String releaseUsageC, String programs) {
}
