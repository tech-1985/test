package com.ford.gpcse.external.vsem.service;

import com.ford.gpcse.bo.VsemServiceResponse;

public interface VsemService {
    VsemServiceResponse fetchPartFilenames(String partNumber);
}
