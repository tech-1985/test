package com.ford.gpcse.service;

import com.ford.gpcse.bo.CreateSblRequest;
import com.ford.gpcse.bo.ReplaceSblRequest;

public interface SblService {

    void createSbl(CreateSblRequest createSblRequest);

    void replaceSbl(ReplaceSblRequest replaceSblRequest);
}
