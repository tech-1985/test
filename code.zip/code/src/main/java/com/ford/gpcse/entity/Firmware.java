package com.ford.gpcse.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "WPCMR03_FIRMWARE")
public class Firmware {

    @Id
    @Column(name = "PCMR03_FIRMWARE_K")
    private Long firmwareK;

    @Column(name = "PCM002_ROLE_K")
    private Long roleKey;

    @Column(name = "PCMR41_FIRMWARE_TYP_C")
    private String firmwareTypC;

    @Column(name = "PCMR03_FIRMWARE_X")
    private String firmwareX;

    @Column(name = "PCMR03_MAX_LEN_R")
    private Long maxLenR;

    @Column(name = "PCMR03_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMR03_MUTUAL_EXCLUSIVE_GRP_R")
    private Long mutualExclusiveGrpR;

    @Column(name = "PCMR03_SEL_GRP_R")
    private Long selGrpR;

    @Column(name = "PCMR03_FIRMWARE_N")
    private String firmwareN;

    @Column(name = "PCMR03_REVW_RESP_C")
    private String revwRespC;

    @Column(name = "PCMR03_FIRMWARE_CATG_N")
    private String firmwareCatgN;

    @Column(name = "PCMR03_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR03_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR03_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR03_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    @OneToMany(mappedBy = "firmware", cascade = CascadeType.ALL)
    private List<FirmwareItem> firmwareItems;

    @OneToMany(mappedBy = "firmware", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<PartFirmware> partFirmwares;

    public Long getFirmwareK() {
        return firmwareK;
    }

    public void setFirmwareK(Long firmwareK) {
        this.firmwareK = firmwareK;
    }

    public Long getRoleKey() {
        return roleKey;
    }

    public void setRoleKey(Long roleKey) {
        this.roleKey = roleKey;
    }

    public String getFirmwareTypC() {
        return firmwareTypC;
    }

    public void setFirmwareTypC(String firmwareTypC) {
        this.firmwareTypC = firmwareTypC;
    }

    public String getFirmwareX() {
        return firmwareX;
    }

    public void setFirmwareX(String firmwareX) {
        this.firmwareX = firmwareX;
    }

    public Long getMaxLenR() {
        return maxLenR;
    }

    public void setMaxLenR(Long maxLenR) {
        this.maxLenR = maxLenR;
    }

    public Long getSortOrdR() {
        return sortOrdR;
    }

    public void setSortOrdR(Long sortOrdR) {
        this.sortOrdR = sortOrdR;
    }

    public Long getMutualExclusiveGrpR() {
        return mutualExclusiveGrpR;
    }

    public void setMutualExclusiveGrpR(Long mutualExclusiveGrpR) {
        this.mutualExclusiveGrpR = mutualExclusiveGrpR;
    }

    public Long getSelGrpR() {
        return selGrpR;
    }

    public void setSelGrpR(Long selGrpR) {
        this.selGrpR = selGrpR;
    }

    public String getFirmwareN() {
        return firmwareN;
    }

    public void setFirmwareN(String firmwareN) {
        this.firmwareN = firmwareN;
    }

    public String getRevwRespC() {
        return revwRespC;
    }

    public void setRevwRespC(String revwRespC) {
        this.revwRespC = revwRespC;
    }

    public String getFirmwareCatgN() {
        return firmwareCatgN;
    }

    public void setFirmwareCatgN(String firmwareCatgN) {
        this.firmwareCatgN = firmwareCatgN;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }

    public List<FirmwareItem> getFirmwareItems() {
        return firmwareItems;
    }

    public void setFirmwareItems(List<FirmwareItem> firmwareItems) {
        this.firmwareItems = firmwareItems;
    }

    public List<PartFirmware> getPartFirmwares() {
        return partFirmwares;
    }

    public void setPartFirmwares(List<PartFirmware> partFirmwares) {
        this.partFirmwares = partFirmwares;
    }

}
