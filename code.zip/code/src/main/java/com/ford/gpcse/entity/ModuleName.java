package com.ford.gpcse.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "WPCMF40_MODULE_NM")
public class ModuleName {
    @Id
    @Column(name = "PCMF40_MODULE_N")
    private String moduleN;

    @Column(name = "PCMF40_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMF40_ACTV_F")
    private String actvF;

    @Column(name = "PCMR40_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR40_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR40_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR40_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    @Column(name = "PCMF40_MOD_CATLG_C")
    private String modCatlgC;

    @OneToOne
    @JoinColumn(name = "PCMR14_MODULE_TYP_C", referencedColumnName = "PCMR14_MODULE_TYP_C")
    private ModuleType moduleType;

    public String getModuleN() {
        return moduleN;
    }

    public void setModuleN(String moduleN) {
        this.moduleN = moduleN;
    }

    public Long getSortOrdR() {
        return sortOrdR;
    }

    public void setSortOrdR(Long sortOrdR) {
        this.sortOrdR = sortOrdR;
    }

    public String getActvF() {
        return actvF;
    }

    public void setActvF(String actvF) {
        this.actvF = actvF;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }

    public String getModCatlgC() {
        return modCatlgC;
    }

    public void setModCatlgC(String modCatlgC) {
        this.modCatlgC = modCatlgC;
    }

    public ModuleType getModuleType() {
        return moduleType;
    }

    public void setModuleType(ModuleType moduleType) {
        this.moduleType = moduleType;
    }
}
