package com.ford.gpcse.service;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import org.springframework.core.io.Resource;

public interface FirmwareXmlExportV3Service {
    Resource generateFirmwareV3Xml(ExportFirmwareXmlRequest exportFirmwareXmlRequest);
}
