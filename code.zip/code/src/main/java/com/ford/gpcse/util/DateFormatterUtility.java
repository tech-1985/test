package com.ford.gpcse.util;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Date;

public class DateFormatterUtility {

    private DateFormatterUtility() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    public static String dateTimeStringInYYMMDD(LocalDate date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMdd");
        return date.format(formatter);
    }

    public static String dateTimeStringInMMDDYYYY(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        return dateFormat.format(date);
    }

    public static String dateTimeStringConcern(LocalDate pDate) {
        String yearPart = String.format("%02d", pDate.getYear() % 100);
        String monthPart = String.format("%02d", pDate.getMonthValue());
        String dayPart = String.format("%02d", pDate.getDayOfMonth());
        return yearPart + monthPart + dayPart;
    }

    public static String dateTimeStringNewPart(LocalDateTime pDate) {
        String monthPart = String.format("%02d", pDate.getMonthValue());
        String dayPart = String.format("%02d", pDate.getDayOfMonth());
        String hourPart = String.format("%02d", pDate.getHour());
        String minutePart = String.format("%02d", pDate.getMinute());
        String secondPart = String.format("%02d", pDate.getSecond());
        return monthPart + dayPart + hourPart + minutePart + secondPart;
    }

    public static String formatDateMonthAbr(LocalDate date) {
        if (date != null) {
            DateTimeFormatter outputFormatter = new DateTimeFormatterBuilder().appendPattern("MMM d, yyyy")
                    .toFormatter();
            return date.format(outputFormatter);
        } else {
            return " ";
        }
    }

    public static String dateTimeStringNotice(LocalDateTime pDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMddHHmm");
        return pDate.format(formatter);
    }

    public static String dateTimeStringFormatFilename(LocalDateTime dateTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd-HHmm");
        return dateTime.format(formatter);
    }

    public static String dateStringFormat(LocalDate date) {
        if (date != null) {
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            return date.format(dateFormatter);
        }
        return null;
    }

    public static String formatWersNotice(String wersNotice) {
        if (wersNotice != null && wersNotice.length() == 16) {
            return wersNotice.substring(0, 4).toUpperCase() + " " + wersNotice.charAt(4) + " "
                    + wersNotice.substring(5, 13) + " " + wersNotice.substring(13);
        }
        return wersNotice != null ? wersNotice : "";
    }

    public static String dateTimeXmlFormat(LocalDateTime pDateTime) {
        if (pDateTime != null) {
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

            String strTime = timeFormatter.format(pDateTime);

            if ("00:00:00".equals(strTime)) {
                return dateFormatter.format(pDateTime);
            } else {
                return dateFormatter.format(pDateTime) + "T" + strTime;
            }
        } else {
            return null;
        }
    }

    public static String formatExportedOn(LocalDateTime dateTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        return dateTime.format(formatter);
    }

}
