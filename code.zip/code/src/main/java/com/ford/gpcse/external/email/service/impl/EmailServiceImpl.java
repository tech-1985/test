package com.ford.gpcse.external.email.service.impl;

import com.ford.gpcse.bo.Email;
import com.ford.gpcse.external.email.service.EmailService;
import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

/**
 * Implementation of the EmailService interface for sending emails. This class
 * uses Spring's JavaMailSender to facilitate email sending functionality,
 * handling both plain text and HTML emails.
 */
@Service
public class EmailServiceImpl implements EmailService {

    private static final Logger log = LoggerFactory.getLogger(EmailServiceImpl.class);

    private final JavaMailSender emailSender;

    public EmailServiceImpl(JavaMailSender emailSender) {
        super();
        this.emailSender = emailSender;
    }

    /**
     * Sends an email using the provided Email object.
     *
     * @param email the Email object containing the necessary details to send the
     *              email
     * @return true if the email was sent successfully, false otherwise
     */
    @Override
    public boolean sendMail(Email email) {
        try {
            var message = emailSender.createMimeMessage();
            var helper = new MimeMessageHelper(message, true);
            helper.setTo(email.to().toArray(String[]::new));
            helper.setSubject(email.subject());
            helper.setText(email.body(), true);
            helper.setFrom(email.from());
            //emailSender.send(message);
            return true;
        } catch (MessagingException e) {
            log.error("Error occurred while sending email: {}", e.getMessage());
            return false;
        }
    }

}
