package com.ford.gpcse.external.vsem.service.impl;

import com.ford.gpcse.bo.VsemServiceResponse;
import com.ford.gpcse.config.AppConfig;
import com.ford.gpcse.exception.VsemServiceException;
import com.ford.gpcse.external.vsem.service.AuthService;
import com.ford.gpcse.external.vsem.service.VsemService;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * Implementation of the VsemService interface for fetching part filenames. This
 * service uses an authentication service to obtain a token and then makes a
 * request to the Vsem API to retrieve part information.
 */
@Service
public class VsemServiceImpl implements VsemService {

    private final AuthService authService;
    private final AppConfig appConfig;
    private final RestTemplate restTemplate;

    public VsemServiceImpl(AuthService authService, AppConfig appConfig, RestTemplate restTemplate) {
        super();
        this.authService = authService;
        this.appConfig = appConfig;
        this.restTemplate = restTemplate;
    }

    /**
     * Fetches part filenames for a given part number.
     *
     * @param partNumber The part number to retrieve filenames for
     * @return VsemServiceResponse containing the part filenames
     * @throws RuntimeException if there is an error during the API request
     */
    @Override
    public VsemServiceResponse fetchPartFilenames(String partNumber) {
        var accessToken = authService.fetchToken().accessToken();

        var headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken);
        headers.set("partNumber", partNumber);

        var requestEntity = new HttpEntity<Void>(headers);

        try {
            var response = restTemplate.exchange(appConfig.getVsemUrl(), HttpMethod.GET, requestEntity,
                    VsemServiceResponse.class);

            return response.getBody();
        } catch (RestClientException e) {
            throw new VsemServiceException("Error fetching part filenames", e);
        }
    }
}
