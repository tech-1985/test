package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.Email;
import com.ford.gpcse.bo.NewMicroMicroTypeRequest;
import com.ford.gpcse.entity.MicroType;
import com.ford.gpcse.entity.ModuleType;
import com.ford.gpcse.entity.SignoffMicroType;
import com.ford.gpcse.entity.Supplier;
import com.ford.gpcse.exception.MicroTypeAlreadyRequestedException;
import com.ford.gpcse.exception.UnableToInsertException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.repository.MicroTypeRepository;
import com.ford.gpcse.repository.ModuleTypeRepository;
import com.ford.gpcse.repository.SignoffMicroTypeRepository;
import com.ford.gpcse.repository.SupplierRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NewMicroTypeServiceImplTest {

    @Mock
    private MicroTypeRepository microTypeRepository;

    @Mock
    private ModuleTypeRepository moduleTypeRepository;

    @Mock
    private SupplierRepository supplierRepository;

    @Mock
    private SignoffMicroTypeRepository signoffMicroTypeRepository;

    @Mock
    private EmailService emailService;

    @InjectMocks
    private NewMicroTypeServiceImpl newMicroTypeService;

    @Test
    void testAddNewMainMicroType_Successful() {
        // Arrange
        NewMicroMicroTypeRequest request = new NewMicroMicroTypeRequest("MainType1", "user1", "user2", "Module123",
                "SupplierXYZ", "Supplier A");

        ModuleType moduleType = new ModuleType();
        moduleType.setModuleTypC("Module123");

        Supplier supplier = new Supplier();
        supplier.setSuplC("Supplier123");

        // Mock repository methods
        when(microTypeRepository.countByMicroTypeName(request.mainMicroTypeName())).thenReturn(0);
        when(moduleTypeRepository.findById(request.moduleTypeCode())).thenReturn(Optional.of(moduleType));
        when(supplierRepository.findById(request.supplierCode())).thenReturn(Optional.of(supplier));
        when(microTypeRepository.fetchMicroId()).thenReturn(123L);

        MicroType savedMicroType = new MicroType();
        savedMicroType.setMicroTypC(123L);
        when(microTypeRepository.save(any(MicroType.class))).thenReturn(savedMicroType);

        SignoffMicroType signoffMicroType = new SignoffMicroType();
        when(signoffMicroTypeRepository.save(any(SignoffMicroType.class))).thenReturn(signoffMicroType);

        // Act
        newMicroTypeService.addNewMainMicroType(request);

        // Assert
        verify(microTypeRepository).save(any(MicroType.class));
        verify(signoffMicroTypeRepository).save(any(SignoffMicroType.class));
        verify(emailService).sendMail(any(Email.class));
    }

    @Test
    void testAddNewMainMicroType_MicroTypeAlreadyRequested() {
        // Arrange
        NewMicroMicroTypeRequest request = new NewMicroMicroTypeRequest("MainType1", "user1", "user2", "Module123",
                "SupplierXYZ", "Supplier A");

        // Mock repository methods
        when(microTypeRepository.countByMicroTypeName(request.mainMicroTypeName())).thenReturn(1);

        // Act & Assert
        assertThrows(MicroTypeAlreadyRequestedException.class, () -> newMicroTypeService.addNewMainMicroType(request));
    }

    @Test
    void testAddNewMainMicroType_MissingMandatoryFields() {
        // Arrange
        NewMicroMicroTypeRequest request = new NewMicroMicroTypeRequest("MainType1", "user1", "user2", "Module123",
                "SupplierXYZ", "Supplier A");

        // Mock repository methods
        when(microTypeRepository.countByMicroTypeName(request.mainMicroTypeName())).thenReturn(0);
        when(moduleTypeRepository.findById(request.moduleTypeCode())).thenReturn(Optional.empty());
        when(supplierRepository.findById(request.supplierCode())).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(UnableToInsertException.class, () -> newMicroTypeService.addNewMainMicroType(request));
    }

    @Test
    void testAddNewMainMicroType_UnableToInsertMicroType() {
        // Arrange
        NewMicroMicroTypeRequest request = new NewMicroMicroTypeRequest("MainType1", "user1", "user2", "Module123",
                "SupplierXYZ", "Supplier A");

        ModuleType moduleType = new ModuleType();
        moduleType.setModuleTypC("Module123");

        Supplier supplier = new Supplier();
        supplier.setSuplC("Supplier123");

        // Mock repository methods
        when(microTypeRepository.countByMicroTypeName(request.mainMicroTypeName())).thenReturn(0);
        when(moduleTypeRepository.findById(request.moduleTypeCode())).thenReturn(Optional.of(moduleType));
        when(supplierRepository.findById(request.supplierCode())).thenReturn(Optional.of(supplier));
        when(microTypeRepository.fetchMicroId()).thenReturn(123L);

        MicroType savedMicroType = new MicroType();
        savedMicroType.setMicroTypC(null); // Simulate failure in saving MicroType
        when(microTypeRepository.save(any(MicroType.class))).thenReturn(savedMicroType);

        // Act & Assert
        assertThrows(UnableToInsertException.class, () -> newMicroTypeService.addNewMainMicroType(request));
    }

}
