package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.Part2PdxRequest;
import com.ford.gpcse.bo.VsemServiceResponse;
import com.ford.gpcse.external.vsem.service.VsemService;
import com.ford.gpcse.repository.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class Part2PdxServiceImplTest {

    @Mock
    private VsemService vsemService;

    @Mock
    private PartRepository partRepository;

    @Mock
    private FirmwareItemRepository firmwareItemRepository;

    @Mock
    private ModuleTypeRepository moduleTypeRepository;

    @Mock
    private ReleaseTypeRepository releaseTypeRepository;

    @Mock
    private MicroTypeRepository microTypeRepository;

    @InjectMocks
    private Part2PdxServiceImpl part2PdxService;

    @Test
    void testAddNewPart2OrPdx_MissingPartFiles() {
        // Arrange
        Part2PdxRequest request = new Part2PdxRequest("PII", "Module123", 456L, "user1", "user2", "1.0", "1.0",
                "Part123", "Part Description", "Yes");

        // Mock VSEM response: missing part files
        VsemServiceResponse vsemResponse = new VsemServiceResponse("Definition Approved", 200, "", "Part123",
                List.of("Part123.mdx"));
        when(vsemService.fetchPartFilenames(request.partNumber())).thenReturn(vsemResponse);

        // Act
        String result = part2PdxService.addNewPart2OrPdx(request);

        // Assert
        assertEquals("Missing mdx file\nMissing mdx.log file\nMissing doc or docx file\n", result);
    }

    @Test
    void testAddNewPart2OrPdx_VsemError() {
        // Arrange
        Part2PdxRequest request = new Part2PdxRequest("PII", "Module123", 456L, "user1", "user2", "1.0", "1.0",
                "Part123", "Part Description", "Yes");

        // Mock VSEM response: error message from VSEM
        VsemServiceResponse vsemResponse = new VsemServiceResponse("", 500, "Internal Server Error", "Part123",
                List.of());
        when(vsemService.fetchPartFilenames(request.partNumber())).thenReturn(vsemResponse);

        // Act
        String result = part2PdxService.addNewPart2OrPdx(request);

        // Assert
        assertEquals("Internal Server Error", result);
    }

    @Test
    void testAddNewPart2OrPdx_UnableToFindPartInVSEM() {
        // Arrange
        Part2PdxRequest request = new Part2PdxRequest("PII", "Module123", 456L, "user1", "user2", "1.0", "1.0",
                "Part123", "Part Description", "Yes");

        when(vsemService.fetchPartFilenames(request.partNumber())).thenReturn(null); // Simulate VSEM response as null

        // Act
        String result = part2PdxService.addNewPart2OrPdx(request);

        // Assert
        assertEquals("Unable to find part in VSEM", result);
    }

}
