package com.ford.gpcse;

import static org.assertj.core.api.Assertions.fail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpcseApplicationTests {

	@Test
	void main() {
		try {
			// This will invoke the main method and check for exceptions
			GpcseApplication.main(new String[] {});
		} catch (Exception e) {
			// If an exception occurs, fail the test
			fail("Main method threw an exception: " + e.getMessage());
		}
	}

}
