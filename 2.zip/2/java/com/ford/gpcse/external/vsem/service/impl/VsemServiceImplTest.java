package com.ford.gpcse.external.vsem.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.ford.gpcse.bo.TokenResponse;
import com.ford.gpcse.bo.VsemServiceResponse;
import com.ford.gpcse.config.AppConfig;
import com.ford.gpcse.exception.VsemServiceException;
import com.ford.gpcse.external.vsem.service.AuthService;

@ExtendWith(MockitoExtension.class)
class VsemServiceImplTest {

	@Mock
	private AuthService authService;

	@Mock
	private AppConfig appConfig;

	@Mock
	private RestTemplate restTemplate;

	@InjectMocks
	private VsemServiceImpl vsemServiceImpl;

	private String oauthToken = "mockAccessToken";
	private String vsemUrl = "https://vsemapi.com/parts";
	private String partNumber = "12345";
	private VsemServiceResponse vsemServiceResponse;

	@BeforeEach
	void setUp() {
		// Mock AuthService to return an access token
		when(authService.fetchToken()).thenReturn(new TokenResponse(oauthToken, "bearer", 3600, "refreshToken"));

		// Mock AppConfig to return the Vsem API URL
		when(appConfig.getVsemUrl()).thenReturn(vsemUrl);

		// Mock VsemServiceResponse
		vsemServiceResponse = new VsemServiceResponse("Available", 200, "Success", partNumber,
				Arrays.asList("filename1.xml", "filename2.xml"));
	}

	@Test
	void testFetchPartFilenames_Success() {
		// Prepare mock response from RestTemplate
		ResponseEntity<VsemServiceResponse> responseEntity = new ResponseEntity<>(vsemServiceResponse, HttpStatus.OK);
		when(restTemplate.exchange(eq(vsemUrl), eq(HttpMethod.GET), any(HttpEntity.class),
				eq(VsemServiceResponse.class))).thenReturn(responseEntity);

		// Call the method under test
		VsemServiceResponse result = vsemServiceImpl.fetchPartFilenames(partNumber);

		// Assert that the response is not null and contains the expected data
		assertNotNull(result);
		assertEquals("Available", result.partstatus());
		assertEquals(200, result.status());
		assertEquals("Success", result.message());
		assertEquals(partNumber, result.partnumber());
		assertTrue(result.partfilenames().contains("filename1.xml"));
		assertTrue(result.partfilenames().contains("filename2.xml"));
	}

	@Test
	void testFetchPartFilenames_ErrorHandling() {
		// Simulate an error from RestTemplate
		when(restTemplate.exchange(eq(vsemUrl), eq(HttpMethod.GET), any(HttpEntity.class),
				eq(VsemServiceResponse.class))).thenThrow(new RestClientException("API request failed"));

		// Call the method and expect an exception
		VsemServiceException exception = assertThrows(VsemServiceException.class,
				() -> vsemServiceImpl.fetchPartFilenames(partNumber));

		// Assert that the exception message is correct
		assertEquals("Error fetching part filenames", exception.getMessage());
	}

	@Test
	void testFetchPartFilenames_InvalidResponse() {
		// Simulate an invalid response (null body)
		ResponseEntity<VsemServiceResponse> responseEntity = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(eq(vsemUrl), eq(HttpMethod.GET), any(HttpEntity.class),
				eq(VsemServiceResponse.class))).thenReturn(responseEntity);

		// Call the method and assert the result is null or handled properly
		VsemServiceResponse result = vsemServiceImpl.fetchPartFilenames(partNumber);

		// Assert that the result is null
		assertNull(result);
	}
}
