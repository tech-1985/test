package com.ford.gpcse.controller;

import static org.hamcrest.CoreMatchers.containsString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import com.ford.gpcse.bo.ProductionPartNumber;
import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.service.ExportToExcelService;
import com.ford.gpcse.service.ExportToXmlService;

@ExtendWith(MockitoExtension.class)
class ExportDataControllerTest {

	private MockMvc mockMvc;

	@Mock
	private ExportToXmlService exportToXmlService;

	@Mock
	private ExportToExcelService exportToExcelService;

	private ExportDataController exportDataController;

	@BeforeEach
	public void setup() {
		exportDataController = new ExportDataController(exportToXmlService, exportToExcelService);
		mockMvc = MockMvcBuilders.standaloneSetup(exportDataController).build();
	}

	@Test
	void testexportPartsToExcelByPartNumbers() throws Exception {
		// Arrange
		List<String> partNumbers = List.of("P12345", "P67890");
		ByteArrayInputStream inputStream = new ByteArrayInputStream("Excel content".getBytes());
		when(exportToExcelService.exportPartsByPartNumbers(partNumbers)).thenReturn(inputStream);

		// Act & Assert
		mockMvc.perform(post("/api/v1/export/parts").contentType(MediaType.APPLICATION_JSON)
				.content("[\"P12345\", \"P67890\"]")).andExpect(status().isOk())
				.andExpect(header().string(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=FirmwareExport.xlsx"))
				.andExpect(content().contentType(MediaType.APPLICATION_OCTET_STREAM));

		verify(exportToExcelService, times(1)).exportPartsByPartNumbers(partNumbers);
	}

	@Test
	void testexportPrismPartsToCSVByPartNumbers() throws Exception {
		// Arrange
		List<ProductionPartNumber> productionPartNumbers = List.of(
				new ProductionPartNumber("P12345", "catchword1", "C123", "SW123", "HW123", "MicroTypeA", "WERS123"),
				new ProductionPartNumber("P67890", "catchword2", "C456", "SW456", "HW456", "MicroTypeB", "WERS456"));

		// Mocking the service to return a dummy ByteArrayInputStream
		ByteArrayInputStream inputStream = new ByteArrayInputStream("CSV content".getBytes());
		when(exportToExcelService.exportPrismPartsByPartNumbers(productionPartNumbers)).thenReturn(inputStream);

		// Act & Assert
		mockMvc.perform(post("/api/v1/export/prism/parts").contentType(MediaType.APPLICATION_JSON).content(
				"[{\"partNumber\": \"P12345\", \"catchWord\": \"catchword1\", \"calibrationNumber\": \"C123\", \"softwarePN\": \"SW123\", \"hardwarePN\": \"HW123\", \"mainMicroType\": \"MicroTypeA\", \"wersNotice\": \"WERS123\"}, "
						+ "{\"partNumber\": \"P67890\", \"catchWord\": \"catchword2\", \"calibrationNumber\": \"C456\", \"softwarePN\": \"SW456\", \"hardwarePN\": \"HW456\", \"mainMicroType\": \"MicroTypeB\", \"wersNotice\": \"WERS456\"}]"))
				.andExpect(status().isOk())
				.andExpect(header().string(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=FirmwareExport.csv"))
				.andExpect(content().contentType(MediaType.APPLICATION_OCTET_STREAM));

		// Verify that the service method was called
		verify(exportToExcelService, times(1)).exportPrismPartsByPartNumbers(productionPartNumbers);
	}

	@Test
	void testFetchFirmwareXml() throws Exception {
		// Arrange
		ExportFirmwareXmlRequest request = new ExportFirmwareXmlRequest(List.of("P12345", "P67890"), "CN123", "WERS123",
				"firmwareExport.xml", "1.0", "user123");
		ByteArrayInputStream inputStream = new ByteArrayInputStream("<xml>content</xml>".getBytes());
		when(exportToXmlService.exportFirmwareDataToXML(request)).thenReturn(new InputStreamResource(inputStream));

		// Act & Assert
		mockMvc.perform(post("/api/v1/export/firmware-xml").contentType(MediaType.APPLICATION_JSON).content(
				"{\"partNumbers\": [\"P12345\", \"P67890\"], \"concernNumber\": \"CN123\", \"wersNoticeNumber\": \"WERS123\", \"exportFilename\": \"firmwareExport.xml\", \"exportVersion\": \"1.0\", \"createUser\": \"user123\"}"))
				.andExpect(status().isOk())
				.andExpect(
						header().string(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"firmwareExport.xml\""))
				.andExpect(content().contentType("application/xml"));

		verify(exportToXmlService, times(1)).exportFirmwareDataToXML(request);
	}

	@Test
	void testexportReleaseRequestDetailsToExcel() throws Exception {
		// Arrange
		ReleaseRequestSearchInput searchInput = new ReleaseRequestSearchInput(123L, // id
				"ModuleX", "Level1", "Active", "JohnDoe", "2024", "ProgramA", "V8", "user123", "user456");

		// Mocking the service to return a dummy ByteArrayInputStream
		ByteArrayInputStream inputStream = new ByteArrayInputStream("Excel content".getBytes());
		when(exportToExcelService.exportReleaseRequestDetails(searchInput)).thenReturn(inputStream);
		// Get today's date
		LocalDate currentDate = LocalDate.now();

		// Define the format (YYYYMMDD)
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");

		// Format the current date
		String formattedDate = currentDate.format(formatter);

		// Generate the filename
		String filename = "ReleaseRequestSearchResult" + formattedDate + ".xlsx";

		// Act & Assert
		mockMvc.perform(post("/api/v1/export/release-request").contentType(MediaType.APPLICATION_JSON).content(
				"{\"id\": 123, \"moduleTypeCode\": \"ModuleX\", \"calibrationLevel\": \"Level1\", \"status\": \"Active\", \"owner\": \"JohnDoe\", \"modelYear\": \"2024\", \"program\": \"ProgramA\", \"engine\": \"V8\", \"createUser\": \"user123\", \"lastUpdateUser\": \"user456\"}"))
				.andExpect(status().isOk())
				.andExpect(header().string(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename))
				.andExpect(content().contentType(MediaType.APPLICATION_OCTET_STREAM));

		// Verify that the service method was called
		verify(exportToExcelService, times(1)).exportReleaseRequestDetails(searchInput);
	}

	@Test
	void testexportPartsToExcelByPartNumbers_Error() throws Exception {
		// Arrange
		List<String> partNumbers = List.of("P12345", "P67890");
		String expectedErrorMessage = "IOException message"; // This is the message you expect from IOException
		when(exportToExcelService.exportPartsByPartNumbers(partNumbers))
				.thenThrow(new IOException(expectedErrorMessage)); // Simulate IOException with message

		// Act & Assert
		mockMvc.perform(post("/api/v1/export/parts").contentType(MediaType.APPLICATION_JSON)
				.content("[\"P12345\", \"P67890\"]")).andExpect(status().isInternalServerError())
				.andExpect(content().string(containsString("Error occurred:")))
				.andExpect(content().string(containsString(expectedErrorMessage)));

		// Verify that the service method was called once
		verify(exportToExcelService, times(1)).exportPartsByPartNumbers(partNumbers);
	}

	@Test
	void testexportPrismPartsToCSVByPartNumbers_Error() throws Exception {
		// Arrange
		List<ProductionPartNumber> productionPartNumbers = List.of(
				new ProductionPartNumber("P12345", "CatchWord1", "Calib1", "SWPN1", "HWPN1", "Micro1", "Wers1"),
				new ProductionPartNumber("P67890", "CatchWord2", "Calib2", "SWPN2", "HWPN2", "Micro2", "Wers2"));
		String expectedErrorMessage = "IOException message"; // The exception message we expect
		when(exportToExcelService.exportPrismPartsByPartNumbers(productionPartNumbers))
				.thenThrow(new IOException(expectedErrorMessage)); // Simulate IOException with a message

		// Act & Assert
		mockMvc.perform(post("/api/v1/export/prism/parts").contentType(MediaType.APPLICATION_JSON).content(
				"[{\"partNumber\":\"P12345\",\"catchWord\":\"CatchWord1\",\"calibrationNumber\":\"Calib1\",\"softwarePN\":\"SWPN1\",\"hardwarePN\":\"HWPN1\",\"mainMicroType\":\"Micro1\",\"wersNotice\":\"Wers1\"},"
						+ "{\"partNumber\":\"P67890\",\"catchWord\":\"CatchWord2\",\"calibrationNumber\":\"Calib2\",\"softwarePN\":\"SWPN2\",\"hardwarePN\":\"HWPN2\",\"mainMicroType\":\"Micro2\",\"wersNotice\":\"Wers2\"}]"))
				.andExpect(status().isInternalServerError())
				.andExpect(content().string(containsString("Error occurred:")))
				.andExpect(content().string(containsString(expectedErrorMessage)));

		// Verify that the service method was called once
		verify(exportToExcelService, times(1)).exportPrismPartsByPartNumbers(productionPartNumbers);
	}

	@Test
	void testexportReleaseRequestDetailsToExcel_Error() throws Exception {
		// Arrange
		ReleaseRequestSearchInput releaseRequestSearchInput = new ReleaseRequestSearchInput(123L, "ModuleType",
				"CalibrationLevel", "Status", "Owner", "2024", "Program", "Engine", "CreateUser", "LastUpdateUser");
		String expectedErrorMessage = "IOException message"; // The exception message we expect
		when(exportToExcelService.exportReleaseRequestDetails(releaseRequestSearchInput))
				.thenThrow(new IOException(expectedErrorMessage)); // Simulate IOException with a message

		// Act & Assert
		mockMvc.perform(post("/api/v1/export/release-request").contentType(MediaType.APPLICATION_JSON).content(
				"{\"id\":123,\"moduleTypeCode\":\"ModuleType\",\"calibrationLevel\":\"CalibrationLevel\",\"status\":\"Status\",\"owner\":\"Owner\",\"modelYear\":\"2024\",\"program\":\"Program\",\"engine\":\"Engine\",\"createUser\":\"CreateUser\",\"lastUpdateUser\":\"LastUpdateUser\"}"))
				.andExpect(status().isInternalServerError()) // Check for Internal Server Error
				.andExpect(content().string(containsString("Error occurred:"))) // Check that "Error occurred:" is in
																				// the response body
				.andExpect(content().string(containsString(expectedErrorMessage))); // Check that the exception message
																					// is in the response body

		// Verify that the service method was called once
		verify(exportToExcelService, times(1)).exportReleaseRequestDetails(releaseRequestSearchInput);
	}

	@Test
	void testFetchFirmwareXml_withExportFilename() throws Exception {
		// Arrange: Create a request where exportFilename is provided
		ExportFirmwareXmlRequest request = new ExportFirmwareXmlRequest(List.of("P12345", "P67890"), "CN123", "WERS123",
				"firmwareExport.xml", "1.0", "user123");

		// Mock the service to return dummy XML content
		ByteArrayInputStream inputStream = new ByteArrayInputStream("<xml>content</xml>".getBytes());
		when(exportToXmlService.exportFirmwareDataToXML(request)).thenReturn(new InputStreamResource(inputStream));

		// Act & Assert: Perform the request and check if the correct filename is
		// returned in the header
		mockMvc.perform(post("/api/v1/export/firmware-xml").contentType(MediaType.APPLICATION_JSON).content(
				"{\"partNumbers\": [\"P12345\", \"P67890\"], \"concernNumber\": \"CN123\", \"wersNoticeNumber\": \"WERS123\", \"exportFilename\": \"firmwareExport.xml\", \"exportVersion\": \"1.0\", \"createUser\": \"user123\"}"))
				.andExpect(status().isOk())
				.andExpect(
						header().string(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"firmwareExport.xml\""))
				.andExpect(content().contentType("application/xml"))
				.andExpect(content().bytes("<xml>content</xml>".getBytes())); // Check if the response body matches the
																				// mock data

		// Verify that the service method was called once
		verify(exportToXmlService, times(1)).exportFirmwareDataToXML(request);
	}

	@Test
	void testFetchFirmwareXml_withoutExportFilename() throws Exception {
		// Arrange: Create a request where exportFilename is not provided
		ExportFirmwareXmlRequest request = new ExportFirmwareXmlRequest(List.of("P12345", "P67890"), "CN123", "WERS123",
				null, "1.0", "user123");

		// Mock the service to return dummy XML content
		ByteArrayInputStream inputStream = new ByteArrayInputStream("<xml>content</xml>".getBytes());
		when(exportToXmlService.exportFirmwareDataToXML(request)).thenReturn(new InputStreamResource(inputStream));

		// Act & Assert: Perform the request and check if the default filename is
		// returned in the header
		mockMvc.perform(post("/api/v1/export/firmware-xml").contentType(MediaType.APPLICATION_JSON).content(
				"{\"partNumbers\": [\"P12345\", \"P67890\"], \"concernNumber\": \"CN123\", \"wersNoticeNumber\": \"WERS123\", \"exportFilename\": null, \"exportVersion\": \"1.0\", \"createUser\": \"user123\"}"))
				.andExpect(status().isOk())
				.andExpect(header().string(HttpHeaders.CONTENT_DISPOSITION, containsString("FirmwareExport"))) // Check
																												// for
																												// default
																												// filename
				.andExpect(content().contentType("application/xml"))
				.andExpect(content().bytes("<xml>content</xml>".getBytes())); // Check if the response body matches the
																				// mock data

		// Verify that the service method was called once
		verify(exportToXmlService, times(1)).exportFirmwareDataToXML(request);
	}

}
