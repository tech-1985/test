package com.ford.gpcse.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import com.ford.gpcse.entity.Catchword;
import com.ford.gpcse.entity.ModuleType;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.entity.PartFirmware;
import com.ford.gpcse.entity.ProgramDescription;
import com.ford.gpcse.entity.Supplier;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.ProgramDescriptionRepository;

class FirmwareXmlExportV6ServiceImplTest {

	@Mock
	private PartRepository partRepository;

	@Mock
	private ProgramDescriptionRepository programDescriptionRepository;

	@Mock
	private PartFirmwareRepository partFirmwareRepository;

	@InjectMocks
	private FirmwareXmlExportV6ServiceImpl firmwareXmlExportV6ServiceImpl;

	private ExportFirmwareXmlRequest exportFirmwareXmlRequest;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		// Initialize mock objects before each test
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(List.of("partNumber1", "partNumber2"), "concern123",
				"wersNotice123", "exportFile.xml", "6", "user123");
	}

	public static List<Part> createMockPartList() {
		List<Part> partList = new ArrayList<>();

		// Create first part mock data
		Part part1 = new Part();
		part1.setPartR("PART001");
		part1.setIpfPartR("IPF001");
		part1.setReplacedPartR("REPLACED_PART001");
		part1.setProdnF("YES");
		part1.setSaleableF("NO");
		part1.setIndstrCostA(new BigDecimal("160.00"));
		part1.setCatchWordC("CATCH001");
		part1.setConcernC("CONCERN001");
		part1.setConcernY(LocalDate.of(2026, 11, 30));
		part1.setStatC("ACTIVE");
		part1.setCreateUserC("user1");
		part1.setCreateS(LocalDateTime.now());
		part1.setLastUpdtUserC("user1");
		part1.setLastUpdtS(LocalDateTime.now());

		// Creating mocked related entities (you can mock these as needed)
		Catchword catchword = new Catchword();
		catchword.setCatchwordC("CATCH001");
		part1.setCatchword(catchword);

		ModuleType moduleType = new ModuleType();
		moduleType.setModuleTypC("MODULE001");
		part1.setModuleType(moduleType);

		Supplier supplier = new Supplier();
		supplier.setSuplC("SUP001");
		part1.setSupplier(supplier);

		// Add this part to the list
		partList.add(part1);

		// Create second part mock data
		Part part2 = new Part();
		part2.setPartR("PART002");
		part2.setIpfPartR("IPF002");
		part2.setReplacedPartR("REPLACED_PART002");
		part2.setProdnF("NO");
		part2.setSaleableF("YES");
		part2.setIndstrCostA(new BigDecimal("200.00"));
		part2.setCatchWordC("CATCH002");
		part2.setConcernC("CONCERN002");
		part2.setConcernY(LocalDate.of(2026, 6, 16));
		part2.setStatC("INACTIVE");
		part2.setCreateUserC("user2");
		part2.setCreateS(LocalDateTime.now());
		part2.setLastUpdtUserC("user2");
		part2.setLastUpdtS(LocalDateTime.now());

		// Creating mocked related entities
		Catchword catchword2 = new Catchword();
		catchword2.setCatchwordC("CATCH002");
		part2.setCatchword(catchword2);

		ModuleType moduleType2 = new ModuleType();
		moduleType2.setModuleTypC("MODULE002");
		part2.setModuleType(moduleType2);

		Supplier supplier2 = new Supplier();
		supplier2.setSuplC("SUP002");
		part2.setSupplier(supplier2);

		// Add this part to the list
		partList.add(part2);

		return partList;
	}

	@Test
	void testGenerateFirmwareV6Xml() {
		// Prepare test data
		PartFirmware partFirmware1 = mock(PartFirmware.class);
		PartFirmware partFirmware2 = mock(PartFirmware.class);
		ProgramDescription programDescription1 = mock(ProgramDescription.class);
		ProgramDescription programDescription2 = mock(ProgramDescription.class);

		// Create Example for PartRepository
		ExampleMatcher partMatcher = ExampleMatcher.matching().withIgnorePaths("id");
		Example<Part> partExample = Example.of(new Part(), partMatcher);

		// Create Example for PartFirmwareRepository
		ExampleMatcher firmwareMatcher = ExampleMatcher.matching().withIgnorePaths("id");
		Example<PartFirmware> firmwareExample = Example.of(new PartFirmware(), firmwareMatcher);

		// Create Example for ProgramDescriptionRepository
		ExampleMatcher programDescriptionMatcher = ExampleMatcher.matching().withIgnorePaths("id");
		Example<ProgramDescription> programDescriptionExample = Example.of(new ProgramDescription(),
				programDescriptionMatcher);

		// Mock the behavior of partRepository.findAll(Example<Part>) to return parts
		when(partRepository.findAll(partExample)).thenReturn(createMockPartList());

		// Mock the behavior of partFirmwareRepository.findAll(Example<PartFirmware>) to
		// return part firmwares
		when(partFirmwareRepository.findAll(firmwareExample)).thenReturn(List.of(partFirmware1, partFirmware2));

		// Mock the behavior of
		// programDescriptionRepository.findAll(Example<ProgramDescription>) to return
		// program descriptions
		when(programDescriptionRepository.findAll(programDescriptionExample))
				.thenReturn(List.of(programDescription1, programDescription2));

		// Call the method under test
		Resource result = firmwareXmlExportV6ServiceImpl.generateFirmwareV6Xml(exportFirmwareXmlRequest);

		// Assert the result is not null
		assertNotNull(result, "The result should not be null.");

		// Check that result is a ByteArrayResource and contains valid XML content
		assertTrue(result instanceof ByteArrayResource, "Result should be an instance of ByteArrayResource");

		// Cast result to ByteArrayResource
		ByteArrayResource byteArrayResource = (ByteArrayResource) result;
		String xmlContent = new String(byteArrayResource.getByteArray());

		// Assert that the XML contains specific content
		assertTrue(xmlContent.contains("<PCMReleases"),
				"The XML content should contain the root element <PCMReleases>");
		assertTrue(xmlContent.contains("Version=\"6\""), "The XML content should have Version attribute set to 6");
		assertTrue(xmlContent.contains("ExportedBy"), "The XML content should contain the ExportedBy attribute");
	}

}
