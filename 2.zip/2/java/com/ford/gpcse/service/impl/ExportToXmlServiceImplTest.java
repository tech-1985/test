package com.ford.gpcse.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import com.ford.gpcse.service.FirmwareXmlExportV10Service;
import com.ford.gpcse.service.FirmwareXmlExportV3Service;
import com.ford.gpcse.service.FirmwareXmlExportV4Service;
import com.ford.gpcse.service.FirmwareXmlExportV5Service;
import com.ford.gpcse.service.FirmwareXmlExportV6Service;
import com.ford.gpcse.service.FirmwareXmlExportV7Service;
import com.ford.gpcse.service.FirmwareXmlExportV8Service;
import com.ford.gpcse.service.FirmwareXmlExportV9Service;

class ExportToXmlServiceImplTest {

	@InjectMocks
	private ExportToXmlServiceImpl exportToXmlService;

	@Mock
	private FirmwareXmlExportV3Service firmwareXmlExportV3Service;

	@Mock
	private FirmwareXmlExportV4Service firmwareXmlExportV4Service;

	@Mock
	private FirmwareXmlExportV5Service firmwareXmlExportV5Service;

	@Mock
	private FirmwareXmlExportV6Service firmwareXmlExportV6Service;

	@Mock
	private FirmwareXmlExportV7Service firmwareXmlExportV7Service;

	@Mock
	private FirmwareXmlExportV8Service firmwareXmlExportV8Service;

	@Mock
	private FirmwareXmlExportV9Service firmwareXmlExportV9Service;

	@Mock
	private FirmwareXmlExportV10Service firmwareXmlExportV10Service;

	private ExportFirmwareXmlRequest exportFirmwareXmlRequest;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testFetchFirmwareXmlWithNoValidQueryParams() throws IOException {
		// Arrange: Create a request with no valid query params (empty lists or nulls)
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(null, null, null, "export.xml", "default", "user1");

		ByteArrayResource expectedResponse = new ByteArrayResource(
				"<ROOT><ERROR>YOU MUST PROVIDE A WHERE CLAUSE.</ERROR></ROOT>".getBytes(StandardCharsets.UTF_8));

		// Act: Call the method
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify that the response is the expected error message
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals(new String(expectedResponse.getByteArray(), StandardCharsets.UTF_8), resultContent);
	}

	@Test
	void testFetchFirmwareXmlWithNoValidQueryParamsEmptyWersNotice() throws IOException {
		// Arrange: Create a request with no valid query params (empty lists or nulls)
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(null, null, "", "export.xml", "default", "user1");

		ByteArrayResource expectedResponse = new ByteArrayResource(
				"<ROOT><ERROR>YOU MUST PROVIDE A WHERE CLAUSE.</ERROR></ROOT>".getBytes(StandardCharsets.UTF_8));

		// Act: Call the method
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify that the response is the expected error message
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals(new String(expectedResponse.getByteArray(), StandardCharsets.UTF_8), resultContent);
	}

	@Test
	void testFetchFirmwareXmlForVersion3() throws IOException {
		// Arrange: Mock the service for version 3
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(List.of("partNumber1", "partNumber2"), null, null,
				"export.xml", "3", "user1");
		when(firmwareXmlExportV3Service.generateFirmwareV3Xml(exportFirmwareXmlRequest))
				.thenReturn(new ByteArrayResource("<XML>Version 3</XML>".getBytes(StandardCharsets.UTF_8)));

		// Act: Call the method
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify the result from the V3 service
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals("<XML>Version 3</XML>", resultContent);
		verify(firmwareXmlExportV3Service, times(1)).generateFirmwareV3Xml(exportFirmwareXmlRequest);
	}

	@Test
	void testFetchFirmwareXmlForVersion4() throws IOException {
		// Arrange: Mock the service for version 4
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(List.of("partNumber1", "partNumber2"), null, null,
				"export.xml", "4", "user1");
		when(firmwareXmlExportV4Service.generateFirmwareV4Xml(exportFirmwareXmlRequest))
				.thenReturn(new ByteArrayResource("<XML>Version 4</XML>".getBytes(StandardCharsets.UTF_8)));

		// Act: Call the method
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify the result from the V4 service
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals("<XML>Version 4</XML>", resultContent);
		verify(firmwareXmlExportV4Service, times(1)).generateFirmwareV4Xml(exportFirmwareXmlRequest);
	}

	@Test
	void testFetchFirmwareXmlForVersion5() throws IOException {
		// Arrange: Mock the service for version 5
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(List.of("partNumber1", "partNumber2"), null, null,
				"export.xml", "5", "user1");
		when(firmwareXmlExportV5Service.generateFirmwareV5Xml(exportFirmwareXmlRequest))
				.thenReturn(new ByteArrayResource("<XML>Version 5</XML>".getBytes(StandardCharsets.UTF_8)));

		// Act: Call the method
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify the result from the V5 service
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals("<XML>Version 5</XML>", resultContent);
		verify(firmwareXmlExportV5Service, times(1)).generateFirmwareV5Xml(exportFirmwareXmlRequest);
	}

	@Test
	void testFetchFirmwareXmlForVersion6() throws IOException {
		// Arrange: Mock the service for version 6
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(List.of("partNumber1", "partNumber2"), null, null,
				"export.xml", "6", "user1");
		when(firmwareXmlExportV6Service.generateFirmwareV6Xml(exportFirmwareXmlRequest))
				.thenReturn(new ByteArrayResource("<XML>Version 6</XML>".getBytes(StandardCharsets.UTF_8)));

		// Act: Call the method
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify the result from the V6 service
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals("<XML>Version 6</XML>", resultContent);
		verify(firmwareXmlExportV6Service, times(1)).generateFirmwareV6Xml(exportFirmwareXmlRequest);
	}

	@Test
	void testFetchFirmwareXmlForVersion7() throws IOException {
		// Arrange: Mock the service for version 7
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(List.of("partNumber1", "partNumber2"), null, null,
				"export.xml", "7", "user1");
		when(firmwareXmlExportV7Service.generateFirmwareV7Xml(exportFirmwareXmlRequest))
				.thenReturn(new ByteArrayResource("<XML>Version 7</XML>".getBytes(StandardCharsets.UTF_8)));

		// Act: Call the method
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify the result from the V7 service
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals("<XML>Version 7</XML>", resultContent);
		verify(firmwareXmlExportV7Service, times(1)).generateFirmwareV7Xml(exportFirmwareXmlRequest);
	}

	@Test
	void testFetchFirmwareXmlForVersion8() throws IOException {
		// Arrange: Mock the service for version 8
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(List.of("partNumber1", "partNumber2"), null, null,
				"export.xml", "8", "user1");
		when(firmwareXmlExportV8Service.generateFirmwareV8Xml(exportFirmwareXmlRequest))
				.thenReturn(new ByteArrayResource("<XML>Version 8</XML>".getBytes(StandardCharsets.UTF_8)));

		// Act: Call the method
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify the result from the V8 service
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals("<XML>Version 8</XML>", resultContent);
		verify(firmwareXmlExportV8Service, times(1)).generateFirmwareV8Xml(exportFirmwareXmlRequest);
	}

	@Test
	void testFetchFirmwareXmlForVersion9() throws IOException {
		// Arrange: Mock the service for version 9
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(List.of("partNumber1", "partNumber2"), null, null,
				"export.xml", "9", "user1");
		when(firmwareXmlExportV9Service.generateFirmwareV9Xml(exportFirmwareXmlRequest))
				.thenReturn(new ByteArrayResource("<XML>Version 9</XML>".getBytes(StandardCharsets.UTF_8)));

		// Act: Call the method
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify the result from the V9 service
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals("<XML>Version 9</XML>", resultContent);
		verify(firmwareXmlExportV9Service, times(1)).generateFirmwareV9Xml(exportFirmwareXmlRequest);
	}

	@Test
	void testFetchFirmwareXmlForDefaultVersion() throws IOException {
		// Arrange: Mock the service for version 10 (default version)
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(List.of("partNumber1", "partNumber2"), null, null,
				"export.xml", null, "user1");
		when(firmwareXmlExportV10Service.generateFirmwareV10Xml(exportFirmwareXmlRequest))
				.thenReturn(new ByteArrayResource("<XML>Version 10</XML>".getBytes(StandardCharsets.UTF_8)));

		// Act: Call the method with no export version set (defaults to version 10)
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify the result from the default V10 service
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals("<XML>Version 10</XML>", resultContent);
		verify(firmwareXmlExportV10Service, times(1)).generateFirmwareV10Xml(exportFirmwareXmlRequest);
	}

	@Test
	void testFetchFirmwareXmlForUnknownVersion() throws IOException {
		// Arrange: Mock the service for version 10 (default version)
		exportFirmwareXmlRequest = new ExportFirmwareXmlRequest(List.of("partNumber1", "partNumber2"), null, null,
				"export.xml", "unknown", "user1");
		when(firmwareXmlExportV10Service.generateFirmwareV10Xml(exportFirmwareXmlRequest))
				.thenReturn(new ByteArrayResource("<XML>Version 10</XML>".getBytes(StandardCharsets.UTF_8)));

		// Act: Call the method with an unknown version string (should default to
		// version 10)
		Resource result = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);

		// Assert: Verify the result from the default V10 service
		assertNotNull(result);

		// Read content from the InputStream of the result
		String resultContent = new String(result.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

		assertEquals("<XML>Version 10</XML>", resultContent);
		verify(firmwareXmlExportV10Service, times(1)).generateFirmwareV10Xml(exportFirmwareXmlRequest);
	}
}
