package com.ford.gpcse.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ford.gpcse.bo.Email;
import com.ford.gpcse.bo.SupplierEnrollmentRequest;
import com.ford.gpcse.exception.UnableToSendEmailNotification;
import com.ford.gpcse.external.email.service.EmailService;

class EnrollmentServiceImplTest {

	@InjectMocks
	private EnrollmentServiceImpl enrollmentService;

	@Mock
	private EmailService emailService;

	private SupplierEnrollmentRequest supplierEnrollmentRequest;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		supplierEnrollmentRequest = new SupplierEnrollmentRequest("user123", "Rama", "Krishna",
				"ram.krishna@example.com", "No comments");
	}

	@Test
	void testSupplierEnrollmentSuccess() {
		// Arrange: Mock the email service to return true (email sent successfully)
		when(emailService.sendMail(any(Email.class))).thenReturn(true);

		// Act: Call the supplierEnrollment method
		String result = enrollmentService.supplierEnrollment(supplierEnrollmentRequest);

		// Assert: Verify the result is the success message
		assertEquals("Your request has been submitted.", result);
		// Verify that sendMail was called once
		verify(emailService, times(1)).sendMail(any(Email.class));
	}

	@Test
	void testSupplierEnrollmentFailure() {
		// Arrange: Mock the email service to return false (email sending failed)
		when(emailService.sendMail(any(Email.class))).thenReturn(false);

		// Act & Assert: Verify that the exception is thrown when email sending fails
		UnableToSendEmailNotification exception = assertThrows(UnableToSendEmailNotification.class, () -> {
			enrollmentService.supplierEnrollment(supplierEnrollmentRequest);
		});

		// Assert: Verify the exception message
		assertEquals("Your request not submitted due to SMTP failure", exception.getMessage());
		// Verify that sendMail was called once
		verify(emailService, times(1)).sendMail(any(Email.class));
	}
}
