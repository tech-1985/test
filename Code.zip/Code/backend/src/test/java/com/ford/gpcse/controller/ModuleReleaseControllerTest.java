package com.ford.gpcse.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gpcse.bo.CreatePblRequest;
import com.ford.gpcse.bo.CreateSblRequest;
import com.ford.gpcse.bo.NewMicroMicroTypeRequest;
import com.ford.gpcse.bo.Part2PdxRequest;
import com.ford.gpcse.bo.ReplacePblRequest;
import com.ford.gpcse.bo.ReplaceSblRequest;
import com.ford.gpcse.service.NewMainMicroTypeService;
import com.ford.gpcse.service.Part2PdxService;
import com.ford.gpcse.service.PblService;
import com.ford.gpcse.service.SblService;

@ExtendWith(MockitoExtension.class)
class ModuleReleaseControllerTest {

	private MockMvc mockMvc;
	private ObjectMapper objectMapper;

	@Mock
	private SblService sblService;

	@Mock
	private PblService pblService;

	@Mock
	private NewMainMicroTypeService newMainMicroTypeService;

	@Mock
	private Part2PdxService part2PdxService;

	@InjectMocks
	private ModuleReleaseController moduleReleaseController;

	@BeforeEach
	void setUp() {
		objectMapper = new ObjectMapper();
		mockMvc = MockMvcBuilders.standaloneSetup(moduleReleaseController).build();
	}

	@Test
	void testCreateSblValidRequest() throws Exception {
		CreateSblRequest validRequest = new CreateSblRequest("sup123", "moduleX", 123L, "Description of SBL",
				"LeadProgram", "user123");

		mockMvc.perform(post("/api/v1/module-release/sbl").contentType("application/json")
				.content(objectMapper.writeValueAsString(validRequest))).andExpect(status().isCreated())
				.andExpect(content().string("Part request has been submitted."));

		verify(sblService, times(1)).createSbl(validRequest);
	}

	@Test
	void testReplaceSblValidRequest() throws Exception {
		ReplaceSblRequest validRequest = new ReplaceSblRequest("moduleX", "part123", "Description of SBL replacement",
				"user123");

		mockMvc.perform(put("/api/v1/module-release/sbl").contentType("application/json")
				.content(objectMapper.writeValueAsString(validRequest))).andExpect(status().isOk())
				.andExpect(content().string("Part request has been submitted."));

		verify(sblService, times(1)).replaceSbl(validRequest);
	}

	@Test
	void testCreatePblValidRequest() throws Exception {
		CreatePblRequest validRequest = new CreatePblRequest("newPbl123", "moduleX", "user123", "user123");

		mockMvc.perform(post("/api/v1/module-release/pbl").contentType("application/json")
				.content(objectMapper.writeValueAsString(validRequest))).andExpect(status().isCreated())
				.andExpect(content().string("newPbl123 has been added to the firmware drop down list"));

		verify(pblService, times(1)).createPbl(validRequest);
	}

	@Test
	void testReplacePblValidRequest() throws Exception {
		ReplacePblRequest validRequest = new ReplacePblRequest("newPbl123", "moduleX", "user123", "user123",
				Arrays.asList("part123", "part456"));

		mockMvc.perform(put("/api/v1/module-release/pbl").contentType("application/json")
				.content(objectMapper.writeValueAsString(validRequest))).andExpect(status().isOk())
				.andExpect(content().string("newPbl123 has been added to the firmware drop down list"));

		verify(pblService, times(1)).replacePbl(validRequest);
	}

	@Test
	void testAddNewMainMicroTypeValidRequest() throws Exception {
		NewMicroMicroTypeRequest validRequest = new NewMicroMicroTypeRequest("MicroType1", "user123", "user123",
				"moduleX", "sup123", "Supplier1");

		mockMvc.perform(post("/api/v1/module-release/main-micro-type").contentType("application/json")
				.content(objectMapper.writeValueAsString(validRequest))).andExpect(status().isOk())
				.andExpect(content().string(
						"MicroType1 has been sent for review.  You will be emailed when this Main Micro Type is ready to be used in a release."));

		verify(newMainMicroTypeService, times(1)).addNewMainMicroType(validRequest);
	}

	@Test
	void testAddNewPart2OrPdxValidRequest() throws Exception {
		Part2PdxRequest validRequest = new Part2PdxRequest("release1", "moduleX", 123L, "user123", "user123", "ggdsV1",
				"swdlV1", "part123", "Part description", "yes");

		mockMvc.perform(post("/api/v1/module-release/part2-pdx").contentType("application/json")
				.content(objectMapper.writeValueAsString(validRequest))).andExpect(status().isOk())
				.andExpect(content().string(""));

		verify(part2PdxService, times(1)).addNewPart2OrPdx(validRequest);
	}

}
