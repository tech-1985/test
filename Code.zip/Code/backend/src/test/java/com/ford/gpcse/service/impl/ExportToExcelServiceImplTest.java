package com.ford.gpcse.service.impl;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ford.gpcse.bo.ProductionPartNumber;
import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.service.PartNumberSearchExcelService;
import com.ford.gpcse.service.PrismPartNumberSearchExcelService;
import com.ford.gpcse.service.ReleaseRequestSearchExcelService;

class ExportToExcelServiceImplTest {

	@InjectMocks
	private ExportToExcelServiceImpl exportToExcelService;

	@Mock
	private PartNumberSearchExcelService partNumberSearchExcelService;

	@Mock
	private ReleaseRequestSearchExcelService releaseRequestSearchExcelService;

	@Mock
	private PrismPartNumberSearchExcelService prismPartNumberSearchExcelService;

	private List<String> partNumbers;
	private List<ProductionPartNumber> productionPartNumbers;
	private ReleaseRequestSearchInput releaseRequestSearchInput;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this); // Initializes @Mock and @InjectMocks annotations

		// Setup sample input data
		partNumbers = List.of("P1234", "P5678");

		// Creating ProductionPartNumber records with mock values
		productionPartNumbers = List.of(
				new ProductionPartNumber("PP1234", "CatchWord1", "Calib1", "SW1234", "HW1234", "Micro1", "WERS1"),
				new ProductionPartNumber("PP5678", "CatchWord2", "Calib2", "SW5678", "HW5678", "Micro2", "WERS2"));

		// Creating ReleaseRequestSearchInput record with mock values
		releaseRequestSearchInput = new ReleaseRequestSearchInput(123L, "Module1", "Level1", "Active", "User1", "2024",
				"Program1", "Engine1", "CreateUser1", "UpdateUser1");
	}

	@Test
	void testExportPartsByPartNumbers() throws IOException {
		// Arrange: Mock the service to return a ByteArrayInputStream (simulating Excel
		// export)
		byte[] mockExcelContent = new byte[] { 1, 2, 3, 4 }; // Simulated Excel file content
		ByteArrayInputStream expectedOutput = new ByteArrayInputStream(mockExcelContent);
		when(partNumberSearchExcelService.exportPartsByPartNumbers(partNumbers)).thenReturn(expectedOutput);

		// Act: Call the method
		ByteArrayInputStream result = exportToExcelService.exportPartsByPartNumbers(partNumbers);

		// Assert: Verify that the result is not null and contains data
		assertNotNull(result);
		assertTrue(result.available() > 0, "The file content should not be empty.");

		// Optionally, we could check the content, but in this case, we are more
		// concerned with the file being returned
		byte[] resultContent = result.readAllBytes();
		assertArrayEquals(mockExcelContent, resultContent,
				"The content of the returned file should match the expected content.");

		// Verify that the method on the mock service was called with the correct
		// arguments
		verify(partNumberSearchExcelService, times(1)).exportPartsByPartNumbers(partNumbers);
	}

	@Test
	void testExportPrismPartsByPartNumbers() throws IOException {
		// Arrange: Mock the service to return a ByteArrayInputStream (simulating Excel
		// export)
		byte[] mockExcelContent = new byte[] { 5, 6, 7, 8 }; // Simulated Excel file content
		ByteArrayInputStream expectedOutput = new ByteArrayInputStream(mockExcelContent);
		when(prismPartNumberSearchExcelService.exportPrismPartsByPartNumbers(productionPartNumbers))
				.thenReturn(expectedOutput);

		// Act: Call the method
		ByteArrayInputStream result = exportToExcelService.exportPrismPartsByPartNumbers(productionPartNumbers);

		// Assert: Verify that the result is not null and contains data
		assertNotNull(result);
		assertTrue(result.available() > 0, "The file content should not be empty.");

		// Optionally, we could check the content, but in this case, we are more
		// concerned with the file being returned
		byte[] resultContent = result.readAllBytes();
		assertArrayEquals(mockExcelContent, resultContent,
				"The content of the returned file should match the expected content.");

		// Verify that the method on the mock service was called with the correct
		// arguments
		verify(prismPartNumberSearchExcelService, times(1)).exportPrismPartsByPartNumbers(productionPartNumbers);
	}

	@Test
	void testExportReleaseRequestDetails() throws IOException {
		// Arrange: Mock the service to return a ByteArrayInputStream (simulating Excel
		// export)
		byte[] mockExcelContent = new byte[] { 9, 10, 11, 12 }; // Simulated Excel file content
		ByteArrayInputStream expectedOutput = new ByteArrayInputStream(mockExcelContent);
		when(releaseRequestSearchExcelService.exportReleaseRequestDetails(releaseRequestSearchInput))
				.thenReturn(expectedOutput);

		// Act: Call the method
		ByteArrayInputStream result = exportToExcelService.exportReleaseRequestDetails(releaseRequestSearchInput);

		// Assert: Verify that the result is not null and contains data
		assertNotNull(result);
		assertTrue(result.available() > 0, "The file content should not be empty.");

		// Optionally, we could check the content, but in this case, we are more
		// concerned with the file being returned
		byte[] resultContent = result.readAllBytes();
		assertArrayEquals(mockExcelContent, resultContent,
				"The content of the returned file should match the expected content.");

		// Verify that the method on the mock service was called with the correct
		// arguments
		verify(releaseRequestSearchExcelService, times(1)).exportReleaseRequestDetails(releaseRequestSearchInput);
	}
}
