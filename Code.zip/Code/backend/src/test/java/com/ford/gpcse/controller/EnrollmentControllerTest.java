package com.ford.gpcse.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gpcse.bo.SupplierEnrollmentRequest;
import com.ford.gpcse.service.EnrollmentService;

@ExtendWith(MockitoExtension.class)
class EnrollmentControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Mock
	private EnrollmentService enrollmentService;

	@InjectMocks
	private EnrollmentController enrollmentController;

	private ObjectMapper objectMapper;

	@BeforeEach
	void setUp() {
		objectMapper = new ObjectMapper();
		mockMvc = MockMvcBuilders.standaloneSetup(enrollmentController).build();
	}

	@Test
	void testSupplierEnrollment_success() throws Exception {
		// Arrange
		SupplierEnrollmentRequest request = new SupplierEnrollmentRequest("user123", "Ram", "Krishna",
				"ram.krishna@example.com", "No comments");
		String expectedResponse = "Supplier enrollment email sent successfully.";

		// Mock the service call
		when(enrollmentService.supplierEnrollment(request)).thenReturn(expectedResponse);

		// Act & Assert: Perform POST request and verify the response
		mockMvc.perform(post("/api/v1/enrollment/supplier").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(request))).andExpect(status().isOk())
				.andExpect(content().string(expectedResponse));

		// Verify the service method was called once with the provided request
		verify(enrollmentService, times(1)).supplierEnrollment(request);
	}

}
