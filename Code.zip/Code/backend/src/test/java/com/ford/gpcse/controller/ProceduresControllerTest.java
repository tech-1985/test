package com.ford.gpcse.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ford.gpcse.bo.EditPartRequest;
import com.ford.gpcse.service.ProceduresService;

class ProceduresControllerTest {

	private MockMvc mockMvc;

	@Mock
	private ProceduresService proceduresService;

	@InjectMocks
	private ProceduresController proceduresController;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(proceduresController).build();
	}

	@Test
	void testEditPart_Success() throws Exception {

		// Act: Mock the service call
		doNothing().when(proceduresService).editPart(any(EditPartRequest.class));

		// Assert: Perform the PUT request and check the response
		mockMvc.perform(put("/api/v1/procedures/part").contentType(MediaType.APPLICATION_JSON)
				.content("{ \"partNumbers\": [\"part1\", \"part2\"], " + "\"softwarePN\": \"softwarePN123\", "
						+ "\"catchWord\": \"catchword1\", " + "\"concernNumber\": \"concern123\", "
						+ "\"calibrationNum\": \"calib123\", "
						+ "\"wersConcernDescription\": \"Concern description here\", " + "\"appEng\": \"appEng123\", "
						+ "\"comments\": \"Test comments\", " + "\"buildLevel\": \"build123\", "
						+ "\"releasePriority\": \"high\", " + "\"releasePriorityDetail\": \"critical\" }"))
				.andExpect(status().isOk()).andExpect(content().string("Update Complete"));
	}

}
