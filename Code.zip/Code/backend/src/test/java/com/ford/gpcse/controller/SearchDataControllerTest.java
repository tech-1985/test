package com.ford.gpcse.controller;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ford.gpcse.bo.FirmwareResponse;
import com.ford.gpcse.bo.GroupedFirmwareResponse;
import com.ford.gpcse.bo.GroupedFirmwareSearchResponse;
import com.ford.gpcse.bo.PartDetail;
import com.ford.gpcse.bo.PartNumberSearchRequest;
import com.ford.gpcse.bo.PartNumberSearchResponse;
import com.ford.gpcse.bo.ProductionPartNumberSearchRequest;
import com.ford.gpcse.bo.ProductionPartNumberSearchResponse;
import com.ford.gpcse.bo.ReleaseRequestOutput;
import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.bo.ReleaseStatusConcernResponse;
import com.ford.gpcse.bo.ReleaseStatusDetails;
import com.ford.gpcse.dto.LookupPartFirmwareDto;
import com.ford.gpcse.dto.LookupProgramDescriptionDto;
import com.ford.gpcse.service.SearchDataService;

@ExtendWith(MockitoExtension.class)
class SearchDataControllerTest {

	@Mock
	private SearchDataService searchDataService;

	@InjectMocks
	private SearchDataController searchDataController;

	private MockMvc mockMvc;

	@BeforeEach
	void setUp() {
		// Set up MockMvc with the controller under test
		mockMvc = MockMvcBuilders.standaloneSetup(searchDataController).build();
	}

	@Test
	void testFetchFirmwareDetailsByWersConcern() throws Exception {
		// Arrange: Prepare mock data
		List<LookupProgramDescriptionDto> programDescriptions = List.of(
				new LookupProgramDescriptionDto(123L, "2023", "Program1", "Platform1", "Engine1", "Transmission1"),
				new LookupProgramDescriptionDto(456L, "2024", "Program2", "Platform2", "Engine2", "Transmission2"));

		List<LookupPartFirmwareDto> partFirmwares = List.of(
				new LookupPartFirmwareDto("firmwareN1", "fileN1", "approvedBy1", "category1", LocalDate.of(2023, 1, 1)),
				new LookupPartFirmwareDto("firmwareN2", "fileN2", "approvedBy2", "category2",
						LocalDate.of(2023, 2, 1)));

		// GroupedFirmwareResponse contains category and firmwares list
		GroupedFirmwareResponse groupedFirmwareResponse = new GroupedFirmwareResponse("category1", partFirmwares);

		// FirmwareResponse now includes the GroupedFirmwareResponse as part of the
		// response
		FirmwareResponse firmwareResponse = new FirmwareResponse("assemblyPN1", "calibration1", "catchWord1",
				"drcdsId1", "notice1", "releaseUsage1", "hardwarePN1", "coreHardwarePN1", "mainMicroType1", "supplier1",
				"coreHwEng1", "softwarePN1", "mainStrategy1", "chipId1", "calibrator1", programDescriptions, "lineage1",
				List.of(groupedFirmwareResponse), "releaseType1", "concern1", "wersConcernDesc1");

		GroupedFirmwareSearchResponse response = new GroupedFirmwareSearchResponse("releaseType1", "usageType1",
				"concern1", "wersConcernDesc1", List.of(firmwareResponse));

		// Mock the service to return the above response for a specific wersConcern
		when(searchDataService.fetchFirmwareDetailsByWersConcern("wersConcern1")).thenReturn(List.of(response));

		// Act: Perform GET request and verify the response
		mockMvc.perform(get("/api/v1/search/wers-concern/wersConcern1")).andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(1))).andExpect(jsonPath("$[0].releaseType", is("releaseType1")))
				.andExpect(jsonPath("$[0].releaseUsage", is("usageType1")))
				.andExpect(jsonPath("$[0].concern", is("concern1")))
				.andExpect(jsonPath("$[0].wersConcernDescription", is("wersConcernDesc1")))
				.andExpect(jsonPath("$[0].firmwareResponses", hasSize(1)))
				.andExpect(jsonPath("$[0].firmwareResponses[0].assemblyPN", is("assemblyPN1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].calibration", is("calibration1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].catchWord", is("catchWord1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].drcdsId", is("drcdsId1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].notice", is("notice1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].releaseUsage", is("releaseUsage1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].hardwarePN", is("hardwarePN1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].coreHardwarePN", is("coreHardwarePN1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].mainMicroType", is("mainMicroType1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].supplier", is("supplier1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].coreHwEng", is("coreHwEng1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].softwarePN", is("softwarePN1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].mainStrategy", is("mainStrategy1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].chipId", is("chipId1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].calibrator", is("calibrator1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].lineage", is("lineage1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].groupedFirmwares", hasSize(1)))
				.andExpect(jsonPath("$[0].firmwareResponses[0].groupedFirmwares[0].category", is("category1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].groupedFirmwares[0].firmwares", hasSize(2)))
				.andExpect(jsonPath("$[0].firmwareResponses[0].groupedFirmwares[0].firmwares[0].firmwareN",
						is("firmwareN1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].groupedFirmwares[0].firmwares[1].firmwareN",
						is("firmwareN2")));
	}

	@Test
	void testFetchFirmwareDetailsByWersNotice() throws Exception {
		// Arrange: Prepare mock data
		List<LookupProgramDescriptionDto> programDescriptions = List.of(
				new LookupProgramDescriptionDto(123L, "2023", "Program1", "Platform1", "Engine1", "Transmission1"),
				new LookupProgramDescriptionDto(456L, "2024", "Program2", "Platform2", "Engine2", "Transmission2"));

		List<GroupedFirmwareResponse> groupedFirmwares = List.of(
				new GroupedFirmwareResponse("firmwareCategory1",
						List.of(new LookupPartFirmwareDto("firmwareN1", "fileN1", "approvedBy1", "category1",
								LocalDate.of(2023, 1, 1)))),
				new GroupedFirmwareResponse("firmwareCategory2", List.of(new LookupPartFirmwareDto("firmwareN2",
						"fileN2", "approvedBy2", "category2", LocalDate.of(2023, 2, 1)))));

		FirmwareResponse firmwareResponse = new FirmwareResponse("assemblyPN1", "calibration1", "catchWord1",
				"drcdsId1", "notice1", "releaseUsage1", "hardwarePN1", "coreHardwarePN1", "mainMicroType1", "supplier1",
				"coreHwEng1", "softwarePN1", "mainStrategy1", "chipId1", "calibrator1", programDescriptions, "lineage1",
				groupedFirmwares, "releaseType1", "concern1", "wersConcernDesc1");

		GroupedFirmwareSearchResponse response = new GroupedFirmwareSearchResponse("releaseType1", "usageType1",
				"concern1", "wersConcernDesc1", List.of(firmwareResponse));

		// Mock the service to return the above response for a specific wersNotice
		when(searchDataService.fetchFirmwareDetailsByWersNotice("wersNotice1")).thenReturn(List.of(response));

		// Act: Perform GET request and verify the response
		mockMvc.perform(get("/api/v1/search/wers-notice/wersNotice1")).andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(1))).andExpect(jsonPath("$[0].releaseType", is("releaseType1")))
				.andExpect(jsonPath("$[0].releaseUsage", is("usageType1")))
				.andExpect(jsonPath("$[0].concern", is("concern1")))
				.andExpect(jsonPath("$[0].wersConcernDescription", is("wersConcernDesc1")))
				.andExpect(jsonPath("$[0].firmwareResponses", hasSize(1)))
				.andExpect(jsonPath("$[0].firmwareResponses[0].assemblyPN", is("assemblyPN1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].calibration", is("calibration1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].catchWord", is("catchWord1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].drcdsId", is("drcdsId1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].notice", is("notice1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].releaseUsage", is("releaseUsage1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].hardwarePN", is("hardwarePN1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].coreHardwarePN", is("coreHardwarePN1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].mainMicroType", is("mainMicroType1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].supplier", is("supplier1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].coreHwEng", is("coreHwEng1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].softwarePN", is("softwarePN1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].mainStrategy", is("mainStrategy1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].chipId", is("chipId1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].calibrator", is("calibrator1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].lineage", is("lineage1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].groupedFirmwares", hasSize(2)))
				.andExpect(jsonPath("$[0].firmwareResponses[0].groupedFirmwares[0].category", is("firmwareCategory1")))
				.andExpect(jsonPath("$[0].firmwareResponses[0].groupedFirmwares[1].category", is("firmwareCategory2")));
	}

	@Test
	void testFetchFirmwareDetailsByPrograms() throws Exception {
		// Arrange: Prepare mock data
		List<LookupProgramDescriptionDto> programDescriptions = List.of(
				new LookupProgramDescriptionDto(123L, "2023", "Program1", "Platform1", "Engine1", "Transmission1"),
				new LookupProgramDescriptionDto(456L, "2024", "Program2", "Platform2", "Engine2", "Transmission2"));

		List<LookupPartFirmwareDto> partFirmwares = List.of(
				new LookupPartFirmwareDto("firmwareN1", "fileN1", "approvedBy1", "category1", LocalDate.of(2023, 1, 1)),
				new LookupPartFirmwareDto("firmwareN2", "fileN2", "approvedBy2", "category2",
						LocalDate.of(2023, 2, 1)));

		List<GroupedFirmwareResponse> groupedFirmwares = List.of(
				new GroupedFirmwareResponse("category1", partFirmwares),
				new GroupedFirmwareResponse("category2", partFirmwares));

		FirmwareResponse firmwareResponse = new FirmwareResponse("assemblyPN1", "calibration1", "catchWord1",
				"drcdsId1", "notice1", "releaseUsage1", "hardwarePN1", "coreHardwarePN1", "mainMicroType1", "supplier1",
				"coreHwEng1", "softwarePN1", "mainStrategy1", "chipId1", "calibrator1", programDescriptions, "lineage1",
				groupedFirmwares, "releaseType1", "concern1", "wersConcernDesc1");

		// Mock the service to return the above response for a specific programKeys
		when(searchDataService.fetchFirmwareDetailsByPrograms(List.of(123L, 456L)))
				.thenReturn(List.of(firmwareResponse));

		// Act: Perform POST request with the programKeys list and verify the response
		mockMvc.perform(post("/api/v1/search/programs").contentType(MediaType.APPLICATION_JSON).content("[123, 456]"))
				.andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(1)))
				.andExpect(jsonPath("$[0].assemblyPN", is("assemblyPN1")))
				.andExpect(jsonPath("$[0].calibration", is("calibration1")))
				.andExpect(jsonPath("$[0].catchWord", is("catchWord1")))
				.andExpect(jsonPath("$[0].drcdsId", is("drcdsId1"))).andExpect(jsonPath("$[0].notice", is("notice1")))
				.andExpect(jsonPath("$[0].releaseUsage", is("releaseUsage1")))
				.andExpect(jsonPath("$[0].hardwarePN", is("hardwarePN1")))
				.andExpect(jsonPath("$[0].coreHardwarePN", is("coreHardwarePN1")))
				.andExpect(jsonPath("$[0].mainMicroType", is("mainMicroType1")))
				.andExpect(jsonPath("$[0].supplier", is("supplier1")))
				.andExpect(jsonPath("$[0].coreHwEng", is("coreHwEng1")))
				.andExpect(jsonPath("$[0].softwarePN", is("softwarePN1")))
				.andExpect(jsonPath("$[0].mainStrategy", is("mainStrategy1")))
				.andExpect(jsonPath("$[0].chipId", is("chipId1")))
				.andExpect(jsonPath("$[0].calibrator", is("calibrator1")))
				.andExpect(jsonPath("$[0].lineage", is("lineage1")))
				.andExpect(jsonPath("$[0].groupedFirmwares", hasSize(2)))
				.andExpect(jsonPath("$[0].groupedFirmwares[0].category", is("category1")))
				.andExpect(jsonPath("$[0].groupedFirmwares[1].category", is("category2")));
	}

	@Test
	void testFetchFirmwareDetailsByPartNumber() throws Exception {
		// Arrange: Prepare mock data for PartDetail and PartNumberSearchResponse
		List<PartDetail> partDetails = List.of(
				new PartDetail("assemblyPN1", "hardwarePN1", "supplier1", "catchWord1", "calibNum1", "status1",
						"2023-01-01", "releaseType1", "releaseUsage1", "wersConcernDesc1", "concernNumber1",
						"softwarePN1", "comments1", "buildLevel1", "releasePriority1", "releasePriorityDetail1"),
				new PartDetail("assemblyPN2", "hardwarePN2", "supplier2", "catchWord2", "calibNum2", "status2",
						"2023-01-02", "releaseType2", "releaseUsage2", "wersConcernDesc2", "concernNumber2",
						"softwarePN2", "comments2", "buildLevel2", "releasePriority2", "releasePriorityDetail2"));

		PartNumberSearchResponse response = new PartNumberSearchResponse("concernNumber1", partDetails);

		// Prepare a PartNumberSearchRequest with a list of release types
		PartNumberSearchRequest searchRequest = new PartNumberSearchRequest(List.of("releaseType1", "releaseType2"),
				"moduleType1", "releaseUsage1", "assemblyPN1", "hardwarePN1", "softwarePN1", "appEng1", "catchWord1",
				"calibrationNum1", "mainStrategy1", "concernNumber1", "reldF1", "2023-01-01", "2023-12-31",
				"2023-01-01", "2023-12-31");

		// Mock the service to return the above response
		when(searchDataService.fetchFirmwareDetailsByPartNumber(searchRequest)).thenReturn(List.of(response));

		// Act: Perform POST request with the PartNumberSearchRequest and verify the
		// response
		mockMvc.perform(post("/api/v1/search/part-number").contentType(MediaType.APPLICATION_JSON)
				.content("{" + "\"releaseTypes\": [\"releaseType1\", \"releaseType2\"],"
						+ "\"moduleType\": \"moduleType1\"," + "\"releaseUsage\": \"releaseUsage1\","
						+ "\"assemblyPN\": \"assemblyPN1\"," + "\"hardwarePN\": \"hardwarePN1\","
						+ "\"softwarePN\": \"softwarePN1\"," + "\"appEng\": \"appEng1\","
						+ "\"catchWord\": \"catchWord1\"," + "\"calibrationNum\": \"calibrationNum1\","
						+ "\"mainStrategy\": \"mainStrategy1\"," + "\"concernNumber\": \"concernNumber1\","
						+ "\"reldF\": \"reldF1\"," + "\"createdDateFrom\": \"2023-01-01\","
						+ "\"createdDateTo\": \"2023-12-31\"," + "\"releasedDateFrom\": \"2023-01-01\","
						+ "\"releasedDateTo\": \"2023-12-31\"" + "}"))
				.andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(1)))
				.andExpect(jsonPath("$[0].concernNumber", is("concernNumber1")))
				.andExpect(jsonPath("$[0].parts", hasSize(2)))
				.andExpect(jsonPath("$[0].parts[0].assemblyPN", is("assemblyPN1")))
				.andExpect(jsonPath("$[0].parts[0].hardwarePN", is("hardwarePN1")))
				.andExpect(jsonPath("$[0].parts[1].assemblyPN", is("assemblyPN2")));
	}

	@Test
	void testFetchReleaseRequests() throws Exception {
		// Arrange: Prepare mock data for ReleaseRequestOutput
		ReleaseRequestOutput releaseRequest1 = new ReleaseRequestOutput(1L, "module1", "rLevel1", "2023", "prog1",
				"engine1", "status1", "2023-01-01", "owner1");

		ReleaseRequestOutput releaseRequest2 = new ReleaseRequestOutput(2L, "module2", "rLevel2", "2024", "prog2",
				"engine2", "status2", "2024-01-01", "owner2");

		List<ReleaseRequestOutput> releaseRequestList = List.of(releaseRequest1, releaseRequest2);

		// Prepare ReleaseRequestSearchInput with mock search parameters
		ReleaseRequestSearchInput searchInput = new ReleaseRequestSearchInput(1L, "module1", "rLevel1", "status1",
				"owner1", "2023", "prog1", "engine1", "createUser1", "lastUpdateUser1");

		// Mock the service to return the mock list of ReleaseRequestOutput
		when(searchDataService.fetchReleaseRequests(searchInput)).thenReturn(releaseRequestList);

		// Act: Perform POST request with the ReleaseRequestSearchInput and verify the
		// response
		mockMvc.perform(post("/api/v1/search/release-request").contentType(MediaType.APPLICATION_JSON)
				.content("{" + "\"id\": 1," + "\"moduleTypeCode\": \"module1\"," + "\"calibrationLevel\": \"rLevel1\","
						+ "\"status\": \"status1\"," + "\"owner\": \"owner1\"," + "\"modelYear\": \"2023\","
						+ "\"program\": \"prog1\"," + "\"engine\": \"engine1\"," + "\"createUser\": \"createUser1\","
						+ "\"lastUpdateUser\": \"lastUpdateUser1\"" + "}"))
				.andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].id", is(1)))
				.andExpect(jsonPath("$[0].module", is("module1"))).andExpect(jsonPath("$[0].status", is("status1")))
				.andExpect(jsonPath("$[1].id", is(2))).andExpect(jsonPath("$[1].module", is("module2")))
				.andExpect(jsonPath("$[1].status", is("status2")));
	}

	@Test
	void testFetchProductionPartNumber() throws Exception {
		// Arrange: Create mock response data
		ProductionPartNumberSearchResponse part1 = new ProductionPartNumberSearchResponse("part001", "catchword1",
				"calib001", "software001", "hardware001", "microType001", "wersNotice001");

		ProductionPartNumberSearchResponse part2 = new ProductionPartNumberSearchResponse("part002", "catchword2",
				"calib002", "software002", "hardware002", "microType002", "wersNotice002");

		List<ProductionPartNumberSearchResponse> mockResponse = List.of(part1, part2);

		// Prepare the request body for ProductionPartNumberSearchRequest
		ProductionPartNumberSearchRequest searchRequest = new ProductionPartNumberSearchRequest("part001",
				"wersNotice001", "catchword1", "software001", "calib001", "stratRel001", "chipId001");

		// Mock the service to return the mock response when fetchProductionPartNumber
		// is called
		when(searchDataService.fetchProductionPartNumber(searchRequest)).thenReturn(mockResponse);

		// Act: Perform a POST request to /production-part-number and verify the
		// response
		mockMvc.perform(post("/api/v1/search/production-part-number") // Replace with actual URL mapping
				.contentType(MediaType.APPLICATION_JSON)
				.content("{" + "\"partNumber\": \"part001\"," + "\"wersNotice\": \"wersNotice001\","
						+ "\"catchWord\": \"catchword1\"," + "\"softwarePartNumber\": \"software001\","
						+ "\"calibrationNumber\": \"calib001\"," + "\"stratRelName\": \"stratRel001\","
						+ "\"chipId\": \"chipId001\"" + "}"))
				.andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(2)))
				.andExpect(jsonPath("$[0].partNumber", is("part001")))
				.andExpect(jsonPath("$[0].catchWord", is("catchword1")))
				.andExpect(jsonPath("$[1].partNumber", is("part002")))
				.andExpect(jsonPath("$[1].catchWord", is("catchword2")));
	}

	@Test
	void testFetchWersTextByConcern() throws Exception {
		// Arrange: Define the expected WERS text for the given concern
		String wersConcern = "concern123";
		String expectedWersText = "This is the WERS text for concern 123";

		// Mock the service to return the expected WERS text
		when(searchDataService.fetchWersTextByConcern(wersConcern)).thenReturn(expectedWersText);

		// Act: Perform a GET request with the specific wersConcern
		mockMvc.perform(get("/api/v1/search/wers-text/wers-concern/{wersConcern}", wersConcern))
				.andExpect(status().isOk());

	}

	@Test
	void testFetchReleaseStatusDetailsByWersConcern() throws Exception {
		// Arrange: Define the test data for the given WERS Concern
		String wersConcern = "concern123";

		// Define the expected response data
		ReleaseStatusConcernResponse response = new ReleaseStatusConcernResponse("assemblyPN123", "calibration123",
				"drcdsId123", "hardwarePN123", "coreHardwarePN123", "mainMicroType123", "softwarePN123",
				"mainStrategy123", "chipD123", List.of(new LookupProgramDescriptionDto(1L, "2023", "program1",
						"platform1", "engine1", "transmission1")),
				"lineage123", new ReleaseStatusDetails("Active", "Completed"));

		// Mock the service to return the expected response
		when(searchDataService.fetchReleaseStatusDetailsByWersConcern(wersConcern)).thenReturn(List.of(response));

		// Act: Perform a GET request with the specified WERS concern
		mockMvc.perform(get("/api/v1/search/release-status/wers-concern/{wersConcern}", wersConcern))
				.andExpect(status().isOk()).andExpect(jsonPath("$[0].assemblyPN", is("assemblyPN123")))
				.andExpect(jsonPath("$[0].calibration", is("calibration123")))
				.andExpect(jsonPath("$[0].drcdsId", is("drcdsId123")))
				.andExpect(jsonPath("$[0].hardwarePN", is("hardwarePN123")))
				.andExpect(jsonPath("$[0].coreHardwarePN", is("coreHardwarePN123")))
				.andExpect(jsonPath("$[0].mainMicroType", is("mainMicroType123")))
				.andExpect(jsonPath("$[0].softwarePN", is("softwarePN123")))
				.andExpect(jsonPath("$[0].mainStrategy", is("mainStrategy123")))
				.andExpect(jsonPath("$[0].chipD", is("chipD123"))).andExpect(jsonPath("$[0].lineage", is("lineage123")))
				.andExpect(jsonPath("$[0].statusDetails.statusDescription", is("Active")))
				.andExpect(jsonPath("$[0].statusDetails.statusValue", is("Completed")));
	}

}
