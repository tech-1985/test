package com.ford.gpcse.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ford.gpcse.bo.FirmwareResponse;
import com.ford.gpcse.bo.GroupedFirmwareSearchResponse;
import com.ford.gpcse.dto.FirmwareDto;
import com.ford.gpcse.exception.ProgramSearchLimitExceedException;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.repository.FirmwareRepository;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.ProgramDescriptionRepository;
import com.ford.gpcse.repository.ProgramPartRepository;
import com.ford.gpcse.repository.ReleaseRequestRepository;
import com.ford.gpcse.repository.SignoffRepository;

class SearchDataServiceImplTest {

	@Mock
	private PartRepository partRepository;
	@Mock
	private ReleaseRequestRepository releaseRequestRepository;
	@Mock
	private PartFirmwareRepository partFirmwareRepository;
	@Mock
	private ProgramDescriptionRepository programDescriptionRepository;
	@Mock
	private ProgramPartRepository programPartRepository;
	@Mock
	private SignoffRepository signoffRepository;
	@Mock
	private FirmwareRepository firmwareRepository;

	@InjectMocks
	private SearchDataServiceImpl searchDataServiceImpl;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testFetchFirmwareDetailsByWersConcern_ValidData() {
		// Arrange: Prepare the test data and mock behavior of the repository
		String wersConcern = "ValidConcern";

		FirmwareDto firmwareDto = new FirmwareDto("PartR123", "PartNumX456", "CalibrationA", "StratRelC",
				"EngineerCdsidC123", "HardwarePartR789", "MicroTypX", "ChipD987", "StratCalibPartR", "CatchWordC",
				"RelUsgX", "RelTypX", "WersNtcR", "ConcernC", "CmtX", "PwrtrnCalibCdsidC", "SuplX",
				"CoreHardwareCdsidC", "CoreHardwarePartR");
		List<FirmwareDto> firmwareDtos = Arrays.asList(firmwareDto);

		when(partRepository.fetchFirmwareDetailsByWersConcern(wersConcern)).thenReturn(Optional.of(firmwareDtos));

		// Act: Call the method being tested
		List<GroupedFirmwareSearchResponse> result = searchDataServiceImpl
				.fetchFirmwareDetailsByWersConcern(wersConcern);

		// Assert: Verify the result
		assertNotNull(result);
		assertEquals(1, result.size());
		GroupedFirmwareSearchResponse groupedResponse = result.get(0);
		assertEquals("RelTypX", groupedResponse.releaseType());
		assertEquals("RelUsgX", groupedResponse.releaseUsage());
		assertEquals("ConcernC", groupedResponse.concern());
		assertEquals("CmtX", groupedResponse.wersConcernDescription());
		assertEquals(1, groupedResponse.firmwareResponses().size());

	}
	
	@Test
	void testFetchFirmwareDetailsByWersConcern_NotValidData() {
		// Arrange: Prepare the test data and mock behavior of the repository
		String wersConcern = "ValidConcern";

		FirmwareDto firmwareDto = new FirmwareDto("PartR123", "PartNumX456", "CalibrationA", "StratRelC",
				"EngineerCdsidC123", "HardwarePartR789", "MicroTypX", "ChipD987", "StratCalibPartR", "CatchWordC",
				"RelUsgX", "RelTypX", "WersNtcR", "ConcernC", "CmtX", "PwrtrnCalibCdsidC", "SuplX",
				"CoreHardwareCdsidC", "CoreHardwarePartR");
		List<FirmwareDto> firmwareDtos = Arrays.asList(firmwareDto);

		when(partRepository.fetchFirmwareDetailsByWersConcern(wersConcern)).thenReturn(Optional.of(firmwareDtos));

		// Act & Assert: Verify that a ResourceNotFoundException is thrown
				assertThrows(ResourceNotFoundException.class, () -> {
					searchDataServiceImpl.fetchFirmwareDetailsByWersConcern("InvalidConcern");
				}, "No Release was found.  Please try again.");

	}

	@Test
	void testFetchFirmwareDetailsByWersNotice_ValidData() {
		// Arrange: Prepare the test data and mock behavior of the repository
		String wersNotice = "ValidNotice";

		FirmwareDto firmwareDto = new FirmwareDto("PartR123", "PartNumX456", "CalibrationA", "StratRelC",
				"EngineerCdsidC123", "HardwarePartR789", "MicroTypX", "ChipD987", "StratCalibPartR", "CatchWordC",
				"RelUsgX", "RelTypX", "WersNtcR", "ConcernC", "CmtX", "PwrtrnCalibCdsidC", "SuplX",
				"CoreHardwareCdsidC", "CoreHardwarePartR");
		List<FirmwareDto> firmwareDtos = Arrays.asList(firmwareDto);

		when(partRepository.fetchFirmwareDetailsByWersNotice(any())).thenReturn(Optional.of(firmwareDtos));

		// Act: Call the method being tested
		List<GroupedFirmwareSearchResponse> result = searchDataServiceImpl.fetchFirmwareDetailsByWersNotice(wersNotice);

		// Assert: Verify the result
		assertNotNull(result);
		assertEquals(1, result.size());
		GroupedFirmwareSearchResponse groupedResponse = result.get(0);
		assertEquals("RelTypX", groupedResponse.releaseType());
		assertEquals("RelUsgX", groupedResponse.releaseUsage());
		assertEquals(1, groupedResponse.firmwareResponses().size());

	}

	@Test
	void testFetchFirmwareDetailsByWersNotice_NotValidData() {
		// Arrange: Prepare the test data and mock behavior of the repository
		String wersNotice = "ValidNotice";

		FirmwareDto firmwareDto = new FirmwareDto("PartR123", "PartNumX456", "CalibrationA", "StratRelC",
				"EngineerCdsidC123", "HardwarePartR789", "MicroTypX", "ChipD987", "StratCalibPartR", "CatchWordC",
				"RelUsgX", "RelTypX", "WersNtcR", "ConcernC", "CmtX", "PwrtrnCalibCdsidC", "SuplX",
				"CoreHardwareCdsidC", "CoreHardwarePartR");
		List<FirmwareDto> firmwareDtos = Arrays.asList(firmwareDto);

		when(partRepository.fetchFirmwareDetailsByWersNotice(wersNotice)).thenReturn(Optional.of(firmwareDtos));

		// Act & Assert: Verify that a ResourceNotFoundException is thrown
		assertThrows(ResourceNotFoundException.class, () -> {
			searchDataServiceImpl.fetchFirmwareDetailsByWersNotice(wersNotice);
		}, "No Release was found.  Please try again.");
	}

	@Test
	void testFetchFirmwareDetailsByPrograms_LimitExceeded() {
		// Arrange: Create a list of 10 or more program keys
		List<Long> programKeys = Arrays.asList(1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L, 9L, 10L); // 10 program keys

		// Act & Assert: Verify that a ProgramSearchLimitExceedException is thrown
		assertThrows(ProgramSearchLimitExceedException.class, () -> {
			searchDataServiceImpl.fetchFirmwareDetailsByPrograms(programKeys);
		}, "Please select less than 10 programs.");
	}

	@Test
	void testFetchFirmwareDetailsByPrograms_NoProgramsFound() {
		// Arrange: Create a list of valid program keys
		List<Long> programKeys = Arrays.asList(1L, 2L, 3L); // valid program keys

		// Mock the partRepository to return an empty Optional
		when(partRepository.fetchFirmwareDetailsByPrograms(programKeys)).thenReturn(Optional.empty());

		// Act & Assert: Verify that a ResourceNotFoundException is thrown
		assertThrows(ResourceNotFoundException.class, () -> {
			searchDataServiceImpl.fetchFirmwareDetailsByPrograms(programKeys);
		}, "No Programs");
	}

	@Test
	void testFetchFirmwareDetailsByPrograms_ValidResponse() {
		// Arrange: Create a list of valid program keys
		List<Long> programKeys = Arrays.asList(1L, 2L, 3L); // valid program keys

		// Create a sample FirmwareDto (instead of FirmwareResponse as in previous
		// example)
		FirmwareDto firmwareDto = new FirmwareDto("partR123", "partNumX", "calibR", "stratRelC", "engineerCdsidC",
				"hardwarePartR", "microTypX", "chipD", "stratCalibPartR", "catchWordC", "relUsgX", "relTypX",
				"wersNtcR", "concernC", "cmtX", "pwrtrnCalibCdsidC", "suplX", "coreHardwareCdsidC",
				"coreHardwarePartR");
		List<FirmwareDto> firmwareDtos = Arrays.asList(firmwareDto);

		// Mock the partRepository to return a valid Optional of a list of FirmwareDto
		when(partRepository.fetchFirmwareDetailsByPrograms(programKeys)).thenReturn(Optional.of(firmwareDtos));

		// Act: Call the method under test
		List<FirmwareResponse> result = searchDataServiceImpl.fetchFirmwareDetailsByPrograms(programKeys);

		// Assert: Verify the result contains the expected FirmwareResponse
		assertNotNull(result, "Expected result to be non-null.");
		assertEquals(1, result.size(), "Expected list to contain one FirmwareResponse.");
		FirmwareResponse response = result.get(0);

		// Assert internal fields of the FirmwareResponse object
		assertEquals("partR123", response.assemblyPN());
		assertEquals("calibR", response.calibration());
		assertEquals("catchWordC", response.catchWord());
		assertEquals("relUsgX", response.releaseUsage());
		assertEquals("hardwarePartR", response.hardwarePN());
		assertEquals("coreHardwarePartR", response.coreHardwarePN());
		assertEquals("microTypX", response.mainMicroType());
		assertEquals("chipD", response.chipId());
		assertEquals("relTypX", response.releaseType());
		assertEquals("concernC", response.concern());
		assertEquals("cmtX", response.wersConcernDescription());
	}

}
