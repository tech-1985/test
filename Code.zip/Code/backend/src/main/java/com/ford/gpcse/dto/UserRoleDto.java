package com.ford.gpcse.dto;

public record UserRoleDto(String firstName, String lastName, String email, String supplierName) {
}
