package com.ford.gpcse.dto;

public record ModuleBaseInformationDto(String partR, String concernC, String statC) {
}
