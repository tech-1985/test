package com.ford.gpcse.bo;

public record ProductionPartNumberSearchResponse(String partNumber, String catchWord, String calibrationNumber,
		String softwarePN, String hardwarePN, String mainMicroType, String wersNotice) {
}
