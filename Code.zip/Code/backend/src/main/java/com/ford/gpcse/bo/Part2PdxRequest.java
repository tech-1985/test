package com.ford.gpcse.bo;

public record Part2PdxRequest(String releaseType, String moduleTypeCode, Long microTypeCode, String createUser,
		String lastUpdateUser, String ggdsVersion, String swdlVersion, String partNumber, String description,
		String uploadedToVSEM) {
}
