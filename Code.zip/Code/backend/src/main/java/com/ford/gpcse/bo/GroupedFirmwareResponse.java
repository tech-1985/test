package com.ford.gpcse.bo;

import java.util.List;

import com.ford.gpcse.dto.LookupPartFirmwareDto;

public record GroupedFirmwareResponse(String category, List<LookupPartFirmwareDto> firmwares) {
}
