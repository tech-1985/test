package com.ford.gpcse.exception;

import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.ford.gpcse.bo.ErrorResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {

	private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleResourceNotFoundException(ResourceNotFoundException ex,
			WebRequest request) {
		log.error("Resource not found: {}", ex.getMessage(), ex);
		return buildErrorResponse(ex.getMessage(), request, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InvalidInputException.class)
	public ResponseEntity<ErrorResponse> handleInvalidInputException(InvalidInputException ex, WebRequest request) {
		log.error("Invalid input: {}", ex.getMessage(), ex);
		return buildErrorResponse(ex.getMessage(), request, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({ FirmwareAlreadyRequestedException.class, UnusedReleaseException.class,
			ResourceAlreadyExistException.class, InvalidPartNumberException.class,
			ProgramSearchLimitExceedException.class, UnableToUpdateException.class,
			MicroTypeAlreadyRequestedException.class, UnableToInsertException.class,
			UnableToSendEmailNotification.class, IllegalArgumentException.class })
	public ResponseEntity<ErrorResponse> handleConflictExceptions(Exception ex, WebRequest request) {
		log.error("Conflict error: {}", ex.getMessage(), ex);
		return buildErrorResponse(ex.getMessage(), request, HttpStatus.CONFLICT);
	}

	@ExceptionHandler(SQLException.class)
	public ResponseEntity<ErrorResponse> handleSQLException(SQLException ex, WebRequest request) {
		log.error("SQL Exception occurred at URI: {}. Error: {}", ex.getMessage(), ex);
		return buildErrorResponse("A database error occurred. Please contact support.", request,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(SQLSyntaxErrorException.class)
	public ResponseEntity<ErrorResponse> handleSQLSyntaxError(SQLSyntaxErrorException ex, WebRequest request) {
		log.error("SQL Syntax error: {}", ex.getMessage(), ex);
		return buildErrorResponse("There was an issue with the database query. Please try again later.", request,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(AuthServiceException.class)
	public ResponseEntity<ErrorResponse> handleAuthServiceException(Exception ex, WebRequest request) {
		log.error("Auth Service Exception: {}", ex.getMessage(), ex);
		return buildErrorResponse(ex.getMessage(), request, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(VsemServiceException.class)
	public ResponseEntity<ErrorResponse> handleVsemServiceException(Exception ex, WebRequest request) {
		log.error("Vsem Service Exception: {}", ex.getMessage(), ex);
		return buildErrorResponse(ex.getMessage(), request, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> handleGlobalException(Exception ex, WebRequest request) {
		log.error("Unexpected error occurred: {}", ex.getMessage(), ex);
		return buildErrorResponse("An unexpected error occurred. Please try again later.", request,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private ResponseEntity<ErrorResponse> buildErrorResponse(String message, WebRequest request, HttpStatus status) {
		ErrorResponse.Details details = new ErrorResponse.Details(request.getDescription(false), LocalDateTime.now());
		ErrorResponse errorResponse = new ErrorResponse("error", message, details);
		return new ResponseEntity<>(errorResponse, status);
	}
}
