package com.ford.gpcse.bo;

public record PrismDataInputResponse(String calibPartNumber, String part2PartNumber, String inputFile,
		String pdxPartNumber, String catchWord, String chipId, String comments, String engineSize, String hardwarePn,
		String modulePn, String vehicleAppl, String vehicleCal, String wersNotice) {
}
