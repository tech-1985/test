package com.ford.gpcse.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.gpcse.common.Constants;
import com.ford.gpcse.entity.Firmware;

/**
 * Repository interface for managing Firmware entities. This interface extends
 * JpaRepository to provide CRUD operations.
 */
@Repository
public interface FirmwareRepository extends JpaRepository<Firmware, Long> {

	/**
	 * Fetches the file name associated with a specific part number and firmware
	 * name pattern.
	 *
	 * @param partNumber       The part number to filter by
	 * @param firmwareNameLike The firmware name pattern to match
	 * @return The file name associated with the specified part and firmware name
	 *         pattern
	 */
	@Query("SELECT pf.fileN FROM PartFirmware pf " + "JOIN pf.firmware fw "
			+ "WHERE fw.firmwareN LIKE :firmwareNameLike " + "AND pf.part.partR = :partR")
	String fetchFileN(@Param(Constants.PART_R) String partNumber, @Param("firmwareNameLike") String firmwareNameLike);

	/**
	 * Fetches a list of Firmware entities associated with a specific release type.
	 *
	 * @param releaseType The release type to filter by
	 * @return A list of Firmware entities associated with the specified release
	 *         type
	 */
	@Query("SELECT f FROM Firmware f WHERE f.selGrpR > 0 "
			+ "AND f.firmwareK IN (SELECT r.firmware.firmwareK FROM ReleaseTypeFirmware r WHERE r.releaseType.relTypC = :releaseType) "
			+ "ORDER BY f.sortOrdR, f.firmwareN")
	Optional<List<Firmware>> fetchFirmwaresByReleaseType(@Param("releaseType") String releaseType);

	/**
	 * Fetches a list of Firmware entities based on a module type code and a
	 * firmware type pattern.
	 *
	 * @param moduleTypeCode The module type code to filter by
	 * @param firmwareType   The firmware type pattern to match
	 * @return A list of Firmware entities matching the specified criteria
	 */
	@Query("SELECT f FROM Firmware f INNER JOIN ReleaseTypeFirmware rt ON f.firmwareK = rt.firmware.firmwareK "
			+ "WHERE f.firmwareN LIKE %:firmwareType% AND rt.releaseType.relTypC IN (SELECT p.releaseType.relTypC FROM Part p WHERE p.moduleType.moduleTypC = :moduleTypeCode)")
	Optional<List<Firmware>> fetchFirmwareByModuleTypeCode(@Param("moduleTypeCode") String moduleTypeCode,
			@Param("firmwareType") String firmwareType);

	/**
	 * Finds firmware column headers associated with specified part numbers.
	 *
	 * @param partNumbers A list of part numbers to filter by
	 * @return A list of objects representing firmware column headers for the
	 *         specified part numbers
	 */
	@Query(value = "SELECT DISTINCT tblA.PCMR03_FIRMWARE_K, tblA.PCMR03_FIRMWARE_N, tblA.PCMR03_SORT_ORD_R "
			+ "FROM WPCMR03_FIRMWARE tblA "
			+ "INNER JOIN WPCMR02_PART_FIRMWARE tblB ON tblA.PCMR03_FIRMWARE_K = tblB.PCMR03_FIRMWARE_K "
			+ "WHERE tblB.PCMR01_PART_R IN (:partNumbers) "
			+ "ORDER BY tblA.PCMR03_SORT_ORD_R, tblA.PCMR03_FIRMWARE_N", nativeQuery = true)
	List<Object[]> findFirmwareColumnHeaders(@Param("partNumbers") List<String> partNumbers);

	/**
	 * Finds firmware details for a specific part number where the approval status
	 * is null.
	 *
	 * @param partR The part number to filter by
	 * @return A list of objects representing firmware details for the specified
	 *         part number
	 */
	@Query(value = "SELECT tblFw.PCMR03_FIRMWARE_N, tblFw.PCMR03_FIRMWARE_K " + "FROM WPCMR02_PART_FIRMWARE tblFwJ "
			+ "INNER JOIN WPCMR03_FIRMWARE tblFw ON tblFwJ.PCMR03_FIRMWARE_K = tblFw.PCMR03_FIRMWARE_K "
			+ "WHERE tblFwJ.PCMR01_PART_R = :partR " + "AND tblFwJ.PCMR02_APRVD_Y IS NULL "
			+ "ORDER BY tblFw.PCMR03_SORT_ORD_R, tblFw.PCMR03_FIRMWARE_CATG_N, tblFw.PCMR03_FIRMWARE_N", nativeQuery = true)
	Optional<List<Object[]>> findFirmwareDetails(@Param("partR") String partR);
}
