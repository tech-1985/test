package com.ford.gpcse.common;

public class Constants {

	private Constants() {
		throw new UnsupportedOperationException("Constants class cannot be instantiated");
	}

	public static final String INITIAL_REQUEST = "Initial Request";
	public static final String FINAL_RESPONSE = "Final Response";

	public static final String PART_R = "partR";
	public static final String FIRMWARE_K = "firmwareK";

	public static final String SCHEMA_ATTRIBUTE = "xsi:nil";

	public static final String CODE = "Code";
	public static final String DESCRIPTION = "Description";

	public static final String REL_REQ_K = "relReqK";
}
