package com.ford.gpcse.service;

import org.springframework.core.io.Resource;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;

public interface FirmwareXmlExportV7Service {
	Resource generateFirmwareV7Xml(ExportFirmwareXmlRequest exportFirmwareXmlRequest);
}
