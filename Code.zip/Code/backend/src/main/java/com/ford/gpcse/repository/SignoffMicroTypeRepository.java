package com.ford.gpcse.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ford.gpcse.entity.SignoffMicroType;
import com.ford.gpcse.entity.SignoffMicroTypeId;

/**
 * Repository interface for accessing SignoffMicroType entities. Extends
 * JpaRepository to provide standard CRUD operations.
 */
public interface SignoffMicroTypeRepository extends JpaRepository<SignoffMicroType, SignoffMicroTypeId> {

	/**
	 * Updates the reqtY field of a SignoffMicroType entity to the current
	 * timestamp. The update occurs only for entries that match the given signoff
	 * type and micro type code, where signoffS and reqtY are both null.
	 *
	 * @param signoff the signoff type code to filter the update
	 * @param microId the micro type code to filter the update
	 */
	@Modifying
	@Transactional
	@Query("UPDATE SignoffMicroType s SET s.reqtY = CURRENT_TIMESTAMP " + "WHERE s.id.signoffTypC = :signoff "
			+ "AND s.signoffS IS NULL " + "AND s.reqtY IS NULL " + "AND s.id.microTypC = :microId")
	void updateSignoff(@Param("signoff") String signoff, @Param("microId") Long microId);
}
