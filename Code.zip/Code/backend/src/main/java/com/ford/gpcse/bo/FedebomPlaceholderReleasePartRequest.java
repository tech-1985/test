package com.ford.gpcse.bo;

import java.util.List;

public record FedebomPlaceholderReleasePartRequest(String moduleTypeCode, String releaseTypeCode, String userId,
		String sraComment, List<FedebomPlaceholderReleasePart> fedebomPlaceholderReleaseParts) {

}
