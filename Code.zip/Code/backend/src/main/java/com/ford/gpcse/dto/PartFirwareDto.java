package com.ford.gpcse.dto;

import com.ford.gpcse.entity.RelUsg;
import com.ford.gpcse.entity.ReleaseType;

public record PartFirwareDto(String partR, String partNumX, String calibPartR, String stratRelC, String engineerCdsidC,
		String hardwarePartR, String microTypX, String chipD, String stratCalibPartR, String catchWordC,
		RelUsg releaseUsage, ReleaseType releaseType, String stratPartR, String cmtX, String coreHardwarePartR,
		String concernC) {
}
