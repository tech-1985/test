package com.ford.gpcse.exception;

public class ResourceNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -5157631488449548375L;

	public ResourceNotFoundException(String message) {
		super(message);
	}

	public ResourceNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
}