package com.ford.gpcse.service.impl;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ford.gpcse.bo.FirmwareDetailsResponse;
import com.ford.gpcse.bo.MicroTypeView;
import com.ford.gpcse.bo.ModuleBaseInformation;
import com.ford.gpcse.bo.ModuleTypeView;
import com.ford.gpcse.bo.PartFirmwareResponse;
import com.ford.gpcse.bo.PrismDataInputResponse;
import com.ford.gpcse.bo.ReleaseRequestDetail;
import com.ford.gpcse.bo.ReleaseRequestOutput;
import com.ford.gpcse.bo.ReleaseStatus;
import com.ford.gpcse.bo.ReleaseTypeView;
import com.ford.gpcse.bo.ReleaseUsageView;
import com.ford.gpcse.bo.ReplacePblSearchRequest;
import com.ford.gpcse.bo.SupplierView;
import com.ford.gpcse.dto.MainMicroTypeDto;
import com.ford.gpcse.dto.PartFirwareDto;
import com.ford.gpcse.dto.ProgramDescriptionDto;
import com.ford.gpcse.dto.ReleaseDetailsDto;
import com.ford.gpcse.dto.ReleaseRequestDTO;
import com.ford.gpcse.dto.UserRoleDto;
import com.ford.gpcse.enums.ModuleTypeCode;
import com.ford.gpcse.enums.ReleaseTypeCode;
import com.ford.gpcse.enums.SignoffTypeCode;
import com.ford.gpcse.exception.FirmwareAlreadyRequestedException;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.exception.UnusedReleaseException;
import com.ford.gpcse.repository.FirmwareItemRepository;
import com.ford.gpcse.repository.FirmwareRepository;
import com.ford.gpcse.repository.MicroTypeRepository;
import com.ford.gpcse.repository.ModuleNameRepository;
import com.ford.gpcse.repository.ModuleTypeRepository;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.ProcessorRepository;
import com.ford.gpcse.repository.ProgramDescriptionRepository;
import com.ford.gpcse.repository.RelUsgRepository;
import com.ford.gpcse.repository.ReleaseRequestRepository;
import com.ford.gpcse.repository.ReleaseTypeRepository;
import com.ford.gpcse.repository.SignoffRepository;
import com.ford.gpcse.repository.SupplierRepository;
import com.ford.gpcse.repository.UserRoleRepository;
import com.ford.gpcse.service.LookupDataService;
import com.ford.gpcse.util.DateFormatterUtility;
import com.ford.gpcse.util.NoticeFormatterUtility;

@Service
public class LookupDataServiceImpl implements LookupDataService {

	private static final String DATE_FORMAT = "MM/dd/yyyy";
	private static final String SOFT_LOCK = "SoftLock";
	private static final String FIRMWARE_EDIT = "FirmwareEdit";
	private static final String HARD_LOCK = "HardLock";
	private static final Map<String, List<String>> moduleTypeToReleaseTypes = new HashMap<>();

	static {
		moduleTypeToReleaseTypes.put(ModuleTypeCode.PCM.name(),
				List.of(ReleaseTypeCode.AREUL.name(), ReleaseTypeCode.AFD.name(), ReleaseTypeCode.AFDCX.name(),
						ReleaseTypeCode.AFG.name(), ReleaseTypeCode.AFGO.name(), ReleaseTypeCode.ARNAL.name(),
						ReleaseTypeCode.HRDCN.name(), ReleaseTypeCode.HARDW.name(), ReleaseTypeCode.HWPT.name(),
						ReleaseTypeCode.PSUPR.name()));
		moduleTypeToReleaseTypes.put(ModuleTypeCode.GSM.name(), List.of(ReleaseTypeCode.GSMA.name()));
		moduleTypeToReleaseTypes.put(ModuleTypeCode.HPCM.name(),
				List.of(ReleaseTypeCode.HASM.name(), ReleaseTypeCode.HASMS.name()));
		moduleTypeToReleaseTypes.put(ModuleTypeCode.TCM.name(),
				List.of(ReleaseTypeCode.DPS6.name(), ReleaseTypeCode.UTCU2.name(), ReleaseTypeCode.HWUTC.name(),
						ReleaseTypeCode.TSUPS.name(), ReleaseTypeCode.HWPUT.name(), ReleaseTypeCode.HWCUT.name()));
		moduleTypeToReleaseTypes.put(ModuleTypeCode.TRCM.name(), List.of(ReleaseTypeCode.TRCMA.name()));
		moduleTypeToReleaseTypes.put(ModuleTypeCode.VCM.name(), List.of(ReleaseTypeCode.VCMA.name(),
				ReleaseTypeCode.VCMH.name(), ReleaseTypeCode.VCMHP.name(), ReleaseTypeCode.VCMHC.name()));
		moduleTypeToReleaseTypes.put(ModuleTypeCode.DCU.name(), List.of(ReleaseTypeCode.DCUA.name()));
		moduleTypeToReleaseTypes.put(ModuleTypeCode.DLCM.name(),
				List.of(ReleaseTypeCode.DLCMA.name(), ReleaseTypeCode.DLCMS.name()));
	}

	private final SupplierRepository supplierRepository;
	private final ModuleTypeRepository moduleTypeRepository;
	private final MicroTypeRepository microTypeRepository;
	private final ModuleNameRepository moduleNameRepository;
	private final ProcessorRepository processorRepository;
	private final ProgramDescriptionRepository programDescriptionRepository;
	private final ReleaseRequestRepository releaseRequestRepository;
	private final PartRepository partRepository;
	private final FirmwareItemRepository firmwareItemRepository;
	private final PartFirmwareRepository partFirmwareRepository;
	private final FirmwareRepository firmwareRepository;
	private final UserRoleRepository userRoleRepository;
	private final ReleaseTypeRepository releaseTypeRepository;
	private final RelUsgRepository relUsgRepository;
	private final SignoffRepository signoffRepository;

	public LookupDataServiceImpl(SupplierRepository supplierRepository, ModuleTypeRepository moduleTypeRepository,
			MicroTypeRepository microTypeRepository, ModuleNameRepository moduleNameRepository,
			ProcessorRepository processorRepository, ProgramDescriptionRepository programDescriptionRepository,
			ReleaseRequestRepository releaseRequestRepository, PartRepository partRepository,
			FirmwareItemRepository firmwareItemRepository, PartFirmwareRepository partFirmwareRepository,
			FirmwareRepository firmwareRepository, UserRoleRepository userRoleRepository,
			ReleaseTypeRepository releaseTypeRepository, RelUsgRepository relUsgRepository,
			SignoffRepository signoffRepository) {
		super();
		this.supplierRepository = supplierRepository;
		this.moduleTypeRepository = moduleTypeRepository;
		this.microTypeRepository = microTypeRepository;
		this.moduleNameRepository = moduleNameRepository;
		this.processorRepository = processorRepository;
		this.programDescriptionRepository = programDescriptionRepository;
		this.releaseRequestRepository = releaseRequestRepository;
		this.partRepository = partRepository;
		this.firmwareItemRepository = firmwareItemRepository;
		this.partFirmwareRepository = partFirmwareRepository;
		this.firmwareRepository = firmwareRepository;
		this.userRoleRepository = userRoleRepository;
		this.releaseTypeRepository = releaseTypeRepository;
		this.relUsgRepository = relUsgRepository;
		this.signoffRepository = signoffRepository;
	}

	@Override
	@Transactional(readOnly = true)
	public List<SupplierView> fetchActiveSuppliers() {
		var optionalSuppliers = supplierRepository.fetchActiveSuppliers();

		if (optionalSuppliers.isEmpty()) {
			throw new ResourceNotFoundException("No Suppliers were found");
		} else {
			var suppliers = optionalSuppliers.get();
			return suppliers.stream().map(supplier -> new SupplierView(supplier.getSuplC(), supplier.getSuplX()))
					.toList();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<ModuleTypeView> fetchActiveModuleTypes() {
		var optionalModuleTypes = moduleTypeRepository.fetchActiveModuleTypes();

		if (optionalModuleTypes.isEmpty()) {
			throw new ResourceNotFoundException("No Module Types were found");
		} else {
			var moduleTypes = optionalModuleTypes.get();
			return moduleTypes.stream()
					.map(moduleType -> new ModuleTypeView(moduleType.getModuleTypC(), moduleType.getModuleTypX()))
					.toList();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<ReleaseUsageView> fetchActiveReleaseUsages() {
		var optionalRelUsgs = relUsgRepository.fetchActiveReleaseUsages();

		if (optionalRelUsgs.isEmpty()) {
			throw new ResourceNotFoundException("No Release Usages were found");
		} else {
			var relUsgs = optionalRelUsgs.get();
			return relUsgs.stream().map(relUsg -> new ReleaseUsageView(relUsg.getRelUsgC(), relUsg.getRelUsgX()))
					.toList();
		}

	}

	@Override
	@Transactional(readOnly = true)
	public List<MicroTypeView> fetchReleasedMicroTypesByModuleType(String moduleTypeCode) {
		var optionalMicroTypes = microTypeRepository.fetchReleasedMicroTypesByModuleType(moduleTypeCode);

		if (optionalMicroTypes.isEmpty()) {
			throw new ResourceNotFoundException("No Micro Types were found for the given module type");
		} else {
			var microTypes = optionalMicroTypes.get();
			return microTypes.stream()
					.map(microType -> new MicroTypeView(microType.getMicroTypC(), microType.getMicroTypX())).toList();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<String> fetchReleaseTypesByModuleType(String moduleTypeCode) {
		var releaseTypes = moduleTypeToReleaseTypes.getOrDefault(moduleTypeCode, Collections.emptyList());

		if (releaseTypes.isEmpty()) {
			throw new ResourceNotFoundException("No Release Types were found for given module type");
		}
		return releaseTypes;
	}

	@Override
	@Transactional(readOnly = true)
	public List<String> fetchActiveModuleNames() {
		var optionalModuleNames = moduleNameRepository.fetchActiveModuleNames();
		if (optionalModuleNames.isEmpty()) {
			throw new ResourceNotFoundException("No Module Names were found");
		} else {
			return optionalModuleNames.get();
		}
	}

	@Override
	public List<String> fetchActiveMicroNames() {
		var optionalMicroNames = processorRepository.fetchActiveMicroNames();
		if (optionalMicroNames.isEmpty()) {
			throw new ResourceNotFoundException("No Micro Names were found");
		} else {
			return optionalMicroNames.get();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<ProgramDescriptionDto> fetchDistinctPrograms() {
		var optionalProgramDescriptions = programDescriptionRepository.fetchDistinctPrograms();
		if (optionalProgramDescriptions.isEmpty()) {
			throw new ResourceNotFoundException("No Programs were found");
		} else {
			return optionalProgramDescriptions.get();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<ReleaseRequestOutput> fetchAllReleaseRequests() {
		var optionalReleaseRequests = releaseRequestRepository.findAllByOrderByRelReqKDesc();
		if (optionalReleaseRequests.isEmpty()) {
			throw new ResourceNotFoundException("No Release Requests were found");
		} else {
			var releaseRequests = optionalReleaseRequests.get();
			return releaseRequests.stream()
					.map(releaseRequest -> new ReleaseRequestOutput(releaseRequest.getRelReqK(),
							releaseRequest.getModuleType().getModuleTypC(), releaseRequest.getCalRLevelR(),
							releaseRequest.getProgramReleaseRequests() != null
									&& !releaseRequest.getProgramReleaseRequests().isEmpty()
											? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription()
													.getMdlYrR()
											: null,
							releaseRequest.getProgramReleaseRequests() != null
									&& !releaseRequest.getProgramReleaseRequests().isEmpty()
											? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription()
													.getPgmN()
											: null,
							releaseRequest.getProgramReleaseRequests() != null
									&& !releaseRequest.getProgramReleaseRequests().isEmpty()
											? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription()
													.getEngN()
											: null,
							releaseRequest.getStatusC(),
							releaseRequest.getCreateS().format(DateTimeFormatter.ofPattern("MMM dd, yyyy")),
							releaseRequest.getCreateUserC()))
					.toList();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<ReleaseStatus> fetchReleaseStatusDetails() {
		var optionalReleaseStatuses = partRepository.fetchReleaseStatusDetails();
		if (optionalReleaseStatuses.isEmpty()) {
			throw new ResourceNotFoundException("No Release Status Details were found");
		} else {
			var releaseStatuses = optionalReleaseStatuses.get();
			return releaseStatuses.stream()
					.map(releaseStatus -> new ReleaseStatus(releaseStatus.concernC(), releaseStatus.partR(),
							releaseStatus.relTypX(), releaseStatus.statC(),
							DateFormatterUtility.formatDateMonthAbr(releaseStatus.concernY())))
					.toList();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<ModuleBaseInformation> fetchModuleBaseInformation(String userId) {
		var optionalModuleBaseInformations = partRepository.fetchModuleBaseInformation(userId);
		if (optionalModuleBaseInformations.isEmpty()) {
			throw new ResourceNotFoundException("No Module Base Information were found");
		} else {
			var moduleBaseInformations = optionalModuleBaseInformations.get();
			return moduleBaseInformations.stream()
					.map(moduleBaseInformation -> new ModuleBaseInformation(moduleBaseInformation.concernC(),
							moduleBaseInformation.partR()))
					.toList();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<PartFirmwareResponse> findPartsByFirmware(ReplacePblSearchRequest replacePblSearchRequest) {

		// Check if the current pbl exists
		var currentPblcount = partFirmwareRepository.countByfileN(replacePblSearchRequest.currentPbl());

		if (currentPblcount == 0) {
			throw new UnusedReleaseException(replacePblSearchRequest.currentPbl()
					+ " has not been used in a release. Please use new PBL request.");
		}

		// Check if the new pbl exists
		var newPblCount = firmwareItemRepository.countByFirmwareItmX(replacePblSearchRequest.newPbl());

		if (newPblCount > 0) {
			throw new FirmwareAlreadyRequestedException(
					replacePblSearchRequest.newPbl() + "  has already been requested.");
		}

		// fetch the PBL records
		var optionalParts = partRepository.fetchPartsByFirmware(replacePblSearchRequest.currentPbl(),
				List.of("BCCMH", "BCMBH", "BCMIH", "BECMH", "HWPT", "HWUTC", "HWPUT", "HWCUT", "HARDW", "HRDCN",
						"PMSEH", "NXTPH", "NXFGH", "NXMBH", "UCLSH", "GPCMH", "AWDHH", "HPCMH", "TCCMH", "DCUH", "GDMH",
						"DLCMH", "TRCMH", "VCMH", "VCMHP", "VCMHC"));

		if (optionalParts.isEmpty()) {
			return Collections.emptyList();
		} else {
			return convertToPartFirmwareResponse(optionalParts.get());
		}
	}

	@Override
	@Transactional(readOnly = true)
	public PrismDataInputResponse fetchPrismInputDataByPartNumber(String partNumber) {
		var optionalPrismInputDetails = partRepository.fetchPrismInputDataByPartNumber(partNumber);

		if (optionalPrismInputDetails.isEmpty()) {
			throw new ResourceNotFoundException("No records found for the given part number.");
		} else {
			var prismInputDetails = optionalPrismInputDetails.get();
			return new PrismDataInputResponse(prismInputDetails[1].toString(),
					firmwareRepository.fetchFileN(prismInputDetails[0].toString(), "%Part II%"),
					prismInputDetails[3].toString().toUpperCase(),
					firmwareRepository.fetchFileN(prismInputDetails[0].toString(), "%PDX%"),
					prismInputDetails[7].toString().toUpperCase(), prismInputDetails[5].toString().toUpperCase(),
					prismInputDetails[9].toString().toUpperCase(), prismInputDetails[13].toString().toUpperCase(),
					prismInputDetails[6].toString(), removePFromPrefix(prismInputDetails[0].toString().toUpperCase()),
					prismInputDetails[11].toString().toUpperCase(), prismInputDetails[1].toString().toUpperCase(),
					NoticeFormatterUtility.formatWersNotice(prismInputDetails[2].toString().toUpperCase()));
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<FirmwareDetailsResponse> fetchFirmwareDetailsByReleaseType(String releaseType) {
		var optionalFirmwares = firmwareRepository.fetchFirmwaresByReleaseType(releaseType);
		if (optionalFirmwares.isEmpty()) {
			throw new ResourceNotFoundException("No records found.");
		}
		var firmwares = optionalFirmwares.get();
		return firmwares.stream().map(firmware -> {
			var optionalUserRoles = userRoleRepository.fetchUserRolesByFirmwareKey(firmware.getFirmwareK());
			List<UserRoleDto> userRoles = new ArrayList<>();
			optionalUserRoles
					.ifPresent(
							roles -> roles.stream().map(
									userRole -> userRole.supplierName() == null || userRole.supplierName().isEmpty()
											? new UserRoleDto(userRole.firstName(), userRole.lastName(),
													userRole.email(), "All Suppliers")
											: userRole)
									.forEach(userRoles::add));
			return new FirmwareDetailsResponse(firmware.getFirmwareN(), firmware.getFirmwareX(),
					firmware.getRevwRespC(), userRoles);
		}).toList();
	}

	@Override
	@Transactional(readOnly = true)
	public List<ReleaseTypeView> fetchActiveReleaseTypes() {
		var optionalReleaseTypes = releaseTypeRepository.fetchActiveReleaseTypes();
		if (optionalReleaseTypes.isEmpty()) {
			throw new ResourceNotFoundException("No Release Types were found");
		} else {
			var releaseTypes = optionalReleaseTypes.get();
			return releaseTypes.stream()
					.map(releaseType -> new ReleaseTypeView(releaseType.getRelTypC(), releaseType.getRelTypX()))
					.toList();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<String> fetchAllProgramsWhichHasPartNumber() {
		var optionalResults = programDescriptionRepository.fetchAllProgramsWhichHasPartNumber();
		if (optionalResults.isEmpty()) {
			throw new ResourceNotFoundException("No Programs were found");
		} else {
			var results = optionalResults.get();
			return results.stream().map(arr -> arr[0] + " " + arr[1]).toList();
		}
	}

	@Override
	@Transactional(readOnly = true)
	public ReleaseRequestDetail fetchReleaseRequestDetailsById(Long id) {
		var optionalReleaseRequest = releaseRequestRepository.findByRelReqK(id);
		if (optionalReleaseRequest.isEmpty()) {
			throw new ResourceNotFoundException("No Release Requests were found");
		} else {
			var releaseRequest = optionalReleaseRequest.get();
			return new ReleaseRequestDetail(String.valueOf(releaseRequest.getRelReqK()),
					releaseRequest.getCreateUserC(), releaseRequest.getStatusC(),
					releaseRequest.getModuleType().getModuleTypC(), releaseRequest.getPrtyC(),
					releaseRequest.getPrtyDtlX(), releaseRequest.getRelReqReasonX(),
					releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getPgmN(),
					releaseRequest.getCalRLevelR(), releaseRequest.getCoordReqF(), releaseRequest.getStratRelC(),
					releaseRequest.getBackCompatF(), releaseRequest.getBldLvlC(),
					releaseRequest.getCalRelY().format(DateTimeFormatter.ofPattern(DATE_FORMAT)),
					releaseRequest.getProjectControlC(), releaseRequest.getReleaseUsage().getRelUsgC(),
					releaseRequest.getReleaseTitleX(), releaseRequest.getCalNumCcmR(),
					releaseRequest.getAddHwSwCoordF(), releaseRequest.getHwSwCoordDetailX(),
					releaseRequest.getAlertRequiredF(), releaseRequest.getAlertDetailX(),
					releaseRequest.getRollPartChangeUsageF(), releaseRequest.getRollPartChangeUsageX(),
					releaseRequest.getBuildStartY().format(DateTimeFormatter.ofPattern(DATE_FORMAT)),
					releaseRequest.getSuppVbfDelY().format(DateTimeFormatter.ofPattern(DATE_FORMAT)),
					releaseRequest.getAppDrEngC(), releaseRequest.getCalEngC(), releaseRequest.getCalRelSupportC(),
					releaseRequest.getHardwarePartR(), releaseRequest.getIpfInstalledPartR(),
					releaseRequest.getServicePartR());
		}
	}

	@Override
	@Transactional(readOnly = true)
	public Map<String, List<ReleaseRequestDTO>> fetchReleaseRequestDetailsByUserId(String userId) {
		var releaseRequestResults = releaseRequestRepository.findReleaseRequestsByUserId(userId);
		if (isValidList(releaseRequestResults)) {
			List<ReleaseRequestDTO> releaseRequests = releaseRequestResults.stream()
					.map(row -> new ReleaseRequestDTO(String.valueOf(row[0]), (String) row[1], (String) row[2],
							DateFormatterUtility.dateTimeStringInMMDDYYYY((Date) row[3]),
							DateFormatterUtility.dateTimeStringInMMDDYYYY((Date) row[4]), (String) row[5]))
					.toList();

			return releaseRequests.stream().collect(Collectors.groupingBy(ReleaseRequestDTO::status));
		}

		return Collections.emptyMap();
	}

	@Override
	@Transactional(readOnly = true)
	public List<ReleaseDetailsDto> fetchReleaseInProcessDetailsByUserId(String userId) {
		Map<String, List<ReleaseDetailsDto>> releaseInProcessMap = new LinkedHashMap<>();
		var releaseInProcessResults = partRepository.findReleaseInProcessByUserId(userId);
		processResultsIfValid(releaseInProcessResults, releaseInProcessMap, "Release In Process");
		return releaseInProcessMap.getOrDefault("Release In Process", Collections.emptyList());
	}

	@Override
	@Transactional(readOnly = true)
	public Map<String, List<MainMicroTypeDto>> fetchMainMicroTypeDetailsByUserId(String userId) {
		var results = microTypeRepository.findSignoffsByUser(userId);
		var signoffMap = new LinkedHashMap<String, List<MainMicroTypeDto>>();

		for (Object[] row : results) {
			MainMicroTypeDto dto = new MainMicroTypeDto((String) row[0], Long.valueOf((String) row[1]), (String) row[2],
					(String) row[3], (String) row[4]);

			var signoffTypX = dto.signoffTypX();
			signoffMap.computeIfAbsent(signoffTypX, k -> new ArrayList<>()).add(dto);
		}

		return signoffMap;
	}

	@Override
	@Transactional(readOnly = true)
	public Map<String, List<ReleaseDetailsDto>> fetchReleaseSetupDetailsByUserId(String userId) {
		var finalResultsMap = new LinkedHashMap<String, List<ReleaseDetailsDto>>();

		List<Object[]> partRequestResults = partRepository.fetchProgDetailsForPartRequest();
		processResultsIfValid(partRequestResults, finalResultsMap, "Part Number Request");

		List<Object[]> editBaseModuleResults = partRepository.fetchProgDetailsForEditBaseModuleByUserId(userId);
		processResultsIfValid(editBaseModuleResults, finalResultsMap, "Edit Base Module Information");

		List<Object[]> sendFirmwareDataResults = partRepository.fetchProgDetailsForSendFirmwareDataByUserId(userId);
		processResultsIfValid(sendFirmwareDataResults, finalResultsMap, "Send Notice to Firmware Owners");

		List<Object[]> completeFirmwareDataResults = partRepository.fetchProgDetailsForCompleteFirmwareByUserId(userId);
		processResultsIfValid(completeFirmwareDataResults, finalResultsMap, "Complete Firmware");

		List<Object[]> wersPeerReviewSignoffResults = partRepository.findSignoffConcerns(SignoffTypeCode.PEERW.name(),
				userId, List.of(FIRMWARE_EDIT));
		processResultsIfValid(wersPeerReviewSignoffResults, finalResultsMap,
				getDisplayValue(SignoffTypeCode.PEERW.name()));

		return finalResultsMap;
	}

	@Override
	@Transactional(readOnly = true)
	public Map<String, List<ReleaseDetailsDto>> fetchPreSoftLockSignoffDetailsByUserId(String userId) {
		var finalResultsMap = new LinkedHashMap<String, List<ReleaseDetailsDto>>();

		List<String> signoffTypes = List.of(SignoffTypeCode.CALUP.name(), SignoffTypeCode.CLSUP.name(),
				SignoffTypeCode.CLOBD.name(), SignoffTypeCode.SUDEP.name(), SignoffTypeCode.CLDEP.name(),
				SignoffTypeCode.PCDEP.name(), SignoffTypeCode.SUDEV.name(), SignoffTypeCode.CLDEV.name(),
				SignoffTypeCode.PCDEV.name());

		signoffTypes.forEach(signoffCode -> {
			List<Object[]> signoffResults = partRepository.findSignoffConcerns(signoffCode, userId,
					List.of(FIRMWARE_EDIT));
			processResultsIfValid(signoffResults, finalResultsMap, getDisplayValue(signoffCode));
		});

		return finalResultsMap;
	}

	@Override
	@Transactional(readOnly = true)
	public Map<String, List<ReleaseDetailsDto>> fetchHardLockSignoffDetailsByUserId(String userId) {
		var finalResultsMap = new LinkedHashMap<String, List<ReleaseDetailsDto>>();

		List<Object[]> partRequestResults = partRepository.fetchProgDetailsForSendPeerReviewByUserId(userId);
		processResultsIfValid(partRequestResults, finalResultsMap, "Review Firmware and Soft Lock");

		List<String> signoffTypes = List.of(SignoffTypeCode.PEERR.name(), SignoffTypeCode.PEERA.name(),
				SignoffTypeCode.HWPER.name(), SignoffTypeCode.SUPPR.name());

		signoffTypes.forEach(signoffCode -> {
			List<Object[]> signoffResults = partRepository.findSignoffConcerns(signoffCode, userId, List.of(SOFT_LOCK));
			processResultsIfValid(signoffResults, finalResultsMap, getDisplayValue(signoffCode));
		});

		List<Object[]> hardLockResults = partRepository.fetchProgDetailsForHardLockByUserId(userId);
		processResultsIfValid(hardLockResults, finalResultsMap, "Hard Lock");

		return finalResultsMap;
	}

	@Override
	@Transactional(readOnly = true)
	public Map<String, List<ReleaseDetailsDto>> fetchPostHardLockSignoffDetailsByUserId(String userId) {

		var finalResultsMap = new LinkedHashMap<String, List<ReleaseDetailsDto>>();

		List<String> signoffTypes = List.of(SignoffTypeCode.SSBLD.name(), SignoffTypeCode.VBFUL.name(),
				SignoffTypeCode.DCUUL.name(), SignoffTypeCode.P2LOC.name(), SignoffTypeCode.SWWER.name(),
				SignoffTypeCode.SWBLD.name(), SignoffTypeCode.PRDWL.name(), SignoffTypeCode.PRBLD.name(),
				SignoffTypeCode.SRPUL.name(), SignoffTypeCode.SWAPR.name(), SignoffTypeCode.EOLPT.name(),
				SignoffTypeCode.IVSSB.name(), SignoffTypeCode.IVSAB.name());

		signoffTypes.forEach(signoffCode -> {
			List<Object[]> signoffResults = partRepository.findSignoffConcernsForPostHardLock(signoffCode, userId,
					List.of(HARD_LOCK));
			processResultsIfValid(signoffResults, finalResultsMap, getDisplayValue(signoffCode));
		});

		List<Object[]> serviceActionResults = partRepository.findServiceActions(userId);
		processResultsIfValid(serviceActionResults, finalResultsMap, "IVS Service Action");

		return finalResultsMap;
	}

	@Override
	public List<String> fetchHardwarePartNumbersByReleaseTypeAndModuleType(String releaseType, String moduleType) {
		switch (releaseType) {
		case "ARNAL", "AFG", "AFGO", "AFD", "AFDCX", "AREUL" -> releaseType = ReleaseTypeCode.HARDW.name();
		case "UTCU2" -> releaseType = ReleaseTypeCode.HWUTC.name();
		default -> {
			return Collections.emptyList();
		}
		}

		return partRepository.fetchHardwarePartNumbersByReleaseTypeAndModuleType(moduleType, releaseType);
	}

	private List<PartFirmwareResponse> convertToPartFirmwareResponse(List<PartFirwareDto> partFirmwareDtos) {
		return partFirmwareDtos.stream()
				.map(partFirwareDto -> new PartFirmwareResponse(partFirwareDto.partR(), partFirwareDto.engineerCdsidC(),
						partFirwareDto.hardwarePartR(), partFirwareDto.coreHardwarePartR(), partFirwareDto.microTypX(),
						programDescriptionRepository.fetchProgramDescriptionByPartNumber(partFirwareDto.partR()),
						partFirwareDto.partNumX(),
						partFirmwareRepository.fetchPartFirmwareByPartNumber(partFirwareDto.partR())))
				.toList();
	}

	public String getDisplayValue(String signoffCode) {
		List<Object[]> activeSignoffProcesses = signoffRepository.findActiveSignoffProcesses();

		for (Object[] process : activeSignoffProcesses) {
			String code = (String) process[0];
			String description = (String) process[1];
			if (signoffCode.equals(code)) {
				return description;
			}
		}

		return signoffCode;
	}

	public static boolean isValidList(List<?> list) {
		return list != null && !list.isEmpty();
	}

	private void processResultsIfValid(List<Object[]> results, Map<String, List<ReleaseDetailsDto>> finalResultsMap,
			String mapKey) {
		if (results != null && !results.isEmpty()) {
			processResults(results, finalResultsMap, mapKey);
		}
	}

	private String buildProgramString(String modelYear, String programName) {
		if (modelYear != null && programName != null) {
			return modelYear + ", " + programName;
		} else if (modelYear != null) {
			return modelYear;
		} else if (programName != null) {
			return programName;
		}
		return "";
	}

	private void processResults(List<Object[]> results, Map<String, List<ReleaseDetailsDto>> finalResultsMap,
			String mapKey) {
		List<ReleaseDetailsDto> releaseDetailsList = finalResultsMap.computeIfAbsent(mapKey, k -> new ArrayList<>());

		for (Object[] result : results) {
			String concern = (String) result[0];
			String part = (String) result[1];
			String modelYear = (String) result[2];
			String program = (String) result[3];

			if (concern == null) {
				continue;
			}

			String programString = buildProgramString(modelYear, program);
			Optional<ReleaseDetailsDto> existingReleaseDetail = findExistingReleaseDetail(releaseDetailsList, concern);

			if (existingReleaseDetail.isPresent()) {
				updateReleaseDetail(existingReleaseDetail.get(), part, programString);
			} else {
				addNewReleaseDetail(releaseDetailsList, concern, part, programString);
			}
		}
	}

	private Optional<ReleaseDetailsDto> findExistingReleaseDetail(List<ReleaseDetailsDto> releaseDetailsList,
			String concern) {
		return releaseDetailsList.stream()
				.filter(releaseDetail -> releaseDetail.concern() != null && releaseDetail.concern().equals(concern))
				.findFirst();
	}

	private void updateReleaseDetail(ReleaseDetailsDto releaseDetail, String part, String programString) {
		if (releaseDetail.parts() != null && !releaseDetail.parts().contains(part)) {
			releaseDetail.parts().add(part);
		}
		if (releaseDetail.programs() != null && !releaseDetail.programs().contains(programString)) {
			releaseDetail.programs().add(programString);
		}
	}

	private void addNewReleaseDetail(List<ReleaseDetailsDto> releaseDetailsList, String concern, String part,
			String programString) {
		List<String> parts = part != null ? new ArrayList<>(List.of(part)) : new ArrayList<>();
		List<String> programs = programString != null ? new ArrayList<>(List.of(programString)) : new ArrayList<>();
		releaseDetailsList.add(new ReleaseDetailsDto(concern, parts, programs));
	}

	private static boolean hasPPrefix(String pPn) {
		return pPn != null && pPn.startsWith("P");
	}

	public static String removePFromPrefix(String pPn) {
		if (hasPPrefix(pPn)) {
			return pPn.substring(1);
		} else {
			return pPn;
		}
	}

}
