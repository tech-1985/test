package com.ford.gpcse.exception;

public class UnusedReleaseException extends RuntimeException {

	private static final long serialVersionUID = 3826615400464814985L;

	public UnusedReleaseException(String message) {
		super(message);
	}

	public UnusedReleaseException(String message, Throwable cause) {
		super(message, cause);
	}
}