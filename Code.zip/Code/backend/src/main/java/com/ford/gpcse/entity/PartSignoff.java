package com.ford.gpcse.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMR21_SIGNOFF_PART")
public class PartSignoff {

	@EmbeddedId
	private PartSignoffId id;

	@ManyToOne
	@JoinColumn(name = "PCMR20_SIGNOFF_TYP_C", referencedColumnName = "PCMR20_SIGNOFF_TYP_C", insertable = false, updatable = false)
	private Signoff signoff;

	@ManyToOne
	@JoinColumn(name = "PCMR01_PART_R", referencedColumnName = "PCMR01_PART_R", insertable = false, updatable = false)
	private Part part;

	@Column(name = "PCMR21_DEVIAT_F")
	private String deviatF;

	@Column(name = "PCMR21_SIGNOFF_S")
	private LocalDateTime signoffS;

	@Column(name = "PCMR21_USER_CDSID_C")
	private String userCdsidC;

	@Column(name = "PCMR21_REQT_Y")
	private LocalDate reqtY;

	@Column(name = "PCMR21_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMR21_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMR21_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMR21_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;
	
	public PartSignoffId getId() {
		return id;
	}

	public void setId(PartSignoffId id) {
		this.id = id;
	}

	public Signoff getSignoff() {
		return signoff;
	}

	public void setSignoff(Signoff signoff) {
		this.signoff = signoff;
	}

	public Part getPart() {
		return part;
	}

	public void setPart(Part part) {
		this.part = part;
	}

	public String getDeviatF() {
		return deviatF;
	}

	public void setDeviatF(String deviatF) {
		this.deviatF = deviatF;
	}

	public LocalDateTime getSignoffS() {
		return signoffS;
	}

	public void setSignoffS(LocalDateTime signoffS) {
		this.signoffS = signoffS;
	}

	public String getUserCdsidC() {
		return userCdsidC;
	}

	public void setUserCdsidC(String userCdsidC) {
		this.userCdsidC = userCdsidC;
	}

	public LocalDate getReqtY() {
		return reqtY;
	}

	public void setReqtY(LocalDate reqtY) {
		this.reqtY = reqtY;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}
}
