package com.ford.gpcse.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.FirmwareDetailsResponse;
import com.ford.gpcse.bo.MicroTypeView;
import com.ford.gpcse.bo.ModuleBaseInformation;
import com.ford.gpcse.bo.ModuleTypeView;
import com.ford.gpcse.bo.PartFirmwareResponse;
import com.ford.gpcse.bo.PrismDataInputResponse;
import com.ford.gpcse.bo.ReleaseRequestDetail;
import com.ford.gpcse.bo.ReleaseRequestOutput;
import com.ford.gpcse.bo.ReleaseStatus;
import com.ford.gpcse.bo.ReleaseTypeView;
import com.ford.gpcse.bo.ReleaseUsageView;
import com.ford.gpcse.bo.ReplacePblSearchRequest;
import com.ford.gpcse.bo.SupplierView;
import com.ford.gpcse.dto.MainMicroTypeDto;
import com.ford.gpcse.dto.ProgramDescriptionDto;
import com.ford.gpcse.dto.ReleaseDetailsDto;
import com.ford.gpcse.dto.ReleaseRequestDTO;
import com.ford.gpcse.service.LookupDataService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Controller for fetching various lookup data. This class provides endpoints
 * for retrieving active suppliers, module types, micro types, release types,
 * and other related information.
 */
@RestController
@RequestMapping("/api/v1/lookup")
@Tag(description = "Fetch All Active Suppliers, Fetch All Active Module Types, Fetch All Active Release Usages, Fetch Released Micro Types By Module Type, Fetch All Release Types By Module Type, Fetch All Active Micro Names, Fetch All Active Module Names, Fetch Distinct Programs, Fetch All Programs Which Has Part Number, Fetch Release Request By Id, Fetch All Release Requests, Fetch All Release Status Details, Fetch Active Release Types, Fetch Module Base Information By User Id, Fetch Parts by Firmware, Fetch Prism Input Data By Part Number, Fetch Firmware Details By Release Type, Fetch Release Request details By User Id, Fetch Release In Process details By User Id, Fetch Main Micro Type details By User Id, Fetch Release Setup details By User Id, Fetch Pre Soft Lock Signoff details By User Id, Fetch Hard Lock Signoff details By User Id, Fetch Post Hard Lock Signoff details By User Id, Fetch Hardware Part Numbers By Release Type and Module Type.", name = "Lookup Data Operations")
public class LookupDataController {

	private final LookupDataService lookupDataService;

	public LookupDataController(LookupDataService lookupDataService) {
		super();
		this.lookupDataService = lookupDataService;
	}

	/**
	 * Endpoint for fetching all active suppliers.
	 *
	 * @return a list of active suppliers
	 */
	@GetMapping("/suppliers")
	@Operation(description = "Fetch All Active Suppliers", summary = "Fetch All Active Suppliers")
	@LoggingAspect
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<SupplierView> fetchActiveSuppliers() {
		return lookupDataService.fetchActiveSuppliers();
	}

	/**
	 * Endpoint for fetching all active module types.
	 *
	 * @return a list of active module types
	 */
	@GetMapping("/module-types")
	@Operation(description = "Fetch All Active Module Types", summary = "Fetch All Active Module Types")
	@LoggingAspect
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ModuleTypeView> fetchActiveModuleTypes() {
		return lookupDataService.fetchActiveModuleTypes();
	}

	/**
	 * Endpoint for fetching all active release usages.
	 *
	 * @return a list of active release usages
	 */
	@GetMapping("/release-usages")
	@Operation(description = "Fetch All Active Release Usages", summary = "Fetch All Active Release Usages")
	@LoggingAspect
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ReleaseUsageView> fetchActiveReleaseUsages() {
		return lookupDataService.fetchActiveReleaseUsages();
	}

	/**
	 * Endpoint for fetching released micro types By a module type.
	 *
	 * @param moduleTypeCode the module type code to filter micro types
	 * @return a list of released micro types for the specified module type
	 */
	@GetMapping("/micro-types")
	@Operation(description = "Fetch Released Micro Types By Module Type", summary = "Fetch Released Micro Types By Module Type")
	@LoggingAspect
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<MicroTypeView> fetchReleasedMicroTypesByModuleType(@RequestParam String moduleTypeCode) {
		return lookupDataService.fetchReleasedMicroTypesByModuleType(moduleTypeCode);
	}

	/**
	 * Endpoint for fetching all release types By a module type.
	 *
	 * @param moduleTypeCode the module type code to filter release types
	 * @return a list of release types for the specified module type
	 */
	@GetMapping("/release-types/module-type/{moduleTypeCode}")
	@Operation(description = "Fetch All Release Types By Module Type", summary = "Fetch All Release Types By Module Type")
	@LoggingAspect
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<String> fetchReleaseTypesByModuleType(@PathVariable String moduleTypeCode) {
		return lookupDataService.fetchReleaseTypesByModuleType(moduleTypeCode);
	}

	/**
	 * Endpoint for fetching all active micro names.
	 *
	 * @return a list of active micro names
	 */
	@GetMapping("/micro-names")
	@Operation(description = "Fetch All Active Micro Names", summary = "Fetch All Active Micro Names")
	@LoggingAspect
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<String> fetchActiveMicroNames() {
		return lookupDataService.fetchActiveMicroNames();
	}

	/**
	 * Endpoint for fetching all active module names.
	 *
	 * @return a list of active module names
	 */
	@GetMapping("/module-names")
	@Operation(description = "Fetch All Active Module Names", summary = "Fetch All Active Module Names")
	@LoggingAspect
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<String> fetchActiveModuleNames() {
		return lookupDataService.fetchActiveModuleNames();
	}

	/**
	 * Endpoint for fetching distinct programs.
	 *
	 * @return a list of distinct programs
	 */
	@GetMapping("/programs")
	@Operation(description = "Fetch Distinct Programs", summary = "Fetch Distinct Programs")
	@LoggingAspect
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ProgramDescriptionDto> fetchDistinctPrograms() {
		return lookupDataService.fetchDistinctPrograms();
	}

	/**
	 * Endpoint for fetching all programs which have a part number.
	 *
	 * @return a list of programs with part numbers
	 */
	@GetMapping("/programs/with-part-number")
	@Operation(description = "Fetch All Programs Which Has Part Number", summary = "Fetch All Programs Which Has Part Number")
	@LoggingAspect
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<String> fetchAllProgramsWhichHasPartNumber() {
		return lookupDataService.fetchAllProgramsWhichHasPartNumber();
	}

	/**
	 * Endpoint for fetching the release request details By id
	 *
	 * @return ReleaseRequest
	 */

	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/release-request/{id}")
	@Operation(description = "Fetch Release Request By Id", summary = "Fetch Release Request By Id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public ReleaseRequestDetail fetchReleaseRequestDetailsById(@PathVariable Long id) {
		return lookupDataService.fetchReleaseRequestDetailsById(id);
	}

	/**
	 * Endpoint for fetching all release requests.
	 *
	 * @return a list of release requests
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/release-request")
	@Operation(description = "Fetch All Release Requests", summary = "Fetch All Release Requests")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ReleaseRequestOutput> fetchAllReleaseRequests() {
		return lookupDataService.fetchAllReleaseRequests();
	}

	/**
	 * Endpoint for fetching all release status details.
	 *
	 * @return a list of release status details
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/release-status")
	@Operation(description = "Fetch All Release Status Details", summary = "Fetch All Release Status Details")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ReleaseStatus> fetchReleaseStatusDetails() {
		return lookupDataService.fetchReleaseStatusDetails();

	}

	/**
	 * Endpoint for fetching all active release types.
	 *
	 * @return a list of active release types
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/release-types")
	@Operation(description = "Fetch Active Release Types", summary = "Fetch Active Release Types")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ReleaseTypeView> fetchActiveReleaseTypes() {
		return lookupDataService.fetchActiveReleaseTypes();
	}

	/**
	 * Endpoint for fetching module base information By user ID.
	 *
	 * @param userId the user ID to filter module base information
	 * @return a list of module base information for the specified user
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/module-base-info/user-id/{userId}")
	@Operation(description = "Fetch Module Base Information By User Id", summary = "Fetch Module Base Information By User Id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ModuleBaseInformation> fetchModuleBaseInformation(@PathVariable String userId) {
		return lookupDataService.fetchModuleBaseInformation(userId);
	}

	/**
	 * Endpoint for fetching parts by firmware By a request object.
	 *
	 * @param replacePblSearchRequest the request object containing search
	 *                                parameters
	 * @return a response entity containing a list of parts by firmware
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping(value = "/parts-by-firmware")
	@Operation(summary = "Fetch Parts by Firmware", description = "Fetch parts by firmware By the current and replace PBL")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<PartFirmwareResponse> findPartsByFirmware(
			@RequestBody ReplacePblSearchRequest replacePblSearchRequest) {
		return lookupDataService.findPartsByFirmware(replacePblSearchRequest);
	}

	/**
	 * Endpoint for fetching prism input data By part number.
	 *
	 * @param partNumber the part number to filter prism input data
	 * @return a response entity containing prism input data for the specified part
	 *         number
	 */
	@TrackExecutionTime
	@LoggingAspect
	@GetMapping(value = "/data-prism-input/part-number/{partNumber}")
	@Operation(summary = "Fetch Prism Input Data By Part Number", description = "Fetch Prism Input Data By Part Number")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public PrismDataInputResponse fetchPrismInputDataByPartNumber(@PathVariable String partNumber) {
		return lookupDataService.fetchPrismInputDataByPartNumber(partNumber);
	}

	/**
	 * Endpoint for fetching firmware details By release type.
	 *
	 * @param releaseType the release type to filter firmware details
	 * @return a response entity containing firmware details for the specified
	 *         release type
	 */
	@TrackExecutionTime
	@LoggingAspect
	@GetMapping(value = "/firmware/release-type/{releaseType}")
	@Operation(summary = "Fetch Firmware Details By Release Type", description = "Fetch Firmware Details By Release Type")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<FirmwareDetailsResponse> fetchFirmwareDetailsByReleaseType(@PathVariable String releaseType) {
		return lookupDataService.fetchFirmwareDetailsByReleaseType(releaseType);
	}

	/**
	 * Endpoint for fetching the release request details By userid
	 *
	 * @return Map containing status and the release request details
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/release-request/user-id/{userId}")
	@Operation(description = "Fetch Release Request details By User Id", summary = "Fetch Release Request details By User Id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public Map<String, List<ReleaseRequestDTO>> fetchReleaseRequestDetailsByUserId(@PathVariable String userId) {
		return lookupDataService.fetchReleaseRequestDetailsByUserId(userId);
	}

	/**
	 * Endpoint for fetching the release in process details By userid
	 *
	 * @return List of release details
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/release-in-process/user-id/{userId}")
	@Operation(description = "Fetch Release In Process details By User Id", summary = "Fetch Release In Process details By User Id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ReleaseDetailsDto> fetchReleaseInProcessDetailsByUserId(@PathVariable String userId) {
		return lookupDataService.fetchReleaseInProcessDetailsByUserId(userId);
	}

	/**
	 * Endpoint for fetching the main micro type details By userid
	 *
	 * @return Map of release details
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/main-micro-type/user-id/{userId}")
	@Operation(description = "Fetch Main Micro Type details By User Id", summary = "Fetch Main Micro Type details By User Id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public Map<String, List<MainMicroTypeDto>> fetchMainMicroTypeDetailsByUserId(@PathVariable String userId) {
		return lookupDataService.fetchMainMicroTypeDetailsByUserId(userId);

	}

	/**
	 * Endpoint for fetching the release setup details By userid
	 *
	 * @return List of release details
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/release-setup/user-id/{userId}")
	@Operation(description = "Fetch Release Setup details By User Id", summary = "Fetch Release Setup details By User Id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public Map<String, List<ReleaseDetailsDto>> fetchReleaseSetupDetailsByUserId(@PathVariable String userId) {
		return lookupDataService.fetchReleaseSetupDetailsByUserId(userId);
	}

	/**
	 * Endpoint for fetching the pre soft lock signoff details By userid
	 *
	 * @return List of release details
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/pre-soft-lock-signoff/user-id/{userId}")
	@Operation(description = "Fetch Pre Soft Lock Signoff details By User Id", summary = "Fetch Pre Soft Lock details By User Id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public Map<String, List<ReleaseDetailsDto>> fetchPreSoftLockSignoffDetailsByUserId(@PathVariable String userId) {
		return lookupDataService.fetchPreSoftLockSignoffDetailsByUserId(userId);
	}

	/**
	 * Endpoint for fetching the hard lock signoff details By userid
	 *
	 * @return List of release details
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/hard-lock-signoff/user-id/{userId}")
	@Operation(description = "Fetch Hard Lock Signoff details By User Id", summary = "Fetch Hard Lock Signoff details By User Id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public Map<String, List<ReleaseDetailsDto>> fetchHardLockSignoffDetailsByUserId(@PathVariable String userId) {
		return lookupDataService.fetchHardLockSignoffDetailsByUserId(userId);
	}

	/**
	 * Endpoint for fetching the post hard lock signoff details By userid
	 *
	 * @return List of release details
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/post-hard-lock-signoff/user-id/{userId}")
	@Operation(description = "Fetch Post Hard Lock Signoff details By User Id", summary = "Fetch Post Hard Lock Signoff details By User Id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public Map<String, List<ReleaseDetailsDto>> fetchPostHardLockSignoffDetailsByUserId(@PathVariable String userId) {
		return lookupDataService.fetchPostHardLockSignoffDetailsByUserId(userId);
	}

	/**
	 * Endpoint for fetching hardware part details By release type and module type
	 *
	 * @return a list of hardware part details
	 */
	@GetMapping("/hardware-part-numbers/release-type/{releaseType}/module-type/{moduleType}")
	@Operation(description = "Fetch Hardware Part Numbers By Release Type and Module Type", summary = "Fetch Hardware Part Numbers By Release Type and Module Type")
	@LoggingAspect
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<String> fetchHardwarePartNumbersByReleaseTypeAndModuleType(@PathVariable String releaseType,
			@PathVariable String moduleType) {
		return lookupDataService.fetchHardwarePartNumbersByReleaseTypeAndModuleType(releaseType, moduleType);
	}

}
