package com.ford.gpcse.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.bo.Email;
import com.ford.gpcse.bo.NewMicroMicroTypeRequest;
import com.ford.gpcse.entity.MicroType;
import com.ford.gpcse.entity.SignoffMicroType;
import com.ford.gpcse.entity.SignoffMicroTypeId;
import com.ford.gpcse.exception.MicroTypeAlreadyRequestedException;
import com.ford.gpcse.exception.UnableToInsertException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.repository.MicroTypeRepository;
import com.ford.gpcse.repository.ModuleTypeRepository;
import com.ford.gpcse.repository.SignoffMicroTypeRepository;
import com.ford.gpcse.repository.SupplierRepository;
import com.ford.gpcse.service.NewMainMicroTypeService;

@Service
public class NewMicroTypeServiceImpl implements NewMainMicroTypeService {

	private final MicroTypeRepository microTypeRepository;
	private final ModuleTypeRepository moduleTypeRepository;
	private final SupplierRepository supplierRepository;
	private final SignoffMicroTypeRepository signoffMicroTypeRepository;
	private final EmailService emailService;

	public NewMicroTypeServiceImpl(MicroTypeRepository microTypeRepository, ModuleTypeRepository moduleTypeRepository,
			SupplierRepository supplierRepository, SignoffMicroTypeRepository signoffMicroTypeRepository,
			EmailService emailService) {
		super();
		this.microTypeRepository = microTypeRepository;
		this.moduleTypeRepository = moduleTypeRepository;
		this.supplierRepository = supplierRepository;
		this.signoffMicroTypeRepository = signoffMicroTypeRepository;
		this.emailService = emailService;
	}

	@Override
	@Transactional
	public void addNewMainMicroType(NewMicroMicroTypeRequest newMicroMicroTypeRequest) {

		// Check if the main micro type name exists
		var count = microTypeRepository.countByMicroTypeName(newMicroMicroTypeRequest.mainMicroTypeName());

		if (count > 0) {
			throw new MicroTypeAlreadyRequestedException(
					newMicroMicroTypeRequest.mainMicroTypeName() + " has already been requested.");
		}
		var moduleType = moduleTypeRepository.findById(newMicroMicroTypeRequest.moduleTypeCode());
		var supplier = supplierRepository.findById(newMicroMicroTypeRequest.supplierCode());
		var microId = microTypeRepository.fetchMicroId();

		if (moduleType.isPresent() && supplier.isPresent()) {

			var microType = new MicroType();
			microType.setMicroTypC(microId);
			microType.setMicroTypX(newMicroMicroTypeRequest.mainMicroTypeName());
			microType.setMicroTypOwnrCdsidC(newMicroMicroTypeRequest.createUser());
			microType.setCreateUserC(Optional.ofNullable(newMicroMicroTypeRequest.createUser()).orElse("Ram"));
			microType.setLastUpdtUserC(Optional.ofNullable(newMicroMicroTypeRequest.lastUpdateUser()).orElse("Ram"));
			microType.setModuleType(moduleType.get());
			microType.setSupplier(supplier.get());
			microType.setArchF("N");
			var savedMicroType = microTypeRepository.save(microType);

			if (savedMicroType.getMicroTypC() == null) {
				throw new UnableToInsertException("Unable to insert " + microId + ". Internal Error 1699.");
			}

			// sign off
			var signoffMicroType = new SignoffMicroType();
			signoffMicroType.setId(new SignoffMicroTypeId("MMSUP", microId));
			signoffMicroType.setMicroType(microType);
			signoffMicroType.setCreateUserC(newMicroMicroTypeRequest.createUser());
			signoffMicroType.setLastUpdtUserC(newMicroMicroTypeRequest.lastUpdateUser());
			signoffMicroTypeRepository.save(signoffMicroType);

			// send Email
			sendNewMainMicroTypeEmail(newMicroMicroTypeRequest, microId);

			// write off
			signoffMicroTypeRepository.updateSignoff("MMSUP", microId);
		} else {
			throw new UnableToInsertException("Mandatory Fields Missing");
		}
	}

	@LoggingAspect
	private void sendNewMainMicroTypeEmail(NewMicroMicroTypeRequest newMicroMicroTypeRequest, Long microId) {

		var url = "";
		var baseUrl = "";

		var emailBody = "<body><p>" + newMicroMicroTypeRequest.createUser() + " has requested a new "
				+ newMicroMicroTypeRequest.moduleTypeCode() + " Main Micro Type '"
				+ newMicroMicroTypeRequest.mainMicroTypeName() + "' for " + newMicroMicroTypeRequest.supplierName()
				+ ". Please use the link provided to review this request.</p><p><a href=\"" + baseUrl + url
				+ "?MicroId=" + microId + "\">" + baseUrl + url + "?MicroId=" + microId
				+ "</a></p><p>&nbsp;</p></body>";

		emailService.sendMail(new Email(List.of(""), // To Email
				"Release action required (Main Micro Supplier Review)", emailBody, "" // pcserel@ford.com
		));

	}
}
