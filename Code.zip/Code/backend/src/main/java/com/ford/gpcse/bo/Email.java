package com.ford.gpcse.bo;

import java.util.List;


public record Email(List<String> to, String subject, String body, String from) {
}
