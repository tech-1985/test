package com.ford.gpcse.bo;

public record ReleaseTypeView(String releaseTypeCode, String releaseTypeName) {
}
