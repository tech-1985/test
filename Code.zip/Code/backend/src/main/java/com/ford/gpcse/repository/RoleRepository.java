package com.ford.gpcse.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.gpcse.entity.Role;

/**
 * Repository interface for accessing Role entities. Extends JpaRepository to
 * provide standard CRUD operations.
 */
@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {

}
