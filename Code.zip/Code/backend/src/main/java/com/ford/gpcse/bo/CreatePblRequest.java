package com.ford.gpcse.bo;

public record CreatePblRequest(String newPbl, String moduleTypeCode, String createUser, String lastUpdateUser) {
}
