package com.ford.gpcse.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ford.gpcse.entity.ReleaseType;

/**
 * Repository interface for accessing ReleaseType entities. Extends
 * JpaRepository to provide standard CRUD operations.
 */
@Repository
public interface ReleaseTypeRepository extends JpaRepository<ReleaseType, String> {

	/**
	 * Fetches a list of active ReleaseType entities that are not archived. The
	 * results are ordered by the sort order field.
	 *
	 * @return a list of active ReleaseType entities
	 */
	@Query("SELECT rt FROM ReleaseType rt WHERE rt.archF = 'N' ORDER BY rt.sortOrdR")
	Optional<List<ReleaseType>> fetchActiveReleaseTypes();

}
