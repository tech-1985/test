package com.ford.gpcse.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import com.ford.gpcse.bo.ProductionPartNumber;
import com.ford.gpcse.bo.ReleaseRequestSearchInput;

public interface ExportToExcelService {
	ByteArrayInputStream exportPartsByPartNumbers(List<String> partNumbers) throws IOException;

	ByteArrayInputStream exportPrismPartsByPartNumbers(List<ProductionPartNumber> productionPartNumbers)
			throws IOException;

	ByteArrayInputStream exportReleaseRequestDetails(ReleaseRequestSearchInput releaseRequestSearchInput)
			throws IOException;
}
