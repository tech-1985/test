package com.ford.gpcse.bo;

public record CreateSblRequest(String supplierCode, String moduleTypeCode, Long microTypeCode, String description,
		String leadMyProgram, String userId) {
}
