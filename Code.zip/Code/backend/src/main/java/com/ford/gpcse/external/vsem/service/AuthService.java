package com.ford.gpcse.external.vsem.service;

import com.ford.gpcse.bo.TokenResponse;

public interface AuthService {
	TokenResponse fetchToken();
}
