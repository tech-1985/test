package com.ford.gpcse.exception;

public class MicroTypeAlreadyRequestedException extends RuntimeException {

	private static final long serialVersionUID = -4983260339540987123L;

	public MicroTypeAlreadyRequestedException(String message) {
		super(message);
	}

	public MicroTypeAlreadyRequestedException(String message, Throwable cause) {
		super(message, cause);
	}
}