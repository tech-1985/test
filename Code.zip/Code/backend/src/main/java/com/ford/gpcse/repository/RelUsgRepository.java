package com.ford.gpcse.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ford.gpcse.entity.RelUsg;

/**
 * Repository interface for accessing RelUsg entities. Extends JpaRepository to
 * provide standard CRUD operations.
 */
@Repository
public interface RelUsgRepository extends JpaRepository<RelUsg, String> {

	/**
	 * Fetches a list of active RelUsg entities that are not archived. The results
	 * are ordered by the sort order field.
	 *
	 * @return a list of active RelUsg entities
	 */
	@Query("SELECT ru FROM RelUsg ru WHERE ru.archF = 'N' ORDER BY ru.sortOrdR")
	Optional<List<RelUsg>> fetchActiveReleaseUsages();
}
