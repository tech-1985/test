package com.ford.gpcse.dto;

import java.util.List;

public record ReleaseDetailsDto(String concern, List<String> parts, List<String> programs) {
}
