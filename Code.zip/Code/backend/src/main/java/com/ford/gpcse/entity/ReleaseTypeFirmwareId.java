package com.ford.gpcse.entity;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class ReleaseTypeFirmwareId {

	@Column(name = "PCMR15_REL_TYP_C", length = 5)
	private String relTypC;

	@Column(name = "PCMR03_FIRMWARE_K")
	private Long firmwareK;

	public ReleaseTypeFirmwareId() {

	}

	public ReleaseTypeFirmwareId(String relTypC, Long firmwareK) {
		this.relTypC = relTypC;
		this.firmwareK = firmwareK;
	}

	public String getRelTypC() {
		return relTypC;
	}

	public void setRelTypC(String relTypC) {
		this.relTypC = relTypC;
	}

	public Long getFirmwareK() {
		return firmwareK;
	}

	public void setFirmwareK(Long firmwareK) {
		this.firmwareK = firmwareK;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		ReleaseTypeFirmwareId that = (ReleaseTypeFirmwareId) o;
		return Objects.equals(relTypC, that.relTypC) && Objects.equals(firmwareK, that.firmwareK);
	}

	@Override
	public int hashCode() {
		return Objects.hash(relTypC, firmwareK);
	}
}
