package com.ford.gpcse.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMR15_REL_TYP")
public class ReleaseType {

	@Id
	@Column(name = "PCMR15_REL_TYP_C", length = 5)
	private String relTypC;

	@Column(name = "PCMR15_REL_TYP_X", length = 50)
	private String relTypX;

	@Column(name = "PCMR15_ARCH_F", length = 1)
	private String archF;

	@Column(name = "PCMR15_SORT_ORD_R", precision = 4, scale = 0)
	private BigDecimal sortOrdR;

	@Column(name = "PCMR15_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMR15_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMR15_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMR15_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;
	
	public String getRelTypC() {
		return relTypC;
	}

	public void setRelTypC(String relTypC) {
		this.relTypC = relTypC;
	}

	public String getRelTypX() {
		return relTypX;
	}

	public void setRelTypX(String relTypX) {
		this.relTypX = relTypX;
	}

	public String getArchF() {
		return archF;
	}

	public void setArchF(String archF) {
		this.archF = archF;
	}

	public BigDecimal getSortOrdR() {
		return sortOrdR;
	}

	public void setSortOrdR(BigDecimal sortOrdR) {
		this.sortOrdR = sortOrdR;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}
}
