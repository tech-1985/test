package com.ford.gpcse.bo;

public record FedebomPlaceholderReleasePart(String pnPrefix, String hardwarePn) {

}
