package com.ford.gpcse.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.gpcse.common.Constants;
import com.ford.gpcse.dto.LookupProgramDescriptionDto;
import com.ford.gpcse.dto.ProgramDescriptionDto;
import com.ford.gpcse.dto.WersTextPartDescriptionDto;
import com.ford.gpcse.entity.ProgramDescription;

/**
 * Repository interface for accessing ProgramDescription entities. Extends
 * JpaRepository for standard CRUD operations and JpaSpecificationExecutor for
 * specifications.
 */
@Repository
public interface ProgramDescriptionRepository
		extends JpaRepository<ProgramDescription, Long>, JpaSpecificationExecutor<ProgramDescription> {

	/**
	 * Fetches program descriptions associated with a specific part number.
	 *
	 * @param partR the part reference to filter program descriptions
	 * @return a list of LookupProgramDescriptionDto containing program details
	 */
	@Query("SELECT new com.ford.gpcse.dto.LookupProgramDescriptionDto(pd.pgmK, pd.mdlYrR, pd.pgmN, pd.platN, pd.engN, pd.transN) "
			+ "FROM ProgramDescription pd " + "JOIN ProgramPart pp ON pd.pgmK = pp.pgmK "
			+ "WHERE pp.part.partR = :partR")
	List<LookupProgramDescriptionDto> fetchProgramDescriptionByPartNumber(@Param(Constants.PART_R) String partR);

	/**
	 * Fetches a distinct list of program descriptions based on certain criteria.
	 * Only includes parts that are not archived and are released.
	 *
	 * @return a list of distinct ProgramDescriptionDto containing program details
	 */
	@Query("SELECT DISTINCT new com.ford.gpcse.dto.ProgramDescriptionDto(pd.pgmK, pd.mdlYrR, pd.pgmN, pd.platN, pd.engN, pd.transN) "
			+ "FROM ProgramDescription pd JOIN ProgramPart pp ON pd.pgmK = pp.pgmK " + "JOIN pp.part p "
			+ "WHERE p.archF = 'N' AND p.reldF = 'Y' "
			+ "ORDER BY pd.mdlYrR DESC, pd.pgmN, pd.platN, pd.engN, pd.transN")
	Optional<List<ProgramDescriptionDto>> fetchDistinctPrograms();

	/**
	 * Fetches program descriptions for multiple part numbers. Returns distinct
	 * program details ordered by model year and program information.
	 *
	 * @param partNumbers a list of part numbers to filter by
	 * @return a list of WersTextPartDescriptionDto containing program details
	 */
	@Query("SELECT DISTINCT new com.ford.gpcse.dto.WersTextPartDescriptionDto("
			+ "pd.pgmK, pd.mdlYrR, pd.pgmN, pd.platN, pd.engN, pd.transN) " + "FROM ProgramDescription pd "
			+ "JOIN ProgramPart pp ON pd.pgmK = pp.pgmK " + "WHERE pp.part.partR IN :partNumbers "
			+ "ORDER BY pd.mdlYrR, pd.pgmN, pd.platN, pd.engN")
	List<WersTextPartDescriptionDto> fetchPartsWithProgramDescription(@Param("partNumbers") List<String> partNumbers);

	/**
	 * Fetches all program descriptions that are associated with part numbers.
	 * Filters for non-archived and released parts, and for model years greater than
	 * 2019.
	 *
	 * @return a list of Object arrays containing model year and program name
	 */
	@Query("SELECT DISTINCT pd.mdlYrR, pd.pgmN " + "FROM ProgramDescription pd "
			+ "JOIN ProgramPart pp ON pd.pgmK = pp.pgmK " + "JOIN Part p ON pp.part.partR = p.partR "
			+ "WHERE p.archF = 'N' " + "AND p.reldF = 'Y' " + "AND pd.mdlYrR > '2019' "
			+ "ORDER BY pd.mdlYrR DESC, pd.pgmN")
	Optional<List<Object[]>> fetchAllProgramsWhichHasPartNumber();
}
