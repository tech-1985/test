package com.ford.gpcse.bo;

import java.util.List;

import com.ford.gpcse.dto.UserRoleDto;

public record FirmwareDetailsResponse(String firmwareType, String description, String independentVerifier,
		List<UserRoleDto> owners) {
}
