export class AddPartIIModel {
  releaseType: string = "part_II";
  moduleTypeName: string = "";
  moduleTypeCode: string = "";
  microTypeCode: number = 0;
  microTypeName: string = "";
  ggdsVersion: string = "";
  swdlVersion: string = "";
  partNumber: string = "";
  description: string = "";
  uploadedToVSEM: string = "";
}

export class AddPartIIPdxPostModel {
  releaseType: string = "";
  moduleTypeCode: string = "";
  microTypeCode: number = 0;
  createUser: string = "";
  lastUpdateUser: string = "";
  ggdsVersion: string = "";
  swdlVersion: string = "";
  partNumber: string = "";
  description: string = "";
  uploadedToVSEM: string = "";
}
