import { ComponentFixture, TestBed } from "@angular/core/testing";

import { DisplayReleaseSetupComponent } from "./display-release-setup.component";

describe("DisplayReleaseSetupComponent", () => {
  let component: DisplayReleaseSetupComponent;
  let fixture: ComponentFixture<DisplayReleaseSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DisplayReleaseSetupComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DisplayReleaseSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
