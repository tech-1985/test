import { ComponentFixture, TestBed } from "@angular/core/testing";

import { DisplayReleaseInProcessComponent } from "./display-release-in-process.component";

describe("DisplayReleaseInProcessComponent", () => {
  let component: DisplayReleaseInProcessComponent;
  let fixture: ComponentFixture<DisplayReleaseInProcessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DisplayReleaseInProcessComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DisplayReleaseInProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
