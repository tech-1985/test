import { ComponentFixture, TestBed } from "@angular/core/testing";

import { DisplayPostHardLockSignoffComponent } from "./display-post-hard-lock-signoff.component";

describe("DisplayPostHardLockComponent", () => {
  let component: DisplayPostHardLockSignoffComponent;
  let fixture: ComponentFixture<DisplayPostHardLockSignoffComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DisplayPostHardLockSignoffComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DisplayPostHardLockSignoffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
