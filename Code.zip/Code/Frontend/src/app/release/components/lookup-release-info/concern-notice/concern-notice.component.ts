import { Component, Input, OnDestroy, OnInit } from "@angular/core";

import { HttpErrorResponse, HttpResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";
import { FindFirmWare } from "../../../utils/models/concern-notice.model";
import { Router } from "@angular/router";
import { ReleaseService } from "../../../utils/services/release.service";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { ExportToXmlPostModel } from "../../../utils/models/xml.model";

@Component({
  selector: "app-concern-notice",
  templateUrl: "./concern-notice.component.html",
  styleUrls: ["./concern-notice.component.scss"],
})
export class ConcernNoticeComponent implements OnInit, OnDestroy {
  selectAllChecked: boolean = false;
  findFrimWare: FindFirmWare = {};
  tempShowTable: boolean = false;
  tempShowHeader: boolean = true;
  firmwareRecords: any[] = [];
  selectedRecords: Set<string> = new Set();
  private unsubscribe$ = new Subject<void>();
  @Input() concernNumber!: string;
  loading: boolean = false;

  constructor(private router: Router, private releaseService: ReleaseService) {}

  ngOnInit() {
    this.resetState();
    if (this.concernNumber) {
      this.findFrimWare.wersConcern = this.concernNumber;
      this.tempShowHeader = false;
      this.tempShowTable = true;
      this.searchWersConcern();
    }
  }

  private resetState() {
    this.findFrimWare = new FindFirmWare();
    this.firmwareRecords = [];
    this.tempShowTable = false;
    this.selectAllChecked = false;
    this.selectedRecords.clear();
    this.loading=false;
  }

  searchWersConcern() {
    this.findFrimWare.wersNotice = "";
    this.firmwareRecords = [];
    this.tempShowTable = false;

    if (!this.findFrimWare?.wersConcern) {
      return;
    }
    this.loading=true;
    this.releaseService
      .getFirmwareDetailsByWersConcern(this.findFrimWare.wersConcern)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.loading=false;
          this.firmwareRecords = Array.isArray(response) ? response : [];
          this.tempShowTable = true;
        },
        error: (error: HttpErrorResponse) => {
          this.loading=false;
          this.handleError(error);
        },
      });
  }

  searchWersNotice() {
    this.findFrimWare.wersConcern = "";
    this.firmwareRecords = [];
    this.tempShowTable = false;

    if (!this.findFrimWare?.wersNotice) {
      return;
    }
  

    const trimmedNotice = this.findFrimWare.wersNotice.trim();
    if (!this.testNoticeNumber(trimmedNotice)) {
   

      const modifiedNotice = trimmedNotice.replace(/-/g, " ");
      if (!this.testNoticeNumber(modifiedNotice)) {
        ReleaseUtils.showErrorSweetAlert(
          "Error",
          "WERS Notice has the incorrect format. The format must be 'APED E 12345678 000'.\n4 characters, space, e or i, space, 8 digits, space, 3 digits"
        );
        return;
      }
    
      this.callFirmwareService(modifiedNotice);
    } else {
      this.callFirmwareService(trimmedNotice);
    }
  }

  private callFirmwareService(notice: string) {
    this.loading=true;
    this.releaseService
      .getFirmwareDetailsByWersNotice(notice)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.loading=false;
          this.firmwareRecords = Array.isArray(response) ? response : [];
          this.tempShowTable = true;
        },
        error: (error: HttpErrorResponse) => {
          this.loading=false;
          this.handleError(error);
        },
      });
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage =
      "Unfortunately, an error has occurred. Please check back later.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }

  cancelSubmit() {
    this.resetState();
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  toggleSelectAll(event: Event) {
    const isChecked = (event.target as HTMLInputElement).checked;
    this.selectAllChecked = isChecked;

    this.selectedRecords.clear();

    if (isChecked) {
      this.firmwareRecords.forEach((group) => {
        group.firmwareResponses.forEach((record: any) => {
          this.selectedRecords.add(record.assemblyPN);
        });
      });
    }
  }

  isRecordSelected(assemblyPN: string): boolean {
    return this.selectedRecords.has(assemblyPN);
  }

  toggleRecordSelection(assemblyPN: string) {
    if (this.selectedRecords.has(assemblyPN)) {
      console.log("Removing:", assemblyPN);
      this.selectedRecords.delete(assemblyPN);
    } else {
      console.log("Adding:", assemblyPN);
      this.selectedRecords.add(assemblyPN);
    }

    this.updateSelectAllChecked();
  }

  updateSelectAllChecked() {
    const totalRecords = this.firmwareRecords.reduce(
      (acc, group) => acc + group.firmwareResponses.length,
      0
    );
    this.selectAllChecked = this.selectedRecords.size === totalRecords;
    console.log("Select All Checked State:", this.selectAllChecked);
  }

  exportToXML() {
    const partNumbers = Array.from(this.selectedRecords);
    const exportToXmlData: ExportToXmlPostModel = new ExportToXmlPostModel();
    exportToXmlData.partNumbers = partNumbers;
    exportToXmlData.createUser = "DSADASH1";
    if (this.concernNumber) {
      exportToXmlData.concernNumber = this.concernNumber;
    }
    if (this.findFrimWare.wersConcern) {
      exportToXmlData.concernNumber = this.findFrimWare.wersConcern;
    }
    if (this.findFrimWare.wersNotice) {
      exportToXmlData.wersNoticeNumber = this.findFrimWare.wersNotice;
    }
    ReleaseUtils.exportToXML(this.releaseService, exportToXmlData);
  }

  exportToExcel() {
    ReleaseUtils.exportToExcel(
      this.releaseService,
      Array.from(this.selectedRecords)
    );
  }

  testNoticeNumber(notice: string): boolean {
    const regex =
      /^[a-z0-9]{4}\s[iesnx]\s\d{8}\s\d{3}$|^[a-z0-9]{4}[iesnx]\d{8}\d{3}$|^[a-z0-9]{4}-[iesnx]-\d{8}-\d{3}$/i;
    return regex.test(notice);
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
