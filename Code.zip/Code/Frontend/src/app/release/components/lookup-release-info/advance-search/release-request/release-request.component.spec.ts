import { ComponentFixture, TestBed } from "@angular/core/testing";

import { ReleaseRequestComponent } from "./release-request.component";

describe("ReleaseRequestComponent", () => {
  let component: ReleaseRequestComponent;
  let fixture: ComponentFixture<ReleaseRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReleaseRequestComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ReleaseRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
