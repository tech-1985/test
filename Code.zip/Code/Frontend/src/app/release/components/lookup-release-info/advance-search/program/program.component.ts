import { Component, OnDestroy, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ReleaseService } from "../../../../utils/services/release.service";
import { Subject } from "rxjs";
import { ErrorResponse } from "../../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../../utils/ReleaseUtils";
import { takeUntil } from "rxjs/operators";
import { HttpErrorResponse, HttpResponse } from "@angular/common/http";
import { ExportToXmlPostModel } from "../../../../utils/models/xml.model";
@Component({
  selector: "app-program",
  templateUrl: "./program.component.html",
  styleUrl: "./program.component.scss",
})
export class ProgramComponent implements OnInit, OnDestroy {
  searchTerm: string = "";
  selectedPrograms: string[] = [];
  programs: string[] = [];
  programKeys: string[] = [];
  filteredProgramKeys: string[] = [];
  tempShowTable: boolean = false;
  firmwareRecords: any[] = [];
  selectedRecords: Set<string> = new Set();
  private unsubscribe$ = new Subject<void>();
  selectAllChecked: boolean = false;
  loading: boolean = false;

  constructor(private router: Router, private releaseService: ReleaseService) {}

  ngOnInit() {
    this.resetState();
    this.fetchPrograms();
  }

  private resetState() {
    this.selectedPrograms = [];
    this.firmwareRecords = [];
    this.tempShowTable = false;
    this.selectAllChecked = false;
    this.selectedRecords.clear();
    this.loading = false;
  }

  fetchPrograms() {
    this.releaseService.getPrograms().subscribe((data) => {
      this.programs = data.map(
        (program) =>
          `${program.mdlYrR}, ${program.pgmN}, ${program.platN}, ${program.engN}, ${program.transN}`
      );
      this.programKeys = data.map((program) => `${program.programKey}`);
    });
  }

  filteredPrograms() {
    if (!this.searchTerm) {
      return this.programs;
    }

    return this.programs.filter((program) =>
      program.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  onProgramSelect(event: any) {
    const selectedOptions = event.target.selectedOptions;
    this.selectedPrograms = [];

    for (let i = 0; i < selectedOptions.length; i++) {
      this.selectedPrograms.push(selectedOptions[i].value);
    }

    this.filteredProgramKeys = this.selectedPrograms
      .map((selectedProgram) => {
        const index = this.programs.indexOf(selectedProgram);
        return this.programKeys[index];
      })
      .filter((key) => key !== undefined);
  }

  onOkClick() {
    this.loading = true;
    this.releaseService
      .getFirmwareDetailsByPrograms(this.filteredProgramKeys)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.loading = false;
          this.firmwareRecords = Array.isArray(response) ? response : [];
          this.tempShowTable = true;
        },
        error: (error: HttpErrorResponse) => {
          this.loading = false;
          this.handleError(error);
        },
      });
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage =
      "Unfortunately, an error has occurred. Please check back later.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }

  onCancelClick() {
    this.resetState();
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  toggleSelectAll(event: Event) {
    const isChecked = (event.target as HTMLInputElement).checked;
    this.selectAllChecked = isChecked;

    if (isChecked) {
      this.firmwareRecords.forEach((record) => {
        this.selectedRecords.add(record.assemblyPN);
      });
    } else {
      this.selectedRecords.clear();
    }
  }

  isRecordSelected(assemblyPN: string): boolean {
    return this.selectedRecords.has(assemblyPN);
  }

  toggleRecordSelection(assemblyPN: string) {
    if (this.selectedRecords.has(assemblyPN)) {
      this.selectedRecords.delete(assemblyPN);
    } else {
      this.selectedRecords.add(assemblyPN);
    }
  }

  exportToXML() {
    const partNumbers = Array.from(this.selectedRecords);
    const exportToXmlData: ExportToXmlPostModel = new ExportToXmlPostModel();
    exportToXmlData.partNumbers = partNumbers;
    ReleaseUtils.exportToXML(this.releaseService, exportToXmlData);
  }

  exportToExcel() {
    ReleaseUtils.exportToExcel(
      this.releaseService,
      Array.from(this.selectedRecords)
    );
  }
  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
