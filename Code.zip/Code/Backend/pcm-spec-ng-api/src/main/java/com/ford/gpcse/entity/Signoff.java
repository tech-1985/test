package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "WPCMR20_SIGNOFF")
public class Signoff {

    @Id
    @Column(name = "PCMR20_SIGNOFF_TYP_C", length = 5)
    private String signoffTypC;

    @Column(name = "PCMR20_SIGNOFF_TYP_X")
    private String signoffTypX;

    @Column(name = "PCMR20_ARCH_F")
    private String archF;

    @Column(name = "PCMR20_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMR20_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR20_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR20_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR20_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    public String getSignoffTypC() {
        return signoffTypC;
    }

    public void setSignoffTypC(String signoffTypC) {
        this.signoffTypC = signoffTypC;
    }

    public String getSignoffTypX() {
        return signoffTypX;
    }

    public void setSignoffTypX(String signoffTypX) {
        this.signoffTypX = signoffTypX;
    }

    public String getArchF() {
        return archF;
    }

    public void setArchF(String archF) {
        this.archF = archF;
    }

    public Long getSortOrdR() {
        return sortOrdR;
    }

    public void setSortOrdR(Long sortOrdR) {
        this.sortOrdR = sortOrdR;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }
}
