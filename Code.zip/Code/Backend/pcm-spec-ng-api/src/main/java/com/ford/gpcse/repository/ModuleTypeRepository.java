package com.ford.gpcse.repository;

import com.ford.gpcse.entity.ModuleType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for managing ModuleType entities. This interface extends
 * JpaRepository to provide CRUD operations for ModuleType entities.
 */
@Repository
public interface ModuleTypeRepository extends JpaRepository<ModuleType, String> {

    /**
     * Fetches a list of active module types. Only module types that are not
     * archived (archF = 'N') will be retrieved.
     *
     * @return A list of active module types sorted by their order and code.
     */
    @Query("SELECT m FROM ModuleType m WHERE m.archF = 'N' ORDER BY m.sortOrdR, m.moduleTypC")
    Optional<List<ModuleType>> fetchActiveModuleTypes();

}
