package com.ford.gpcse.service.impl;

import com.ford.gpcse.repository.FirmwareRepository;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.service.PartNumberSearchExcelService;
import com.ford.gpcse.util.CommonUtility;
import com.ford.gpcse.util.NoticeFormatterUtility;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;

@Service
public class PartNumberSearchExcelServiceImpl implements PartNumberSearchExcelService {

    private static final String[] HEADERS = {"Part Number", "Firmware Program", "MY", "Program", "Platform", "Engine",
            "Transmission", "Lineage", "Release Type", "Release Usage", "Calib. No.", "Cal Variant", "Cal R Level",
            "Catch Word", "Release Eng.", "Hardware PN", "Core Hardware PN", "Core Hardware Owner", "Main Micro Type",
            "Supplier", "HCR Number", "Software PN", "Calibration PN", "Main Strategy", "Chip ID", "Build Level",
            "Release Priority", "Release Priority Details", "Concern", "WERS Notice", "WERS Description",
            "Backwards Compatibility", "Replaced P/N", "IPF Module P/N", "Service Module PN",
            "Reason for not Backwards Compatible", "Superseded", "Application Peer Reviewer", "Hardware Peer Reviewer",
            "Project Control Engineer", "Calibrator", "Assembly Peer Reviewer", "Label Type", "IVS Program",
            "Program Archive", "Date Created", "Cal Date Planned", "Cal Date Actual", "Date Locked", "Release Status",
            "IVS Service Action"};

    private final PartRepository partRepository;
    private final PartFirmwareRepository partFirmwareRepository;
    private final FirmwareRepository firmwareRepository;

    public PartNumberSearchExcelServiceImpl(PartRepository partRepository, PartFirmwareRepository partFirmwareRepository, FirmwareRepository firmwareRepository) {
        this.partRepository = partRepository;
        this.partFirmwareRepository = partFirmwareRepository;
        this.firmwareRepository = firmwareRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public ByteArrayInputStream exportPartsByPartNumbers(List<String> partNumbers) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            var partResults = List.<Object[]>of();
            var firmwareResults = List.<Object[]>of();
            if (!partNumbers.isEmpty()) {
                partResults = partRepository.findAllPartsByIds(partNumbers);
                firmwareResults = partFirmwareRepository.findAllFirmwareByParts(partNumbers);
            }

            var firmwareMap = populateFirwareMapForPartNumbers(firmwareResults);

            var verticalSheet = workbook.createSheet("ExportFirmwareVertical");

            var firmwareHeaders = firmwareRepository.findFirmwareColumnHeaders(partNumbers);
            fillTheDataInVertialSheetForPartNumbers(verticalSheet, partResults, firmwareMap, firmwareHeaders);

            var horizontalSheet = workbook.createSheet("ExportFirmwareHorizontal");
            fillTheDataInHorizontalSheetForPartNumbers(horizontalSheet, partResults, firmwareMap, firmwareHeaders);

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    private void fillTheDataInHorizontalSheetForPartNumbers(Sheet horizontalSheet, List<Object[]> partResults,
                                                            Map<String, String> firmwareMap, List<Object[]> firmwareHeaders) {

        int totalNumberOfHeaderRows = createHorizontalHeaderColumnForPartNumbers(horizontalSheet, firmwareHeaders);
        int partColumnIndex = 1;

        for (Object[] partResult : partResults) {
            if (partResult != null) {
                for (int rowIndex = 0; rowIndex < totalNumberOfHeaderRows; rowIndex++) {
                    Row row = horizontalSheet.getRow(rowIndex);
                    if (row == null) {
                        row = horizontalSheet.createRow(rowIndex);
                    }
                    row.setHeightInPoints(26);

                    setRowCellValue(row, partResult, rowIndex, partColumnIndex);
                }

                createFirmwareHorizontalCellDataForPartNumbers(horizontalSheet, firmwareMap, partResult,
                        partColumnIndex);

                horizontalSheet.autoSizeColumn(partColumnIndex);
                partColumnIndex++;
            }
        }
    }

    private void setRowCellValue(Row row, Object[] partResult, int rowIndex, int partColumnIndex) {
        var indexMap = new HashMap<Integer, Integer>();
        indexMap.put(2, 45); // PCMS01_MDL_YR_R
        indexMap.put(3, 46); // PCMS01_PGM_N
        indexMap.put(4, 47); // PCMS01_PLAT_N
        indexMap.put(5, 48); // PCMS01_ENG_N
        indexMap.put(6, 49); // PCMS01_TRANS_N
        indexMap.put(7, 1); // PCMR01_PART_NUM_X
        indexMap.put(8, 21); // PCMR15_REL_TYP_X
        indexMap.put(9, 16); // PCMR24_REL_USG_X
        indexMap.put(10, 3); // PCMR01_CALIB_R
        indexMap.put(11, 4); // Cal Variant
        indexMap.put(12, 5); // Cal R Level
        indexMap.put(13, 2); // PCMR01_CATCHWORD_C
        indexMap.put(14, 9); // PCMR01_ENGINEER_CDSID_C
        indexMap.put(15, 10); // PCMR01_HARDWARE_PART_R
        indexMap.put(16, 43); // PCMR01_CORE_HARDWARE_PART_R
        indexMap.put(17, 44); // PCMR01_CORE_HARDWARE_CDSID_C
        indexMap.put(18, 14); // PCMR19_MICRO_TYP_X
        indexMap.put(19, 20); // PCMR17_SUPL_X
        indexMap.put(20, 15); // PCMR01_HCR_R
        indexMap.put(21, 13); // PCMR01_STRAT_CALIB_PART_R
        indexMap.put(22, 29); // PCMR01_STRAT_PART_R
        indexMap.put(23, 6); // PCMR01_STRAT_REL_C
        indexMap.put(24, 11); // PCMR01_CHIP_D
        indexMap.put(25, 32); // PCMR01_BLD_LVL_C
        indexMap.put(26, 33); // PCMR01_PRTY_C
        indexMap.put(27, 34); // PCMR01_PRTY_DTL_X
        indexMap.put(28, 8); // PCMR01_CONCERN_C
        indexMap.put(29, 12); // PCMR01_WERS_NTC_R (true)
        indexMap.put(30, 28); // PCMR01_CMT_X
        indexMap.put(31, 22); // PCMR26_BACKWARD_COMPAT_X
        indexMap.put(32, 23); // PCMR01_REPLACED_PART_R
        indexMap.put(33, 24); // PCMR01_IPF_PART_R
        indexMap.put(34, 17); // PCMR01_SVC_MODULE_PART_R
        indexMap.put(35, 25); // PCMR01_BACKWARD_COMPAT_GRP_C
        indexMap.put(36, 37); // Superseded
        indexMap.put(37, 38); // Application Peer Reviewer
        indexMap.put(38, 36); // Hardware Peer Reviewer
        indexMap.put(39, 35); // PCMR01_PROJ_CTL_ENG_CDSID_C
        indexMap.put(40, 26); // PCMR01_PWRTRN_CALIB_CDSID_C
        indexMap.put(41, 30); // Assembly Peer Reviewer
        indexMap.put(42, 19); // Label Type
        indexMap.put(43, 31); // PCMS01_IVS_PGM_D
        indexMap.put(44, 50); // PCMS01_ARCH_F
        indexMap.put(45, 18); // PCMR01_CONCERN_Y
        indexMap.put(46, 51); // PCMR01_CAL_REL_PLAN_Y
        indexMap.put(47, 52); // PCMR01_CAL_REL_ACT_Y
        indexMap.put(48, 7); // PCMR01_RELD_Y
        indexMap.put(49, 27); // PCMR01_STAT_C (true)
        indexMap.put(50, -1); // Empty case

        if (rowIndex == 1) {
            String firmwareProgram = buildFirmwareProgram(partResult);
            row.createCell(partColumnIndex).setCellValue(firmwareProgram);
        } else if (indexMap.containsKey(rowIndex)) {
            int index = indexMap.get(rowIndex);
            if (index == -1) {
                setCellValue(row, "", partColumnIndex);
            } else {
                setCellValue(row, partResult[index], partColumnIndex, rowIndex == 29 || rowIndex == 49);
            }
        } else {
            setCellValue(row, partResult[0], partColumnIndex);
        }
    }

    private void setCellValue(Row row, Object value, int columnIndex) {
        setCellValue(row, value, columnIndex, false);
    }

    private void setCellValue(Row row, Object value, int columnIndex, boolean formatNotice) {
        if (value != null) {
            String cellValue = CommonUtility.getSafeValue(value);
            if (formatNotice) {
                cellValue = NoticeFormatterUtility.formatNotice(cellValue);
            }
            row.createCell(columnIndex).setCellValue(cellValue);
        } else {
            row.createCell(columnIndex).setCellValue("");
        }
    }

    private String buildFirmwareProgram(Object[] partResult) {
        return String.join(",", CommonUtility.getSafeValue(partResult[45]), // PCMS01_MDL_YR_R
                CommonUtility.getSafeValue(partResult[46]), // PCMS01_PGM_N
                CommonUtility.getSafeValue(partResult[47]), // PCMS01_PLAT_N
                CommonUtility.getSafeValue(partResult[48]), // PCMS01_ENG_N
                CommonUtility.getSafeValue(partResult[49]) // PCMS01_TRANS_N
        );
    }

    private int createHorizontalHeaderColumnForPartNumbers(Sheet sheet, List<Object[]> firmwareHeaders) {
        var workbook = sheet.getWorkbook();
        var headerStyle = workbook.createCellStyle();
        var font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        var rowIndex = 0;
        for (String header : HEADERS) {
            var row = sheet.createRow(rowIndex);
            var cell = row.createCell(0);
            cell.setCellValue(header);
            cell.setCellStyle(headerStyle);
            row.setHeightInPoints(20);
            sheet.autoSizeColumn(0);
            rowIndex++;
        }
        var seenFirmwareNames = new HashSet<String>();

        for (Object[] row : firmwareHeaders) {
            var firmwareName = (String) row[1];

            if (seenFirmwareNames.add(firmwareName)) {
                var rowObj = sheet.createRow(rowIndex);
                var cell = rowObj.createCell(0);
                cell.setCellValue(firmwareName);
                cell.setCellStyle(headerStyle);
                rowObj.setHeightInPoints(20);
                sheet.autoSizeColumn(0);
                rowIndex++;
            }
        }
        return rowIndex;
    }

    private void fillTheDataInVertialSheetForPartNumbers(Sheet verticalSheet, List<Object[]> partResults,
                                                         Map<String, String> firmwareMap, List<Object[]> firmwareHeaders) {
        createVerticalHeaderRowForPartNumbers(verticalSheet, firmwareHeaders);
        var rowNum = 1;
        for (Object[] partResult : partResults) {
            if (partResult != null) {
                var row = verticalSheet.createRow(rowNum++);
                createVerticalDataRowForPartNumbers(partResult, row, firmwareMap);
            }
        }
    }

    private void createVerticalHeaderRowForPartNumbers(Sheet sheet, List<Object[]> firmwareHeaders) {
        var headerRow = sheet.createRow(0);
        headerRow.setHeightInPoints(20);
        var workbook = sheet.getWorkbook();
        var headerStyle = workbook.createCellStyle();
        var font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        var columnIndex = 0;
        for (String header : HEADERS) {
            var cell = headerRow.createCell(columnIndex);
            cell.setCellValue(header);
            cell.setCellStyle(headerStyle);
            var columnWidth = header.length() * 512;
            sheet.setColumnWidth(columnIndex, columnWidth);
            columnIndex++;
        }
        var seenFirmwareNames = new HashSet<String>();

        for (Object[] row : firmwareHeaders) {
            var firmwareName = (String) row[1];
            if (seenFirmwareNames.add(firmwareName)) {
                var cell = headerRow.createCell(columnIndex);
                cell.setCellValue(firmwareName);
                cell.setCellStyle(headerStyle);
                var columnWidth = firmwareName.length() * 512;
                sheet.setColumnWidth(columnIndex, columnWidth);
                columnIndex++;
            }
        }
    }

    private void createVerticalDataRowForPartNumbers(Object[] partResult, Row row, Map<String, String> firmwareMap) {
        row.createCell(0).setCellValue(partResult[0] != null ? partResult[0].toString() : ""); // PCMR01_PART_R
        var firmwareProgram = CommonUtility.getSafeValue(partResult[45]) + "," + // PCMS01_MDL_YR_R
                CommonUtility.getSafeValue(partResult[46]) + "," + // PCMS01_PGM_N
                CommonUtility.getSafeValue(partResult[47]) + "," + // PCMS01_PLAT_N
                CommonUtility.getSafeValue(partResult[48]) + "," + // PCMS01_ENG_N
                CommonUtility.getSafeValue(partResult[49]); // PCMS01_TRANS_N

        row.createCell(1).setCellValue(firmwareProgram); // Firmware Program
        row.createCell(2).setCellValue(CommonUtility.getSafeValue(partResult[45])); // PCMS01_MDL_YR_R
        row.createCell(3).setCellValue(CommonUtility.getSafeValue(partResult[46])); // PCMS01_PGM_N
        row.createCell(4).setCellValue(CommonUtility.getSafeValue(partResult[47])); // PCMS01_PLAT_N
        row.createCell(5).setCellValue(CommonUtility.getSafeValue(partResult[48])); // PCMS01_ENG_N
        row.createCell(6).setCellValue(CommonUtility.getSafeValue(partResult[49])); // PCMS01_TRANS_N
        row.createCell(7).setCellValue(CommonUtility.getSafeValue(partResult[1])); // PCMR01_PART_NUM_X
        row.createCell(8).setCellValue(CommonUtility.getSafeValue(partResult[21])); // PCMR15_REL_TYP_X
        row.createCell(9).setCellValue(CommonUtility.getSafeValue(partResult[16])); // PCMR24_REL_USG_X
        row.createCell(10).setCellValue(CommonUtility.getSafeValue(partResult[3])); // PCMR01_CALIB_R
        row.createCell(11).setCellValue(CommonUtility.getSafeValue(partResult[4])); // Cal Variant
        row.createCell(12).setCellValue(CommonUtility.getSafeValue(partResult[5])); // Cal R Level
        row.createCell(13).setCellValue(CommonUtility.getSafeValue(partResult[2])); // PCMR01_CATCHWORD_C
        row.createCell(14).setCellValue(CommonUtility.getSafeValue(partResult[9])); // PCMR01_ENGINEER_CDSID_C
        row.createCell(15).setCellValue(CommonUtility.getSafeValue(partResult[10])); // PCMR01_HARDWARE_PART_R
        row.createCell(16).setCellValue(CommonUtility.getSafeValue(partResult[43])); // PCMR01_CORE_HARDWARE_PART_R
        row.createCell(17).setCellValue(CommonUtility.getSafeValue(partResult[44])); // PCMR01_CORE_HARDWARE_CDSID_C
        row.createCell(18).setCellValue(CommonUtility.getSafeValue(partResult[14])); // PCMR19_MICRO_TYP_X
        row.createCell(19).setCellValue(CommonUtility.getSafeValue(partResult[20])); // PCMR17_SUPL_X
        row.createCell(20).setCellValue(CommonUtility.getSafeValue(partResult[15])); // PCMR01_HCR_R
        row.createCell(21).setCellValue(CommonUtility.getSafeValue(partResult[13])); // PCMR01_STRAT_CALIB_PART_R
        row.createCell(22).setCellValue(CommonUtility.getSafeValue(partResult[29])); // PCMR01_STRAT_PART_R
        row.createCell(23).setCellValue(CommonUtility.getSafeValue(partResult[6])); // PCMR01_STRAT_REL_C
        row.createCell(24).setCellValue(CommonUtility.getSafeValue(partResult[11])); // PCMR01_CHIP_D
        row.createCell(25).setCellValue(CommonUtility.getSafeValue(partResult[32])); // PCMR01_BLD_LVL_C
        row.createCell(26).setCellValue(CommonUtility.getSafeValue(partResult[33])); // PCMR01_PRTY_C
        row.createCell(27).setCellValue(CommonUtility.getSafeValue(partResult[34])); // PCMR01_PRTY_DTL_X
        row.createCell(28).setCellValue(CommonUtility.getSafeValue(partResult[8])); // PCMR01_CONCERN_C
        row.createCell(29).setCellValue(partResult[12] != null ? NoticeFormatterUtility.formatNotice(partResult[12].toString()) : ""); // PCMR01_WERS_NTC_R
        row.createCell(30).setCellValue(CommonUtility.getSafeValue(partResult[28])); // PCMR01_CMT_X
        row.createCell(31).setCellValue(CommonUtility.getSafeValue(partResult[22])); // PCMR26_BACKWARD_COMPAT_X
        row.createCell(32).setCellValue(CommonUtility.getSafeValue(partResult[23])); // PCMR01_REPLACED_PART_R
        row.createCell(33).setCellValue(CommonUtility.getSafeValue(partResult[24])); // PCMR01_IPF_PART_R
        row.createCell(34).setCellValue(CommonUtility.getSafeValue(partResult[17])); // PCMR01_SVC_MODULE_PART_R
        row.createCell(35).setCellValue(CommonUtility.getSafeValue(partResult[25])); // PCMR01_BACKWARD_COMPAT_GRP_C
        row.createCell(36).setCellValue(CommonUtility.getSafeValue(partResult[37])); // Superseded
        row.createCell(37).setCellValue(CommonUtility.getSafeValue(partResult[38])); // Application Peer Reviewer
        row.createCell(38).setCellValue(CommonUtility.getSafeValue(partResult[36])); // Hardware Peer Reviewer
        row.createCell(39).setCellValue(CommonUtility.getSafeValue(partResult[35])); // PCMR01_PROJ_CTL_ENG_CDSID_C
        row.createCell(40).setCellValue(CommonUtility.getSafeValue(partResult[26])); // PCMR01_PWRTRN_CALIB_CDSID_C
        row.createCell(41).setCellValue(CommonUtility.getSafeValue(partResult[30])); // Assembly Peer Reviewer
        row.createCell(42).setCellValue(CommonUtility.getSafeValue(partResult[19])); // Label Type
        row.createCell(43).setCellValue(CommonUtility.getSafeValue(partResult[31])); // PCMS01_IVS_PGM_D
        row.createCell(44).setCellValue(CommonUtility.getSafeValue(partResult[50])); // PCMS01_ARCH_F
        row.createCell(45).setCellValue(CommonUtility.getSafeValue(partResult[18])); // PCMR01_CONCERN_Y
        row.createCell(46).setCellValue(CommonUtility.getSafeValue(partResult[51])); // PCMR01_CAL_REL_PLAN_Y
        row.createCell(47).setCellValue(CommonUtility.getSafeValue(partResult[52])); // PCMR01_CAL_REL_ACT_Y
        row.createCell(48).setCellValue(CommonUtility.getSafeValue(partResult[7])); // PCMR01_RELD_Y
        row.createCell(49).setCellValue(partResult[27] != null ? CommonUtility.releaseStatusText(partResult[27].toString()) : ""); // PCMR01_STAT_C
        row.createCell(50).setCellValue(""); // PCMR04_IVS_SERVICE_ACTION_R column not found in WPCMR04_PGM_PART table

        createFirmwareVerticalCellDataForPartNumbers(partResult, firmwareMap, row);
    }


    private void createFirmwareHorizontalCellDataForPartNumbers(Sheet horizontalSheet,
                                                                Map<String, String> firmwareMap, Object[] partResult, int partColumnIndex) {
        var partNumber = partResult[0] != null ? partResult[0].toString() : "";
        var firmwareData = firmwareMap.getOrDefault(partNumber, "");
        if (!firmwareData.isEmpty()) {
            var firmwareDataArray = firmwareData.split(",");
            for (int firmwareIndex = 0; firmwareIndex < firmwareDataArray.length; firmwareIndex++) {
                Row firmwareRow = horizontalSheet.getRow(51 + firmwareIndex);
                firmwareRow.createCell(partColumnIndex).setCellValue(firmwareDataArray[firmwareIndex]);
            }
        }
    }

    private void createFirmwareVerticalCellDataForPartNumbers(Object[] partResult,
                                                              Map<String, String> firmwareMap, Row row) {
        var partNumber = partResult[0] != null ? partResult[0].toString() : "";
        var firmwareData = firmwareMap.getOrDefault(partNumber, "");
        if (firmwareData != null && !firmwareData.isEmpty()) {
            var firmwareDataArray = firmwareData.split(",");
            for (int i = 0; i < firmwareDataArray.length; i++) {
                row.createCell(51 + i).setCellValue(firmwareDataArray[i]);
            }
        }
    }

    private Map<String, String> populateFirwareMapForPartNumbers(List<Object[]> firmwareResults) {
        var firmwareMap = new LinkedHashMap<String, String>();
        for (Object[] firmwareResult : firmwareResults) {
            if (firmwareResult != null && firmwareResult.length >= 3) {
                var partNumber = firmwareResult[0] != null ? firmwareResult[0].toString() : "";
                var fileName = firmwareResult[2] != null ? firmwareResult[2].toString() : "";

                var currentValue = firmwareMap.getOrDefault(partNumber, "");
                if (!currentValue.isEmpty()) {
                    currentValue += ",";
                }
                currentValue += fileName;
                firmwareMap.put(partNumber, currentValue);
            }
        }
        return firmwareMap;
    }


}
