package com.ford.gpcse.bo;

import com.ford.gpcse.dto.LookupPartFirmwareDto;
import com.ford.gpcse.dto.LookupProgramDescriptionDto;

import java.util.List;

public record PartFirmwareResponse(String assemblyPN, String drcdsId, String hardwarePN, String coreHardwarePN,
                                   String mainMicroType, List<LookupProgramDescriptionDto> programDescriptions,
                                   String lineage,
                                   List<LookupPartFirmwareDto> partFirmwares) {
}
