package com.ford.gpcse.service;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import org.springframework.core.io.Resource;

public interface FirmwareXmlExportV10Service {
    Resource generateFirmwareV10Xml(ExportFirmwareXmlRequest exportFirmwareXmlRequest);
}
