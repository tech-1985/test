package com.ford.gpcse.bo;

public record ReleaseUsageView(String releaseUsageCode, String releaseUsageName) {
}
