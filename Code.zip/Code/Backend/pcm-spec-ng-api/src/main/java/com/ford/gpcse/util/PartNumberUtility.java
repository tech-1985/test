package com.ford.gpcse.util;

public class PartNumberUtility {

    private PartNumberUtility() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    public static String incrementPartNumber(String pPn) {
        if (pPn.length() < 8) {
            return pPn;
        }

        String strLastChar = pPn.substring(pPn.length() - 1);
        String strNewPn;

        if (strLastChar.matches("[A-Z]")) {
            strNewPn = pPn.substring(0, pPn.length() - 1);

            switch (strLastChar) {
                case "H":
                    strLastChar = "I";
                    break;
                case "N":
                    strLastChar = "O";
                    break;
                case "P":
                    strLastChar = "Q";
                    break;
                case "V":
                    strLastChar = "W";
                    break;
                default:
                    break;
            }
            return strNewPn + (char) (strLastChar.charAt(0) + 1);
        } else if (strLastChar.matches("\\d")) {
            String lastPart = pPn.substring(pPn.length() - 2);
            if (lastPart.matches("\\d{2}")) {
                strNewPn = pPn.substring(0, pPn.length() - 2);
                return strNewPn + (Integer.parseInt(lastPart) + 1);
            } else {
                strNewPn = pPn.substring(0, pPn.length() - 1);
                return strNewPn + (Integer.parseInt(pPn.substring(pPn.length() - 1)) + 1);
            }

        } else {
            return pPn;
        }
    }

}
