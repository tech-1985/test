package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.EditPartRequest;
import com.ford.gpcse.bo.Email;
import com.ford.gpcse.common.Constants;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.exception.UnableToUpdateException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.service.ProceduresService;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

@Service
public class ProceduresServiceImpl implements ProceduresService {

    private static final Logger log = LoggerFactory.getLogger(ProceduresServiceImpl.class);

    private final PartRepository partRepository;
    private final EmailService emailService;

    public ProceduresServiceImpl(PartRepository partRepository, EmailService emailService) {
        this.partRepository = partRepository;
        this.emailService = emailService;
    }

    @Override
    @Transactional
    public void editPart(EditPartRequest editPartRequest) {

        var partsToUpdate = partRepository.findAll(withEditPartCriteria(editPartRequest));

        if (partsToUpdate.isEmpty()) {
            throw new UnableToUpdateException("No parts found to update for the given criteria.");
        }

        for (Part part : partsToUpdate) {
            applyUpdates(part, editPartRequest);
        }

        try {

            var updatedParts = partRepository.saveAll(partsToUpdate);

            if (updatedParts.isEmpty()) {
                throw new UnableToUpdateException("Unable to update Part Number " + editPartRequest.partNumbers().get(0)
                        + ". Internal Error 1298.");
            }

            sendEmailReminderToDr(editPartRequest.partNumbers(), editPartRequest.appEng());

        } catch (DataAccessException e) {
            throw new UnableToUpdateException("Database error while updating Part Number "
                    + editPartRequest.partNumbers().get(0) + ". Internal Error 1298.", e);
        }
    }

    private void applyUpdates(Part part, EditPartRequest editPartRequest) {
        if (editPartRequest.softwarePN() != null) {
            part.setStratCalibPartR(editPartRequest.softwarePN());
        }
        if (editPartRequest.catchWord() != null) {
            part.getCatchword().setCatchwordC(editPartRequest.catchWord());
        }
        if (editPartRequest.concernNumber() != null) {
            part.setConcernC(editPartRequest.concernNumber());
        }
        if (editPartRequest.calibrationNum() != null) {
            part.setCalibR(editPartRequest.calibrationNum());
        }
        if (editPartRequest.wersConcernDescription() != null) {
            part.setCmtX(editPartRequest.wersConcernDescription());
        }
        if (editPartRequest.appEng() != null) {
            part.setEngineerCdsidC(editPartRequest.appEng());
        }
        if (editPartRequest.comments() != null) {
            part.setProcCmtX(editPartRequest.comments());
        }
        if (editPartRequest.buildLevel() != null) {
            part.setBldLvlC(editPartRequest.buildLevel());
        }
        if (editPartRequest.releasePriority() != null) {
            part.setPrtyC(editPartRequest.releasePriority());
        }
        if (editPartRequest.releasePriorityDetail() != null) {
            part.setPrtyDtlX(editPartRequest.releasePriorityDetail());
        }
    }

    private Specification<Part> withEditPartCriteria(EditPartRequest request) {
        return (root, query, criteriaBuilder) -> {
            assert query != null;
            query.distinct(true);
            List<Predicate> predicates = new ArrayList<>();
            addPredicateIfNotNull(predicates, root, criteriaBuilder, Constants.PART_R, request.partNumbers());
            addPredicateIfNotNull(predicates, root, criteriaBuilder, "stratCalibPartR", request.softwarePN());
            addPredicateIfNotNull(predicates, root, criteriaBuilder, "catchword.catchwordC", request.catchWord());
            addPredicateIfNotNull(predicates, root, criteriaBuilder, "concernC", request.concernNumber());
            addPredicateIfNotNull(predicates, root, criteriaBuilder, "calibR", request.calibrationNum());
            addPredicateIfNotNull(predicates, root, criteriaBuilder, "cmtX", request.wersConcernDescription());
            addPredicateIfNotNull(predicates, root, criteriaBuilder, "engineerCdsidC", request.appEng());
            addPredicateIfNotNull(predicates, root, criteriaBuilder, "procCmtX", request.comments());
            addPredicateIfNotNull(predicates, root, criteriaBuilder, "bldLvlC", request.buildLevel());
            addPredicateIfNotNull(predicates, root, criteriaBuilder, "prtyC", request.releasePriority());
            addPredicateIfNotNull(predicates, root, criteriaBuilder, "prtyDtlX", request.releasePriorityDetail());
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }


    private void addPredicateIfNotNull(List<Predicate> predicates, Root<Part> root, CriteriaBuilder criteriaBuilder,
                                       String fieldName, Object value) {
        if (value != null) {
            if (value instanceof List) {
                if (!((List<?>) value).isEmpty()) {
                    predicates.add(root.get(fieldName).in((List<?>) value));
                }
            } else {
                predicates.add(criteriaBuilder.equal(root.get(fieldName), value));
            }
        }
    }

    public void sendEmailReminderToDr(List<String> partNumbers, String appEngineer) {
        try {
            List<Part> parts = partRepository.findAll(engineerNotEqual(appEngineer).and(partNumberIn(partNumbers)));
            for (Part part : parts) {
                String partNumber = part.getPartR();
                String concern = part.getConcernC();

                StringJoiner joiner = new StringJoiner("", "<html><body>", "</body></html>");
                joiner.add("<p>").add(appEngineer + " has requested parts for " + concern + ".</p>")
                        .add("<pre>" + partNumber + "</pre>");
                String emailBody = joiner.toString();

                emailService.sendMail(new Email(List.of(appEngineer),
                        appEngineer + " has requested parts for " + concern + ".", emailBody, "pcserel@ford.com"));

            }
        } catch (Exception e) {
            log.error("Error occurred while sending email reminders: {}", e.getMessage(), e);
        }
    }

    private Specification<Part> engineerNotEqual(String appEngineer) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.notEqual(root.get("engineerCdsidC"), appEngineer);
    }

    private Specification<Part> partNumberIn(List<String> partNumbers) {
        return (root, query, criteriaBuilder) -> root.get(Constants.PART_R).in(partNumbers);
    }
}
