package com.ford.gpcse.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;

/**
 * Configuration class to create RestTemplate instances. This includes a
 * RestTemplate without a proxy and another with a proxy.
 */
@Configuration
public class RestTemplateConfig {

    private final AppConfig appConfig;

    public RestTemplateConfig(AppConfig appConfig) {
        this.appConfig = appConfig;
    }

    /**
     * Creates a basic RestTemplate bean.
     *
     * @return a standard RestTemplate instance.
     */
    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }

    /**
     * Creates a RestTemplate bean configured to use a proxy.
     *
     * @return a RestTemplate instance with proxy settings.
     */
    @Bean
    RestTemplate restTemplateWithProxy() {
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(appConfig.getProxyHost(), appConfig.getProxyPort()));
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setProxy(proxy);
        return new RestTemplate(factory);
    }
}
