package com.ford.gpcse.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "WPCMR22_FIRMWARE_ITM")
public class FirmwareItem {

    @Id
    @Column(name = "PCMR22_FIRMWARE_ITM_X", nullable = false)
    private String firmwareItmX;

    @Column(name = "PCMR03_FIRMWARE_K", nullable = false)
    private Long firmwareK;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PCMR03_FIRMWARE_K", insertable = false, updatable = false)
    private Firmware firmware;

    @Column(name = "PCMR22_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMR22_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR22_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR22_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR22_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    public String getFirmwareItmX() {
        return firmwareItmX;
    }

    public void setFirmwareItmX(String firmwareItmX) {
        this.firmwareItmX = firmwareItmX;
    }

    public Long getFirmwareK() {
        return firmwareK;
    }

    public void setFirmwareK(Long firmwareK) {
        this.firmwareK = firmwareK;
    }

    public Firmware getFirmware() {
        return firmware;
    }

    public void setFirmware(Firmware firmware) {
        this.firmware = firmware;
    }

    public Long getSortOrdR() {
        return sortOrdR;
    }

    public void setSortOrdR(Long sortOrdR) {
        this.sortOrdR = sortOrdR;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }
}
