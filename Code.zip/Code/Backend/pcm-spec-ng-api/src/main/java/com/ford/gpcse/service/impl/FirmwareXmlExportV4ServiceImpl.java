package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import com.ford.gpcse.common.Constants;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.entity.PartFirmware;
import com.ford.gpcse.entity.ProgramDescription;
import com.ford.gpcse.entity.ProgramPart;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.ProgramDescriptionRepository;
import com.ford.gpcse.service.FirmwareXmlExportV4Service;
import com.ford.gpcse.util.CommonUtility;
import com.ford.gpcse.util.DateFormatterUtility;
import com.ford.gpcse.util.FirmwareXmlExportUtility;
import jakarta.persistence.criteria.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class FirmwareXmlExportV4ServiceImpl implements FirmwareXmlExportV4Service {

    private static final Logger log = LoggerFactory.getLogger(FirmwareXmlExportV4ServiceImpl.class);

    private final PartRepository partRepository;
    private final ProgramDescriptionRepository programDescriptionRepository;
    private final PartFirmwareRepository partFirmwareRepository;

    public FirmwareXmlExportV4ServiceImpl(PartRepository partRepository, ProgramDescriptionRepository programDescriptionRepository, PartFirmwareRepository partFirmwareRepository) {
        this.partRepository = partRepository;
        this.programDescriptionRepository = programDescriptionRepository;
        this.partFirmwareRepository = partFirmwareRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public Resource generateFirmwareV4Xml(ExportFirmwareXmlRequest exportFirmwareXmlRequest) {
        var outputStream = new ByteArrayOutputStream();
        try {
            var doc = FirmwareXmlExportUtility.buildDocument();

            var rootElement = doc.createElement("PCMReleases");
            rootElement.setAttribute("xmlns", "http://web.pcm.ford.com/Schema/PCMReleaseV4");
            rootElement.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
            rootElement.setAttribute("Version", "4");
            rootElement.setAttribute("ExportedOn", DateFormatterUtility.formatExportedOn(LocalDateTime.now()));
            rootElement.setAttribute("ExportedBy", CommonUtility.getSafeValue(exportFirmwareXmlRequest.createUser()));
            doc.appendChild(rootElement);

            var parts = partRepository.findAll(buildV4PartSpecification(exportFirmwareXmlRequest));

            if (!parts.isEmpty()) {
                iteratingV4Parts(parts, doc, rootElement);
            }

            var xmlDeclaration = "<?xml version=\"1.0\"?>";
            outputStream.write(xmlDeclaration.getBytes(StandardCharsets.UTF_8));

            var transformer = FirmwareXmlExportUtility.buildTransformer();
            transformer.transform(new DOMSource(doc), new StreamResult(outputStream));

            return new ByteArrayResource(outputStream.toByteArray());
        } catch (Exception e) {
            log.error("Error occurred while generating Firmware V4 Xml : {}", e.getMessage());
        }
        return null;
    }

    private void iteratingV4Parts(List<Part> parts, Document doc, Element rootElement) {
        for (Part part : parts) {
            var pcmElement = doc.createElement("PCMRelease");
            rootElement.appendChild(pcmElement);

            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "PartNumber",
                    CommonUtility.getSafeValue(part.getPartR()));
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ProgramDescription",
                    CommonUtility.getSafeValue(part.getPartNumX()));
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "CatchWord",
                    CommonUtility.getSafeValue(part.getCatchWordC()));
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "CalibrationNumber",
                    CommonUtility.getSafeValue(part.getCalibR()));
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "MainStrategy",
                    CommonUtility.getSafeValue(part.getStratRelC()));
            var approvedDateElement = doc.createElement("ApprovedDate");
            if (part.getReldY() != null) {
                approvedDateElement.setTextContent(
                        CommonUtility.getSafeValue(DateFormatterUtility.dateStringFormat(part.getReldY())));
                approvedDateElement.setAttribute(Constants.SCHEMA_ATTRIBUTE, "false");
            } else {
                approvedDateElement.setAttribute(Constants.SCHEMA_ATTRIBUTE, "true");
            }
            pcmElement.appendChild(approvedDateElement);
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "Production",
                    part.getReleaseUsage() != null && "PROT".equals(part.getReleaseUsage().getRelUsgC()) ? "N" : "Y");
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ConcernNumber",
                    CommonUtility.getSafeValue(part.getConcernC()));
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ReleaseEngineer",
                    CommonUtility.getSafeValue(part.getEngineerCdsidC()));
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ModuleType",
                    CommonUtility.getSafeValue(part.getHardwarePartR()));
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ChipId",
                    CommonUtility.getSafeValue(part.getChipD()));
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "WersNotice",
                    CommonUtility.getSafeValue(DateFormatterUtility.formatWersNotice(part.getWersNtcR())));
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "SoftwarePartNumber",
                    CommonUtility.getSafeValue(part.getStratCalibPartR()));

            var programDescriptions = programDescriptionRepository.findAll(findByV4PartR(part.getPartR()));

            if (!programDescriptions.isEmpty()) {
                iteratingV4ProgramDescriptions(programDescriptions, doc, rootElement);
            }

            var partFirmwares = partFirmwareRepository.findAll(findByV4PartRAndApproved(part.getPartR()));

            if (!partFirmwares.isEmpty()) {
                iteratingV4PartFirmwares(partFirmwares, doc, rootElement);
            }
        }
    }

    private void iteratingV4ProgramDescriptions(List<ProgramDescription> programDescriptions, Document doc,
                                                Element rootElement) {
        for (ProgramDescription programDescription : programDescriptions) {
            var applicationElement = doc.createElement("Application");
            rootElement.appendChild(applicationElement);

            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "ID",
                    programDescription.getPgmK() != null ? String.valueOf(programDescription.getPgmK()) : "");
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "ModelYear",
                    CommonUtility.getSafeValue(programDescription.getMdlYrR()));
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "Program",
                    CommonUtility.getSafeValue(programDescription.getPgmN()));
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "Platform",
                    CommonUtility.getSafeValue(programDescription.getPlatN()));
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "Engine",
                    CommonUtility.getSafeValue(programDescription.getEngN()));
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "Transmission",
                    CommonUtility.getSafeValue(programDescription.getTransN()));
        }
    }

    private void iteratingV4PartFirmwares(List<PartFirmware> partFirmwares, Document doc, Element rootElement) {
        for (PartFirmware partFirmware : partFirmwares) {
            var firmwareElement = doc.createElement("Firmware");
            rootElement.appendChild(firmwareElement);

            FirmwareXmlExportUtility.addChildElement(doc, firmwareElement, "ID",
                    partFirmware.getFirmware() != null && partFirmware.getFirmware().getFirmwareK() != null
                            ? String.valueOf(partFirmware.getFirmware().getFirmwareK())
                            : "");
            FirmwareXmlExportUtility.addChildElement(doc, firmwareElement, "Description",
                    partFirmware.getFirmware() != null
                            ? CommonUtility.getSafeValue(partFirmware.getFirmware().getFirmwareN())
                            : "");
            FirmwareXmlExportUtility.addChildElement(doc, firmwareElement, "Value",
                    CommonUtility.getSafeValue(partFirmware.getFileN()));
            FirmwareXmlExportUtility.addChildElement(doc, firmwareElement, "ApprovedBy",
                    CommonUtility.getSafeValue(partFirmware.getAprvdByCdsidC()));
            var approvedDateElement = doc.createElement("ApprovedDate");
            if (partFirmware.getAprvdY() != null) {
                approvedDateElement.setTextContent(
                        CommonUtility.getSafeValue(DateFormatterUtility.dateStringFormat(partFirmware.getAprvdY())));
                approvedDateElement.setAttribute(Constants.SCHEMA_ATTRIBUTE, "false");
            } else {
                approvedDateElement.setAttribute(Constants.SCHEMA_ATTRIBUTE, "true");
            }
            firmwareElement.appendChild(approvedDateElement);
        }
    }

    private Specification<PartFirmware> findByV4PartRAndApproved(String partR) {
        return (Root<PartFirmware> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            var firmwareJoin = root.join("firmware");
            var partJoin = root.join("part");

            var partRPredicate = criteriaBuilder.equal(partJoin.get(Constants.PART_R), partR);
            var approvedPredicate = criteriaBuilder.isNotNull(root.get("aprvdY"));

            assert query != null;
            query.where(criteriaBuilder.and(partRPredicate, approvedPredicate));

            query.orderBy(criteriaBuilder.asc(firmwareJoin.get("sortOrdR")),
                    criteriaBuilder.asc(firmwareJoin.get("firmwareN")));

            query.multiselect(firmwareJoin.get("firmwareN"), root.get("fileN"), root.get("aprvdByCdsidC"),
                    root.get("aprvdY"), firmwareJoin.get(Constants.FIRMWARE_K));

            return query.getRestriction();
        };
    }

    private Specification<ProgramDescription> findByV4PartR(String partR) {
        return (Root<ProgramDescription> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            assert query != null;

            var subquery = query.subquery(Long.class);
            var programPartRoot = subquery.from(ProgramPart.class);
            var programPartToPart = programPartRoot.join("part");

            subquery.select(programPartRoot.get("pgmK"))
                    .where(criteriaBuilder.equal(programPartToPart.get(Constants.PART_R), partR));

            query.where(criteriaBuilder.in(root.get("pgmK")).value(subquery));

            query.orderBy(criteriaBuilder.asc(root.get("mdlYrR")), criteriaBuilder.asc(root.get("pgmN")),
                    criteriaBuilder.asc(root.get("platN")), criteriaBuilder.asc(root.get("engN")),
                    criteriaBuilder.asc(root.get("transN")));

            return query.getRestriction();
        };
    }

    private Specification<Part> buildV4PartSpecification(ExportFirmwareXmlRequest request) {
        return (root, query, criteriaBuilder) -> {
            var predicates = new ArrayList<>();

            predicates.add(criteriaBuilder.equal(root.get("archF"), "N"));
            predicates.add(criteriaBuilder.not(root.get("statC").in("NewPnRequest", "PeadEdit", "PeadComplete")));

            if (request.partNumbers() != null && !request.partNumbers().isEmpty()) {
                predicates.add(root.get(Constants.PART_R).in(request.partNumbers()));
            }

            if (request.concernNumber() != null && !request.concernNumber().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("concernC"), request.concernNumber()));
            }

            if (request.wersNoticeNumber() != null && !request.wersNoticeNumber().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("wersNtcR"), request.wersNoticeNumber()));
            }

            var microTypeJoin = root.join("microType", JoinType.LEFT);
            assert query != null;
            query.multiselect(root.get(Constants.PART_R), root.get("partNumX"), root.get("catchWordC"),
                    root.get("calibR"), root.get("stratRelC"), root.get("reldY"), root.get("concernC"),
                    root.get("engineerCdsidC"), root.get("hardwarePartR"), root.get("chipD"), root.get("wersNtcR"),
                    root.get("stratCalibPartR"), microTypeJoin.get("microTypX"), root.get("releaseUsage"));

            query.orderBy(criteriaBuilder.asc(root.get(Constants.PART_R)));

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }
}
