package com.ford.gpcse.dto;

import java.time.LocalDate;

public record LookupPartFirmwareDto(String firmwareN, String fileN, String aprvdByCdsidC, String firmwareCatgN,
                                    LocalDate aprvdY) {
}
