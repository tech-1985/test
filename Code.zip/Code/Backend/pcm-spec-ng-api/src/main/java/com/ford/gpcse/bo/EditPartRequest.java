package com.ford.gpcse.bo;

import java.util.List;

public record EditPartRequest(List<String> partNumbers, String softwarePN, String catchWord, String concernNumber,
                              String calibrationNum, String wersConcernDescription, String appEng, String comments,
                              String buildLevel,
                              String releasePriority, String releasePriorityDetail) {
}
