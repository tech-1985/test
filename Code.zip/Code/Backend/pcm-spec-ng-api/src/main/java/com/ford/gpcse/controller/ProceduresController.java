package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.EditPartRequest;
import com.ford.gpcse.service.ProceduresService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for managing procedures related to parts. This class provides an
 * endpoint for editing parts by Software Release Analysts.
 */
@RestController
@RequestMapping("/api/v1/procedures")
@Tag(description = "Edit Part", name = "Procedures Operations")
public class ProceduresController {

    private final ProceduresService proceduresService;

    public ProceduresController(ProceduresService proceduresService) {
        this.proceduresService = proceduresService;
    }

    /**
     * Endpoint to edit a part.
     *
     * @param editPartRequest the request object containing details of the part to
     *                        edit
     * @return a response entity indicating the status of the update
     */
    @TrackExecutionTime
    @LoggingAspect
    @PutMapping("/part")
    @Operation(summary = "Software Release Analyst Section - Edit Part", description = "Enables editing of part by Software Release Analysts.")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")})
    public ResponseEntity<String> editPart(@RequestBody EditPartRequest editPartRequest) {
        proceduresService.editPart(editPartRequest);
        return ResponseEntity.ok().body("Update Complete");
    }
}
