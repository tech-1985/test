package com.ford.gpcse.bo;

import com.ford.gpcse.dto.LookupPartFirmwareDto;

import java.util.List;

public record GroupedFirmwareResponse(String category, List<LookupPartFirmwareDto> firmwares) {
}
