package com.ford.gpcse.dto;

public record FirmwareDto(String partR, String partNumX, String calibR, String stratRelC, String engineerCdsidC,
                          String hardwarePartR, String microTypX, String chipD, String stratCalibPartR,
                          String catchWordC, String relUsgX,
                          String relTypX, String wersNtcR, String concernC, String cmtX, String pwrtrnCalibCdsidC,
                          String suplX,
                          String coreHardwareCdsidC, String coreHardwarePartR) {
}
