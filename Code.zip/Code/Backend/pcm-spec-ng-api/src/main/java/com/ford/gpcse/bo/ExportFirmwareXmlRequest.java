package com.ford.gpcse.bo;

import java.util.List;

public record ExportFirmwareXmlRequest(List<String> partNumbers, String concernNumber, String wersNoticeNumber,
                                       String exportFilename, String exportVersion, String createUser) {
}
