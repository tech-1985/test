package com.ford.gpcse.util;

import com.ford.gpcse.enums.ModuleTypeCode;
import com.ford.gpcse.enums.ReleaseTypeCode;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModuleReleaseTypeUtility {


    private static final Map<String, List<String>> moduleTypeToReleaseTypes = new HashMap<>();

    static {
        moduleTypeToReleaseTypes.put(ModuleTypeCode.PCM.name(),
                List.of(ReleaseTypeCode.AREUL.name(), ReleaseTypeCode.AFD.name(), ReleaseTypeCode.AFDCX.name(),
                        ReleaseTypeCode.AFG.name(), ReleaseTypeCode.AFGO.name(), ReleaseTypeCode.ARNAL.name(),
                        ReleaseTypeCode.HRDCN.name(), ReleaseTypeCode.HARDW.name(), ReleaseTypeCode.HWPT.name(),
                        ReleaseTypeCode.PSUPR.name()));
        moduleTypeToReleaseTypes.put(ModuleTypeCode.GSM.name(), List.of(ReleaseTypeCode.GSMA.name()));
        moduleTypeToReleaseTypes.put(ModuleTypeCode.HPCM.name(),
                List.of(ReleaseTypeCode.HASM.name(), ReleaseTypeCode.HASMS.name()));
        moduleTypeToReleaseTypes.put(ModuleTypeCode.TCM.name(),
                List.of(ReleaseTypeCode.DPS6.name(), ReleaseTypeCode.UTCU2.name(), ReleaseTypeCode.HWUTC.name(),
                        ReleaseTypeCode.TSUPS.name(), ReleaseTypeCode.HWPUT.name(), ReleaseTypeCode.HWCUT.name()));
        moduleTypeToReleaseTypes.put(ModuleTypeCode.TRCM.name(), List.of(ReleaseTypeCode.TRCMA.name()));
        moduleTypeToReleaseTypes.put(ModuleTypeCode.VCM.name(), List.of(ReleaseTypeCode.VCMA.name(),
                ReleaseTypeCode.VCMH.name(), ReleaseTypeCode.VCMHP.name(), ReleaseTypeCode.VCMHC.name()));
        moduleTypeToReleaseTypes.put(ModuleTypeCode.DCU.name(), List.of(ReleaseTypeCode.DCUA.name()));
        moduleTypeToReleaseTypes.put(ModuleTypeCode.DLCM.name(),
                List.of(ReleaseTypeCode.DLCMA.name(), ReleaseTypeCode.DLCMS.name()));
    }

    private ModuleReleaseTypeUtility() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    public static List<String> getReleaseTypesForModuleType(String moduleType) {
        return moduleTypeToReleaseTypes.getOrDefault(moduleType, Collections.emptyList());
    }
}
