package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ProductionPartNumber;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.service.PrismPartNumberSearchExcelService;
import com.ford.gpcse.util.CommonUtility;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class PrismPartNumberSearchExcelServiceImpl implements PrismPartNumberSearchExcelService {

    private static final String[] HEADERS = {"Module File Releasing", "Module Type", "Engine Size",
            "Vehicle Calibration", "WERS Notice", "Calibration Part Number", "Input File", "Module Part Number",
            "Catch Word", "Vehicle Application", "Calibration ID", "Release Usage", "PDX Part Number",
            "Part II Part Number", "Application Signing Key File", "CANID", "SUBNET", "SUBNODE", "SBLMICROID"};

    private final PartRepository partRepository;

    public PrismPartNumberSearchExcelServiceImpl(PartRepository partRepository) {
        this.partRepository = partRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public ByteArrayInputStream exportPrismPartsByPartNumbers(List<ProductionPartNumber> productionPartNumbers)
            throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            var partResults = List.<Object[]>of();
            if (!productionPartNumbers.isEmpty()) {
                partResults = partRepository.fetchAllPrismParts(
                        productionPartNumbers.stream().map(ProductionPartNumber::partNumber).toList(),
                        productionPartNumbers.stream().map(ProductionPartNumber::softwarePN).toList(),
                        productionPartNumbers.stream().map(ProductionPartNumber::wersNotice).toList());
            }
            var verticalSheet = workbook.createSheet("ExportFirmwareVertical");
            fillTheDataInVerticalSheetForPartNumbers(verticalSheet, partResults);
            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    private void fillTheDataInVerticalSheetForPartNumbers(Sheet verticalSheet, List<Object[]> partResults) {
        createVerticalHeaderRowForPartNumbers(verticalSheet);
        var rowNum = 1;
        for (Object[] partResult : partResults) {
            if (partResult != null) {
                var row = verticalSheet.createRow(rowNum++);
                createVerticalDataRowForPartNumbers(partResult, row);
            }
        }
    }

    private void createVerticalDataRowForPartNumbers(Object[] partResult, Row row) {
        row.createCell(0).setCellValue(CommonUtility.getSafeValue(partResult[9]));
        row.createCell(1).setCellValue(CommonUtility.getSafeValue(partResult[6]));
        row.createCell(2).setCellValue(CommonUtility.getSafeValue(partResult[13]));
        row.createCell(3).setCellValue(CommonUtility.getSafeValue(partResult[1]));
        row.createCell(4).setCellValue(CommonUtility.getSafeValue(partResult[2]));
        row.createCell(5).setCellValue(CommonUtility.getSafeValue(partResult[4]));
        row.createCell(6).setCellValue(CommonUtility.getSafeValue(partResult[3]));
        row.createCell(7).setCellValue(CommonUtility.getSafeValue(partResult[0]));
        row.createCell(8).setCellValue(CommonUtility.getSafeValue(partResult[7]));
        row.createCell(9).setCellValue(CommonUtility.getSafeValue(partResult[11]));
        row.createCell(10).setCellValue(CommonUtility.getSafeValue(partResult[5]));
        row.createCell(11).setCellValue(CommonUtility.getSafeValue(partResult[15]));
        row.createCell(12).setCellValue(CommonUtility.getSafeValue(partResult[16]));
        row.createCell(13).setCellValue(CommonUtility.getSafeValue(partResult[17]));
        row.createCell(14).setCellValue(CommonUtility.getSafeValue(partResult[18]));
        row.createCell(15).setCellValue(CommonUtility.getSafeValue(partResult[19]));
        row.createCell(16).setCellValue(CommonUtility.getSafeValue(partResult[22]));
        row.createCell(17).setCellValue(CommonUtility.getSafeValue(partResult[21]));
        row.createCell(18).setCellValue(CommonUtility.getSafeValue(partResult[23]));
    }

    private void createVerticalHeaderRowForPartNumbers(Sheet sheet) {
        var headerRow = sheet.createRow(0);
        headerRow.setHeightInPoints(20);
        var workbook = sheet.getWorkbook();
        var headerStyle = workbook.createCellStyle();
        var font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        var columnIndex = 0;
        for (String header : HEADERS) {
            var cell = headerRow.createCell(columnIndex);
            cell.setCellValue(header);
            cell.setCellStyle(headerStyle);
            var columnWidth = header.length() * 512;
            sheet.setColumnWidth(columnIndex, columnWidth);
            columnIndex++;
        }

    }

}
