package com.ford.gpcse.bo;

public record MicroTypeView(Long microTypeCode, String microTypeName) {
}
