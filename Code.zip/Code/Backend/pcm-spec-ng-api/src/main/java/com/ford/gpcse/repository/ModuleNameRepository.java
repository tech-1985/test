package com.ford.gpcse.repository;

import com.ford.gpcse.entity.ModuleName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for managing ModuleName entities. This interface extends
 * JpaRepository to provide CRUD operations for ModuleName entities.
 */
@Repository
public interface ModuleNameRepository extends JpaRepository<ModuleName, String> {

    /**
     * Fetches a list of active module names. Only modules that are marked as active
     * (actvF = 'Y') will be retrieved.
     *
     * @return A list of active module names sorted by their order and name.
     */
    @Query("SELECT m.moduleN FROM ModuleName m WHERE m.actvF = 'Y' ORDER BY m.sortOrdR, m.moduleN")
    Optional<List<String>> fetchActiveModuleNames();
}
