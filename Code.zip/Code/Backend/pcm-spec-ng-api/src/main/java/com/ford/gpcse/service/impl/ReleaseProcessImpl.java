package com.ford.gpcse.service.impl;

import com.ford.gpcse.entity.PartSignoff;
import com.ford.gpcse.entity.PartSignoffId;
import com.ford.gpcse.enums.ReleaseProcessCode;
import com.ford.gpcse.exception.UnableToInsertException;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.PartSignoffRepository;
import com.ford.gpcse.repository.SignoffRepository;
import com.ford.gpcse.service.ReleaseProcessService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class ReleaseProcessImpl implements ReleaseProcessService {

    private final PartSignoffRepository partSignOffRepository;
    private final PartRepository partRepository;
    private final SignoffRepository signoffRepository;

    public ReleaseProcessImpl(PartSignoffRepository partSignOffRepository, PartRepository partRepository, SignoffRepository signoffRepository) {
        this.partSignOffRepository = partSignOffRepository;
        this.partRepository = partRepository;
        this.signoffRepository = signoffRepository;
    }

    @Override
    @Transactional
    public void setupSignOffProcess(String partNumber, String releaseType, String releaseUsage, String createUser,
                                    String lastUpdateUser) {

        var signoffs = new ArrayList<String>();

        // Calibration Process
        processCalibration(releaseType, signoffs);

        // Hard Lock Process
        processHardLock(releaseUsage, signoffs);

        // Service Action
        if ((!isHardwareReleaseType(releaseType) && !releaseType.equals("SBL"))
                && (releaseUsage.equals("IPF") || releaseUsage.equals("SF") || releaseUsage.equals("PROD"))) {
            signoffs.add(ReleaseProcessCode.ISVAC.name());
        }

        // EOL Process
        if (releaseUsage.equals("IPF")) {
            signoffs.add(ReleaseProcessCode.EOLVO.name());
        }

        // Review Process
        reviewProcess(releaseType, releaseUsage, signoffs);

        if (!signoffs.isEmpty()) {
            addSignOffProcess(partNumber, signoffs, createUser, lastUpdateUser);
        }
    }

    private void addSignOffProcess(String partNumber, List<String> signoffs, String createUser, String lastUpdateUser) {
        signoffs.forEach(signoff -> {
            insertPartSignOffs(partNumber, createUser, lastUpdateUser, signoff);
            if (signoff.equals(ReleaseProcessCode.PEERR.name()) || signoff.equals(ReleaseProcessCode.HWPER.name())
                    || signoff.equals(ReleaseProcessCode.CALUP.name())) {
                updatePartSignOffs(partNumber, signoff);
            }
        });
    }

    private void updatePartSignOffs(String partNumber, String signOffType) {
        var partSignOffsByPartR = partSignOffRepository.findByPartRAndSignOffTypC(partNumber, signOffType);
        partSignOffsByPartR.setUserCdsidC(partRepository.fetchCalibrationCodeByPartR(partNumber));
        partSignOffRepository.save(partSignOffsByPartR);
    }

    private void insertPartSignOffs(String partNumber, String createUser, String lastUpdateUser, String signOffType) {
        var signOff = signoffRepository.findById(signOffType);
        var part = partRepository.findById(partNumber);

        if (signOff.isPresent() && part.isPresent()) {
            var partsignOff = new PartSignoff();
            partsignOff.setId(new PartSignoffId(signOffType, partNumber));
            partsignOff.setSignoff(signOff.get());
            partsignOff.setPart(part.get());
            partsignOff.setUserCdsidC("");
            partsignOff.setDeviatF("N");
            partsignOff.setCreateUserC(createUser);
            partsignOff.setLastUpdtUserC(lastUpdateUser);
            partSignOffRepository.save(partsignOff);
        } else {
            throw new UnableToInsertException("Mandatory Fields Missing");
        }
    }

    private void reviewProcess(String releaseType, String releaseUsage, List<String> signoffs) {
        if (releaseUsage.equals("CERT") || releaseUsage.equals("PREL")) {
            return; // No action for CERT or PREL
        }

        switch (releaseType) {
            case "AREUL", "ARNAL", "AFG", "AFGO", "AFD", "AFDCX", "DCUA", "GDMA", "DLCMA", "DLCMS", "GSMA", "TRCMA",
                 "VCMA",
                 "PMSEA", "NXTPA", "NXFGA", "NXMBA", "UCLSA", "TCCMA", "TCCMS", "GPCMA", "AWDHA", "HASM", "AWDHS",
                 "HASMS", "UTCU2":
                handleReleaseUsageForGroup1(releaseUsage, signoffs);
                break;
            case "PSUPR", "BECMA", "BCCMA", "BCMBA", "BCMIA":
                handleReleaseUsageForGroup2(releaseUsage, signoffs);
                break;
            case "HARDW", "HWPT", "VCMH", "VCMHP", "HWUTC":
                signoffs.addAll(List.of(ReleaseProcessCode.HWPER.name(), ReleaseProcessCode.SUPPR.name()));
                break;
            case "DPS6":
                handleReleaseUsageForDPS6(releaseUsage, signoffs);
                break;
            case "TSUPS":
                handleReleaseUsageForTSUPS(releaseUsage, signoffs);
                break;
            default:
                break;
        }
    }

    private void handleReleaseUsageForGroup1(String releaseUsage, List<String> signoffs) {
        if (releaseUsage.equals("RC") || releaseUsage.equals("PROT")) {
            signoffs.add(ReleaseProcessCode.PEERR.name());
        } else {
            signoffs.addAll(List.of(ReleaseProcessCode.PEERR.name(), ReleaseProcessCode.SUPPR.name(),
                    ReleaseProcessCode.PEERW.name()));
        }
    }

    private void handleReleaseUsageForGroup2(String releaseUsage, List<String> signoffs) {
        if (releaseUsage.equals("RC") || releaseUsage.equals("PROT")) {
            signoffs.add(ReleaseProcessCode.PEERR.name());
        } else {
            signoffs.addAll(List.of(ReleaseProcessCode.PEERR.name(), ReleaseProcessCode.PEERW.name()));
        }
    }

    private void handleReleaseUsageForDPS6(String releaseUsage, List<String> signoffs) {
        if (releaseUsage.equals("RC") || releaseUsage.equals("PROT")) {
            signoffs.add(ReleaseProcessCode.PEERR.name());
        } else if (releaseUsage.equals("SF")) {
            signoffs.addAll(List.of(ReleaseProcessCode.PEERR.name(), ReleaseProcessCode.PEERW.name()));
        } else {
            signoffs.addAll(List.of(ReleaseProcessCode.PEERR.name(), ReleaseProcessCode.SUPPR.name(),
                    ReleaseProcessCode.PEERW.name()));
        }
    }

    private void handleReleaseUsageForTSUPS(String releaseUsage, List<String> signoffs) {
        if (releaseUsage.equals("RC") || releaseUsage.equals("PROT")) {
            signoffs.addAll(List.of(ReleaseProcessCode.PEERR.name(), ReleaseProcessCode.SUPPR.name()));
        } else {
            signoffs.addAll(List.of(ReleaseProcessCode.PEERR.name(), ReleaseProcessCode.SUPPR.name(),
                    ReleaseProcessCode.PEERW.name()));
        }
    }

    private void processCalibration(String releaseType, List<String> signoffs) {
        if (isHardwareReleaseType(releaseType)) {
            signoffs.add(ReleaseProcessCode.CLSUP.name());
        } else {
            signoffs.add(ReleaseProcessCode.CALUP.name());
        }
    }

    private void processHardLock(String releaseUsage, List<String> signoffs) {
        if (releaseUsage.equals("HW")) {
            signoffs.add(ReleaseProcessCode.CLOBD.name());
        } else {
            signoffs.add(ReleaseProcessCode.SUDEP.name());
        }
    }

    private boolean isHardwareReleaseType(String releaseType) {
        return releaseType.equals("HARDW") || releaseType.equals("HWPT");
    }
}
