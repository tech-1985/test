package com.ford.gpcse.bo;

import java.util.List;

public record PartNumberSearchRequest(List<String> releaseTypes, String moduleType, String releaseUsage,
                                      String assemblyPN, String hardwarePN, String softwarePN, String appEng,
                                      String catchWord, String calibrationNum,
                                      String mainStrategy, String concernNumber, String reldF, String createdDateFrom,
                                      String createdDateTo,
                                      String releasedDateFrom, String releasedDateTo) {
}
