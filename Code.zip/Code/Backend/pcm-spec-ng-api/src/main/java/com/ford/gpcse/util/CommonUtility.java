package com.ford.gpcse.util;

import com.ford.gpcse.common.Constants;
import com.ford.gpcse.enums.ReleaseTypeCode;

import java.util.List;

public class CommonUtility {

    private CommonUtility() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    public static String getSafeValue(Object value) {
        return value != null ? value.toString() : "";
    }

    public static String getValidValue(String value) {
        return (value == null || value.isEmpty()) ? Constants.N_A : value;
    }

    public static String getDisplayValue(String code) {
        return code != null ? code : "Unknown";
    }


    public static boolean isHardwareReleaseType(String pReleaseType) {
        return switch (pReleaseType) {
            case "BCCMH", "BCMBH", "BCMIH", "BECMH", "HWPT", "HWUTC", "HWPUT", "HWCUT", "HARDW", "HRDCN", "PMSEH",
                 "NXTPH", "NXFGH", "NXMBH", "UCLSH", "GPCMH", "AWDHH", "HPCMH", "TCCMH", "DCUH", "GDMH", "DLCMH",
                 "GSMH", "TRCMH", "VCMH", "VCMHP", "VCMHC" -> true;
            default -> false;
        };
    }

    public static String getHardwareReleaseType(String releaseTypeCode, String releaseUsageCode) {
        return switch (releaseTypeCode) {
            case "ARNAL", "AFG", "AFGO", "AFD", "AFDCX", "AREUL", "PSUPR" ->
                    releaseUsageCode.equals("PROT") ? "HWPT" : "HARDW";
            case "UTCU2", "TSUPS" -> releaseUsageCode.equals("PROT") ? ReleaseTypeCode.HWPUT.name() : "HWUTC";
            case "BCCMA" -> "BCCMH";
            case "BCMBA" -> "BCMBH";
            case "BCMIA" -> "BCMIH";
            case "BECMA" -> "BECMH";
            case "PMSEA" -> "PMSEH";
            case "NXTPA" -> "NXTPH";
            case "NXFGA" -> "NXFGH";
            case "NXMBA" -> "NXMBH";
            case "UCLSA" -> "UCLSH";
            case "GPCMA" -> "GPCMH";
            case "TCCMA", "TCCMS" -> "TCCMH";
            case "AWDHA", "AWDHS" -> "AWDHH";
            case "HASM", "HASMS" -> "HPCMH";
            case "DCUA" -> "DCUH";
            case "GDMA" -> "GDMH";
            case "DLCMA", "DLCMS" -> "DLCMH";
            case "TRCMA" -> "TRCMH";
            case "VCMA" -> releaseUsageCode.equals("PROT") ? ReleaseTypeCode.VCMHP.name() : "VCMH";
            default -> "";
        };
    }

    public static boolean isValidList(List<?> list) {
        return list != null && !list.isEmpty();
    }

    public static boolean hasPPrefix(String pPn) {
        return pPn != null && pPn.startsWith("P");
    }

    public static String removePFromPrefix(String pPn) {
        if (hasPPrefix(pPn)) {
            return pPn.substring(1);
        } else {
            return pPn;
        }
    }

    public static String releaseStatusText(String releaseStatusCode) {
        return switch (releaseStatusCode) {
            case "NewPnRequest" -> "New Part Number Request";
            case "PeadEdit", "PeadComplete" -> "Module Base Info Edit";
            case "FirmwareEdit" -> "Firmware Edit";
            case "SoftLock" -> "Soft Lock";
            case "HardLock" -> "Hard Lock";
            case "Complete" -> "Release Complete";
            default -> "";
        };
    }


    public static String getStatusDescription(String statC) {
        return switch (statC) {
            case "" -> "";
            case "NewPnRequest" -> "New Part Number Request";
            case "PeadEdit", "PeadComplete" -> "Module Base Info Edit";
            case "FirmwareEdit" -> "Firmware Edit";
            case "SoftLock" -> "Soft Lock";
            case "HardLock" -> "Hard Lock";
            case "Complete" -> "Release Complete";
            default -> statC;
        };
    }
}
