package com.ford.gpcse.common;

public class Constants {

    public static final String INITIAL_REQUEST = "Initial Request";
    public static final String FINAL_RESPONSE = "Final Response";
    public static final String PART_R = "partR";
    public static final String FIRMWARE_K = "firmwareK";
    public static final String SCHEMA_ATTRIBUTE = "xsi:nil";
    public static final String CODE = "Code";
    public static final String DESCRIPTION = "Description";
    public static final String REL_REQ_K = "relReqK";
    public static final String DATE_FORMAT_1 = "MM/dd/yyyy";
    public static final String SOFT_LOCK = "SoftLock";
    public static final String FIRMWARE_EDIT = "FirmwareEdit";
    public static final String HARD_LOCK = "HardLock";
    public static final String NOT_FOUND = " not found.";
    public static final String NO_PARTS_FOUND = "No Parts to display";
    public static final String MODULE_TYPE = "moduleType";
    public static final String MODULE_TYP_C = "moduleTypC";
    public static final String NEW_PN_REQUEST = "NewPnRequest";
    public static final String N_A = "N/A";
    public static final String TBD = "TBD";
    public static final String ERROR_OCCURRED_MSG = "Error occurred: ";

    private Constants() {
        throw new UnsupportedOperationException("Constants class cannot be instantiated");
    }

}
