package com.ford.gpcse.service;

import com.ford.gpcse.bo.*;

import java.util.List;

public interface SearchDataService {

    List<GroupedFirmwareSearchResponse> fetchFirmwareDetailsByWersConcern(String wersConcern);

    List<GroupedFirmwareSearchResponse> fetchFirmwareDetailsByWersNotice(String wersNotice);

    List<FirmwareResponse> fetchFirmwareDetailsByPrograms(List<Long> programKeys);

    List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(PartNumberSearchRequest partNumberSearchRequest);

    List<ReleaseRequestOutput> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput);

    List<ProductionPartNumberSearchResponse> fetchProductionPartNumber(
            ProductionPartNumberSearchRequest productionPartNumberSearchRequest);

    String fetchWersTextByConcern(String wersConcern);

    List<ReleaseStatusConcernResponse> fetchReleaseStatusDetailsByWersConcern(String wersConcern);
}
