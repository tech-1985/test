package com.ford.gpcse.enums;

public enum ReleaseProcessCode {
    CALUP, CLSUP, CLOBD, SUDEP, CLDEP, VBFUL, DCUUL, PEERR, SUPPR, PEERW, SWBLD, PRBLD, PRDWL, SWWER, SSBLD, SWDRW,
    TELGR, IVSSB, SRPUL, IVSAB, IVSEM, IVSXM, ISVAC, HWPER, EOLVO;

}
