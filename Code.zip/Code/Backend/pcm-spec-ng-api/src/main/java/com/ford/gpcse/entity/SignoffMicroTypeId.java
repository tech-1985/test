package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.util.Objects;

@Embeddable
public class SignoffMicroTypeId {

    @Column(name = "PCMR20_SIGNOFF_TYP_C", nullable = false, length = 5)
    private String signoffTypC;

    @Column(name = "PCMR19_MICRO_TYP_C", nullable = false, length = 5)
    private Long microTypC;

    public SignoffMicroTypeId() {
    }

    public SignoffMicroTypeId(String signoffTypC, Long microTypC) {
        this.signoffTypC = signoffTypC;
        this.microTypC = microTypC;
    }

    public String getSignoffTypC() {
        return signoffTypC;
    }

    public void setSignoffTypC(String signoffTypC) {
        this.signoffTypC = signoffTypC;
    }

    public Long getMicroTypC() {
        return microTypC;
    }

    public void setMicroTypC(Long microTypC) {
        this.microTypC = microTypC;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        SignoffMicroTypeId that = (SignoffMicroTypeId) o;
        return Objects.equals(signoffTypC, that.signoffTypC) && Objects.equals(microTypC, that.microTypC);
    }

    @Override
    public int hashCode() {
        return Objects.hash(signoffTypC, microTypC);
    }
}
