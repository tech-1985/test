package com.ford.gpcse.bo;

import java.util.List;

public record ReplacePblRequest(String newPbl, String moduleTypeCode, String createUser, String lastUpdateUser,
                                List<String> partNumbers) {
}
