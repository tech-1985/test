package com.ford.gpcse.bo;

public record ModuleTypeView(String moduleTypeCode, String moduleTypeName) {
}
