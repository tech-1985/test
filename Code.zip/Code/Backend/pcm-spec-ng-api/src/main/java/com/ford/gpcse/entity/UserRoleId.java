package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.util.Objects;

@Embeddable
public class UserRoleId {

    @Column(name = "PCM001_USER_CDSID_C", length = 8, nullable = false)
    private String userCdsidC;

    @Column(name = "PCM002_ROLE_K", nullable = false)
    private Long roleK;

    public UserRoleId() {

    }

    public UserRoleId(String userCdsidC, Long roleK) {
        this.userCdsidC = userCdsidC;
        this.roleK = roleK;
    }

    public String getUserCdsidC() {
        return userCdsidC;
    }

    public void setUserCdsidC(String userCdsidC) {
        this.userCdsidC = userCdsidC;
    }

    public Long getRoleK() {
        return roleK;
    }

    public void setRoleK(Long roleK) {
        this.roleK = roleK;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        UserRoleId that = (UserRoleId) o;
        return Objects.equals(userCdsidC, that.userCdsidC) && Objects.equals(roleK, that.roleK);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userCdsidC, roleK);
    }
}
