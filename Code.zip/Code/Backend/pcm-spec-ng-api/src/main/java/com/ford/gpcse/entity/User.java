package com.ford.gpcse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "WPCM001_USER")
public class User {
    @Id
    @Column(name = "PCM001_USER_CDSID_C", length = 8, nullable = false)
    private String userCdsidC;

    @OneToMany(mappedBy = "user")
    private List<UserRole> userRoles;

    @Column(name = "PCM001_USER_N", length = 60)
    private String userN;

    @Column(name = "PCM001_EMAIL_ADDR_X", length = 100, nullable = false)
    private String emailAddrX;

    @Column(name = "PCM001_ARCH_F", length = 1, nullable = false)
    private String archF;

    @Column(name = "PCM001_PASSWORD_X", length = 40)
    private String passwordX;

    @Column(name = "PCM001_COMP_N", length = 50)
    private String compN;

    @Column(name = "PCM001_CMT_X", length = 100)
    private String cmtX;

    @Column(name = "PCM001_CREATE_USER_C", length = 8, nullable = false)
    private String createUserC;

    @NotNull
    @CreationTimestamp
    @Column(name = "PCM001_CREATE_S", nullable = false, updatable = false)
    private LocalDateTime createS;

    @Column(name = "PCM001_LAST_UPDT_USER_C", length = 8, nullable = false)
    private String lastUpdtUserC;

    @NotNull
    @UpdateTimestamp
    @Column(name = "PCM001_LAST_UPDT_S", nullable = false)
    private LocalDateTime lastUpdtS;

    @Column(name = "PCM001_PASSWORD_EXP_Y", nullable = false)
    private LocalDateTime passwordExpY;

    @Column(name = "PCM001_USER_DOMAIN_C", length = 10)
    private String userDomainC;

    @Column(name = "PCM001_USER_SECUR_D", length = 60)
    private String userSecurD;

    @Column(name = "PCM001_FRST_N", length = 25)
    private String frstN;

    @Column(name = "PCM001_LST_N", length = 25)
    private String lstN;

    public String getUserCdsidC() {
        return userCdsidC;
    }

    public void setUserCdsidC(String userCdsidC) {
        this.userCdsidC = userCdsidC;
    }

    public List<UserRole> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(List<UserRole> userRoles) {
        this.userRoles = userRoles;
    }

    public String getUserN() {
        return userN;
    }

    public void setUserN(String userN) {
        this.userN = userN;
    }

    public String getEmailAddrX() {
        return emailAddrX;
    }

    public void setEmailAddrX(String emailAddrX) {
        this.emailAddrX = emailAddrX;
    }

    public String getArchF() {
        return archF;
    }

    public void setArchF(String archF) {
        this.archF = archF;
    }

    public String getPasswordX() {
        return passwordX;
    }

    public void setPasswordX(String passwordX) {
        this.passwordX = passwordX;
    }

    public String getCompN() {
        return compN;
    }

    public void setCompN(String compN) {
        this.compN = compN;
    }

    public String getCmtX() {
        return cmtX;
    }

    public void setCmtX(String cmtX) {
        this.cmtX = cmtX;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }

    public LocalDateTime getPasswordExpY() {
        return passwordExpY;
    }

    public void setPasswordExpY(LocalDateTime passwordExpY) {
        this.passwordExpY = passwordExpY;
    }

    public String getUserDomainC() {
        return userDomainC;
    }

    public void setUserDomainC(String userDomainC) {
        this.userDomainC = userDomainC;
    }

    public String getUserSecurD() {
        return userSecurD;
    }

    public void setUserSecurD(String userSecurD) {
        this.userSecurD = userSecurD;
    }

    public String getFrstN() {
        return frstN;
    }

    public void setFrstN(String frstN) {
        this.frstN = frstN;
    }

    public String getLstN() {
        return lstN;
    }

    public void setLstN(String lstN) {
        this.lstN = lstN;
    }
}
