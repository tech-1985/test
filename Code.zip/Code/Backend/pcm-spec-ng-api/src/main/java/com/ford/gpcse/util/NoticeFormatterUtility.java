package com.ford.gpcse.util;

public class NoticeFormatterUtility {
    private NoticeFormatterUtility() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    public static String formatWersNotice(String wersNotice) {
        if (wersNotice == null || wersNotice.trim().length() < 16) {
            return null;
        }
        wersNotice = wersNotice.replace(" ", "").replace("-", "").trim();
        return wersNotice.length() >= 16 ? wersNotice.substring(0, 16) + "%" : null;
    }

    public static String wersNoticeFormatDatabase(String pWersNotice) {
        String tmp = pWersNotice;
        if (tmp == null) {
            tmp = "";
        }
        tmp = tmp.trim().replace(" ", "").replace("-", "");
        if (tmp.length() < 16) {
            return null;
        } else {
            return tmp.substring(0, 16);
        }
    }


    public static String formatNotice(String notice) {
        if (notice.length() == 16) {
            return String.format("%s %s %s %s", notice.substring(0, 4), notice.charAt(4), notice.substring(5, 13),
                    notice.substring(13, 16));
        }
        return notice;
    }

}
