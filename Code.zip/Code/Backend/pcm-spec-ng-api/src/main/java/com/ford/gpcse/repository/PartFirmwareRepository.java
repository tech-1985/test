package com.ford.gpcse.repository;

import com.ford.gpcse.common.Constants;
import com.ford.gpcse.dto.LookupPartFirmwareDto;
import com.ford.gpcse.entity.PartFirmware;
import com.ford.gpcse.entity.PartFirmwareId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for managing PartFirmware entities. This interface
 * extends JpaRepository for CRUD operations and JpaSpecificationExecutor for
 * dynamic queries.
 */
@Repository
public interface PartFirmwareRepository
        extends JpaRepository<PartFirmware, PartFirmwareId>, JpaSpecificationExecutor<PartFirmware> {

    /**
     * Counts the number of PartFirmware entries by the given file name.
     *
     * @param fileN The file name to count entries for.
     * @return The number of PartFirmware entries with the specified file name.
     */
    @Query("SELECT COUNT(f) FROM PartFirmware f WHERE f.fileN = :fileN")
    Long countByfileN(@Param("fileN") String fileN);

    /**
     * Counts the number of PartFirmware entries associated with a specific part
     * number.
     *
     * @param partR The part number to count entries for.
     * @return The count of PartFirmware entries for the specified part number.
     */
    @Query(value = "SELECT COUNT(PCMR03_FIRMWARE_K) FROM WPCMR02_PART_FIRMWARE WHERE PCMR01_PART_R = :partR", nativeQuery = true)
    Long countByPartR(@Param("partR") String partR);

    /**
     * Counts the number of review sign-offs associated with a specific part number.
     *
     * @param partR The part number to check for review sign-offs.
     * @return The count of review sign-offs for the specified part number.
     */
    @Query(value = "SELECT count(PCMR01_PART_R) FROM WPCMR21_SIGNOFF_PART tblA WHERE tblA.PCMR01_PART_R = :partR AND  tblA.PCMR20_SIGNOFF_TYP_C IN ('SUPPR', 'PEERR', 'PEERA', 'HWPER', 'IVSEM')", nativeQuery = true)
    Long countByPartRHasReviewSignOff(@Param("partR") String partR);

    /**
     * Fetches PartFirmware entries by part number, returning specific details in a
     * DTO.
     *
     * @param partR The part number to fetch firmware details for.
     * @return A list of LookupPartFirmwareDto containing firmware details for the
     * specified part number.
     */
    @Query("SELECT new com.ford.gpcse.dto.LookupPartFirmwareDto(f.firmwareN, pf.fileN, pf.aprvdByCdsidC, f.firmwareCatgN, pf.aprvdY) "
            + "FROM PartFirmware pf " + "INNER JOIN Firmware f ON pf.firmware.firmwareK = f.firmwareK "
            + "WHERE pf.part.partR = :partR " + "ORDER BY f.sortOrdR, f.firmwareCatgN, f.firmwareN")
    List<LookupPartFirmwareDto> fetchPartFirmwareByPartNumber(@Param(Constants.PART_R) String partR);

    /**
     * Finds all firmware associated with a list of part numbers.
     *
     * @param partNumbers A list of part numbers to find firmware for.
     * @return A list of object arrays containing part numbers, firmware keys, and
     * file names.
     */
    @Query(value = "SELECT pf.PCMR01_PART_R, pf.PCMR03_FIRMWARE_K, pf.PCMR02_FILE_N "
            + "FROM WPCMR02_PART_FIRMWARE pf "
            + "INNER JOIN WPCMR03_FIRMWARE f ON pf.PCMR03_FIRMWARE_K = f.PCMR03_FIRMWARE_K "
            + "WHERE pf.PCMR01_PART_R IN (:partNumbers) "
            + "AND pf.PCMR02_APRVD_Y IS NOT NULL "
            + "ORDER BY pf.PCMR01_PART_R, f.PCMR03_SORT_ORD_R", nativeQuery = true)
    List<Object[]> findAllFirmwareByParts(@Param("partNumbers") List<String> partNumbers);

}
