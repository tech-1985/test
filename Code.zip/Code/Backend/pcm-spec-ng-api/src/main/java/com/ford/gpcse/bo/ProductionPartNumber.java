package com.ford.gpcse.bo;

public record ProductionPartNumber(String partNumber, String catchWord, String calibrationNumber, String softwarePN,
                                   String hardwarePN, String mainMicroType, String wersNotice) {
}
