package com.ford.gpcse.dto;

public record MainMicroTypeDto(String signoffTypC, Long microTypC, String microTypX, String ownerCdsId,
                               String signoffTypX) {
}
