package com.ford.gpcse.repository;

import com.ford.gpcse.common.Constants;
import com.ford.gpcse.entity.PartSignoff;
import com.ford.gpcse.entity.PartSignoffId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * Repository interface for accessing PartSignoff entities. Extends
 * JpaRepository to provide CRUD operations.
 */
@Repository
public interface PartSignoffRepository extends JpaRepository<PartSignoff, PartSignoffId> {

    /**
     * Updates the userCdsidC field of PartSignoff entries.
     *
     * @param signoffType the type of signoff to filter by
     * @param partR       the part reference used to find the engineer's cdsid
     * @return the number of entities updated
     */
    @Modifying
    @Transactional
    @Query("UPDATE PartSignoff ps SET ps.userCdsidC = "
            + "(SELECT p.engineerCdsidC FROM ps.part p WHERE p.partR = :partR) "
            + "WHERE ps.signoff.signoffTypC = :signoffType " + "AND ps.signoffS IS NULL")
    int updateUserCdsidCForSignoffs(@Param("signoffType") String signoffType, @Param(Constants.PART_R) String partR);

    /**
     * Retrieves a PartSignoff entity based on part reference and signoff type.
     *
     * @param partR       the part reference to filter by
     * @param signoffTypC the type of signoff to filter by
     * @return the matching PartSignoff entity, or null if not found
     */
    @Query("SELECT ps FROM PartSignoff ps WHERE ps.part.partR = :partR AND ps.signoff.signoffTypC=:signoffTypC")
    PartSignoff findByPartRAndSignOffTypC(@Param("partR") String partR, @Param("signoffTypC") String signoffTypC);
}
