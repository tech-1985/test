package com.ford.gpcse.external.vsem.service.impl;

import com.ford.gpcse.bo.TokenResponse;
import com.ford.gpcse.config.AppConfig;
import com.ford.gpcse.exception.AuthServiceException;
import com.ford.gpcse.external.vsem.service.AuthService;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * Implementation of the AuthService interface for fetching authentication
 * tokens. This service communicates with an OAuth2 provider to obtain a token
 * using client credentials.
 */
@Service
public class AuthServiceImpl implements AuthService {

    private final AppConfig appConfig;
    private final RestTemplate restTemplateWithProxy;

    public AuthServiceImpl(AppConfig appConfig, RestTemplate restTemplateWithProxy) {
        this.appConfig = appConfig;
        this.restTemplateWithProxy = restTemplateWithProxy;
    }

    /**
     * Fetches an OAuth2 token using client credentials.
     *
     * @return TokenResponse containing the access token and other details
     * @throws RuntimeException if there is an error during the token fetching
     *                          process
     */
    @Override
    public TokenResponse fetchToken() {
        var requestBody = new LinkedMultiValueMap<String, String>();
        requestBody.add("grant_type", "client_credentials");
        requestBody.add("client_id", appConfig.getClientId());
        requestBody.add("client_secret", appConfig.getClientSecret());
        requestBody.add("scope", appConfig.getResource());

        var headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        var requestEntity = new HttpEntity<MultiValueMap<String, String>>(requestBody, headers);

        try {
            var response = restTemplateWithProxy.exchange(appConfig.getOauthUrl(), HttpMethod.POST, requestEntity,
                    TokenResponse.class);

            return response.getBody();
        } catch (RestClientException e) {
            throw new AuthServiceException("Error fetching token", e);
        }
    }
}
