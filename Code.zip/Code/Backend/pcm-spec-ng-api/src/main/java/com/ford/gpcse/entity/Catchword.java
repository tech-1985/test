package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "WPCMR08_CATCHWORD")
public class Catchword {
    @Id
    @Column(name = "PCMR08_CATCHWORD_C", nullable = false)
    private String catchwordC;
    @Column(name = "PCMR08_CATCHWORD_TYP_C")
    private String catchwordTypC;

    @Column(name = "PCMR08_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR08_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR08_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR08_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    public String getCatchwordC() {
        return catchwordC;
    }

    public void setCatchwordC(String catchwordC) {
        this.catchwordC = catchwordC;
    }

    public String getCatchwordTypC() {
        return catchwordTypC;
    }

    public void setCatchwordTypC(String catchwordTypC) {
        this.catchwordTypC = catchwordTypC;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }
}
