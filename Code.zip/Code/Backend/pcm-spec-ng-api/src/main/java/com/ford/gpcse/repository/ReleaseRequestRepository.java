package com.ford.gpcse.repository;

import com.ford.gpcse.entity.ReleaseRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for accessing ReleaseRequest entities. Extends
 * JpaRepository for standard CRUD operations and JpaSpecificationExecutor for
 * dynamic queries.
 */
@Repository
public interface ReleaseRequestRepository
        extends JpaRepository<ReleaseRequest, Long>, JpaSpecificationExecutor<ReleaseRequest> {

    /**
     * Retrieves all ReleaseRequest entities ordered by their release request key in
     * descending order.
     *
     * @return a list of ReleaseRequest entities ordered by relReqK
     */
    Optional<List<ReleaseRequest>> findAllByOrderByRelReqKDesc();

    /**
     * Retrieves Release Request Details based on id.
     *
     * @return a Release Request
     */
    Optional<ReleaseRequest> findByRelReqK(Long id);

    @Query(value = "SELECT " + "tblR48.PCMR48_REL_REQ_K, " + "tblS01.PCMS01_MDL_YR_R, " + "tblS01.PCMS01_PGM_N, "
            + "PCMR48_CAL_REL_Y, " + "(SELECT MAX(PCMF52_LOG_DATE_S) " + " FROM WPCMR52_RELEASE_REQUEST_STATUS_LOG "
            + " WHERE PCMR48_REL_REQ_K = tblR48.PCMR48_REL_REQ_K) AS StateChange, " + "tblR48.PCMR48_STATUS_C "
            + "FROM WPCMR48_RELEASE_REQUEST tblR48 "
            + "LEFT JOIN WPCMR49_PGM_RELEASE_REQUEST tblR49 ON tblR48.PCMR48_REL_REQ_K = tblR49.PCMR48_REL_REQ_K "
            + "LEFT JOIN WPCMS01_PGM_DESC tblS01 ON tblS01.PCMS01_PGM_K = tblR49.PCMS01_PGM_K " + "WHERE ("
            + "(tblR48.PCMR48_STATUS_C = 'New' AND UPPER(tblR48.PCMF48_CREATE_USER_C) = UPPER(:userId)) "
            + "OR (tblR48.PCMR48_STATUS_C = 'Project Control' AND UPPER(tblR48.PCMR48_PROJECT_CONTROL_C) = UPPER(:userId)) "
            + "OR (tblR48.PCMR48_STATUS_C = 'D&R Engineer' AND UPPER(tblR48.PCMR48_APP_DR_ENG_C) = UPPER(:userId)) "
            + "OR (tblR48.PCMR48_STATUS_C = 'Cal Release Engineer' AND UPPER(tblR48.PCMR48_CAL_REL_SUPPORT_C) = UPPER(:userId)) "
            + ") "
            + "ORDER BY tblR48.PCMR48_REL_REQ_K, tblS01.PCMS01_MDL_YR_R, tblS01.PCMS01_PGM_N", nativeQuery = true)
    List<Object[]> findReleaseRequestsByUserId(@Param("userId") String userId);
}
