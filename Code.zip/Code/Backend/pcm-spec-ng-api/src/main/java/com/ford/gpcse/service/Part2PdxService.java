package com.ford.gpcse.service;

import com.ford.gpcse.bo.Part2PdxRequest;

public interface Part2PdxService {

    String addNewPart2OrPdx(Part2PdxRequest part2PdxRequest);

}
