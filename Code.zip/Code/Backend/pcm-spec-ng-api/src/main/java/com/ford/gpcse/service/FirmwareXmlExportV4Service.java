package com.ford.gpcse.service;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import org.springframework.core.io.Resource;

public interface FirmwareXmlExportV4Service {
    Resource generateFirmwareV4Xml(ExportFirmwareXmlRequest exportFirmwareXmlRequest);
}
