package com.ford.gpcse.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "WPCMR23_REL_TYP_FIRMWARE")
public class ReleaseTypeFirmware {

    @EmbeddedId
    private ReleaseTypeFirmwareId id;

    @ManyToOne
    @JoinColumn(name = "PCMR15_REL_TYP_C", referencedColumnName = "PCMR15_REL_TYP_C", insertable = false, updatable = false)
    private ReleaseType releaseType;

    @ManyToOne
    @JoinColumn(name = "PCMR03_FIRMWARE_K", referencedColumnName = "PCMR03_FIRMWARE_K", insertable = false, updatable = false)
    private Firmware firmware;

    @Column(name = "PCMR23_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR23_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR23_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR23_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    public ReleaseTypeFirmwareId getId() {
        return id;
    }

    public void setId(ReleaseTypeFirmwareId id) {
        this.id = id;
    }

    public ReleaseType getReleaseType() {
        return releaseType;
    }

    public void setReleaseType(ReleaseType releaseType) {
        this.releaseType = releaseType;
    }

    public Firmware getFirmware() {
        return firmware;
    }

    public void setFirmware(Firmware firmware) {
        this.firmware = firmware;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }
}
