package com.ford.gpcse.dto;

public record ReleaseRequestDTO(String requestId, String modelYear, String program, String cfX, String stateChange,
                                String status) {
}
