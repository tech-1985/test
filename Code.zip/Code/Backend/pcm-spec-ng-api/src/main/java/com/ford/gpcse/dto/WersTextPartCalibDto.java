package com.ford.gpcse.dto;

public record WersTextPartCalibDto(String partR, String replacedPartR, String catchwordC, String partNumX,
                                   String calibR, String hardwarePartR, String statC, String oldCal, String oldCw) {
}
