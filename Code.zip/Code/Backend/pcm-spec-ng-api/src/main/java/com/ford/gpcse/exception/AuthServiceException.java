package com.ford.gpcse.exception;

import java.io.Serial;

public class AuthServiceException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = -8762906415016361945L;

    public AuthServiceException(String message) {
        super(message);
    }

    public AuthServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
