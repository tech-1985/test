package com.ford.gpcse.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "WPCMR02_PART_FIRMWARE")
public class PartFirmware {

    @EmbeddedId
    private PartFirmwareId partFirmwareId;

    @ManyToOne
    @JoinColumn(name = "PCMR01_PART_R", referencedColumnName = "PCMR01_PART_R", insertable = false, updatable = false)
    private Part part;

    @ManyToOne
    @JoinColumn(name = "PCMR03_FIRMWARE_K", referencedColumnName = "PCMR03_FIRMWARE_K", insertable = false, updatable = false)
    private Firmware firmware;

    @Column(name = "PCMR02_FILE_N", length = 66)
    private String fileN;

    @Column(name = "PCMR02_APRVD_BY_CDSID_C", length = 8)
    private String aprvdByCdsidC;
    @Column(name = "PCMR02_APRVD_Y")
    private LocalDate aprvdY;

    @Column(name = "PCMR02_REQT_Y")
    private LocalDate reqtY;

    @Column(name = "PCMR02_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR02_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR02_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR02_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    @Column(name = "PCMR02_FILE_U", length = 2000)
    private String fileU;

    @Lob
    @Column(name = "PCMR02_FILE_L")
    private byte[] fileL;

    public PartFirmwareId getPartFirmwareId() {
        return partFirmwareId;
    }

    public void setPartFirmwareId(PartFirmwareId partFirmwareId) {
        this.partFirmwareId = partFirmwareId;
    }

    public Part getPart() {
        return part;
    }

    public void setPart(Part part) {
        this.part = part;
    }

    public Firmware getFirmware() {
        return firmware;
    }

    public void setFirmware(Firmware firmware) {
        this.firmware = firmware;
    }

    public String getFileN() {
        return fileN;
    }

    public void setFileN(String fileN) {
        this.fileN = fileN;
    }

    public String getAprvdByCdsidC() {
        return aprvdByCdsidC;
    }

    public void setAprvdByCdsidC(String aprvdByCdsidC) {
        this.aprvdByCdsidC = aprvdByCdsidC;
    }

    public LocalDate getAprvdY() {
        return aprvdY;
    }

    public void setAprvdY(LocalDate aprvdY) {
        this.aprvdY = aprvdY;
    }

    public LocalDate getReqtY() {
        return reqtY;
    }

    public void setReqtY(LocalDate reqtY) {
        this.reqtY = reqtY;
    }

    public String getCreateUserC() {
        return createUserC;
    }

    public void setCreateUserC(String createUserC) {
        this.createUserC = createUserC;
    }

    public LocalDateTime getCreateS() {
        return createS;
    }

    public void setCreateS(LocalDateTime createS) {
        this.createS = createS;
    }

    public String getLastUpdtUserC() {
        return lastUpdtUserC;
    }

    public void setLastUpdtUserC(String lastUpdtUserC) {
        this.lastUpdtUserC = lastUpdtUserC;
    }

    public LocalDateTime getLastUpdtS() {
        return lastUpdtS;
    }

    public void setLastUpdtS(LocalDateTime lastUpdtS) {
        this.lastUpdtS = lastUpdtS;
    }

    public String getFileU() {
        return fileU;
    }

    public void setFileU(String fileU) {
        this.fileU = fileU;
    }

    public byte[] getFileL() {
        return fileL;
    }

    public void setFileL(byte[] fileL) {
        this.fileL = fileL;
    }
}