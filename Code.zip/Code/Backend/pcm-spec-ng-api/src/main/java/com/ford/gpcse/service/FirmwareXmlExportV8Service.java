package com.ford.gpcse.service;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import org.springframework.core.io.Resource;

public interface FirmwareXmlExportV8Service {
    Resource generateFirmwareV8Xml(ExportFirmwareXmlRequest exportFirmwareXmlRequest);
}
