package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.util.Objects;

@Embeddable
public class FirmwareRoleId {

    @Column(name = "PCMR03_FIRMWARE_K", nullable = false)
    private Long firmwareK;

    @Column(name = "PCM002_ROLE_K", nullable = false)
    private Long roleK;

    public FirmwareRoleId() {

    }

    public FirmwareRoleId(Long firmwareK, Long roleK) {
        super();
        this.firmwareK = firmwareK;
        this.roleK = roleK;
    }

    public Long getFirmwareK() {
        return firmwareK;
    }

    public void setFirmwareK(Long firmwareK) {
        this.firmwareK = firmwareK;
    }

    public Long getRoleK() {
        return roleK;
    }

    public void setRoleK(Long roleK) {
        this.roleK = roleK;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        FirmwareRoleId that = (FirmwareRoleId) o;
        return Objects.equals(firmwareK, that.firmwareK) && Objects.equals(roleK, that.roleK);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firmwareK, roleK);
    }
}
