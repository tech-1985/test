package com.ford.gpcse.external.email.service.impl;

import com.ford.gpcse.bo.Email;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class EmailServiceImplTest {

    @Mock
    private JavaMailSender emailSender;

    @InjectMocks
    private EmailServiceImpl emailService;

    private Email email;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        email = new Email(List.of("recipient@example.com"), "Test Subject", "<h1>Test Body</h1>", "sender@example.com");

    }

    @Test
    void testSendMailSuccess() throws MessagingException {
        // Arrange
        MimeMessage mimeMessage = mock(MimeMessage.class);
        when(emailSender.createMimeMessage()).thenReturn(mimeMessage);

        // Use a real MimeMessageHelper to avoid issues with mocking
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
        helper.setTo(email.to().toArray(String[]::new));
        helper.setSubject(email.subject());
        helper.setText(email.body(), true);
        helper.setFrom(email.from());

        // Act
        boolean result = emailService.sendMail(email);

        // Assert
        assertTrue(result);

    }

}
