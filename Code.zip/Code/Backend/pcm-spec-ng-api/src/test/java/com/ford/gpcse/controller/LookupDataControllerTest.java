package com.ford.gpcse.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gpcse.bo.*;
import com.ford.gpcse.dto.*;
import com.ford.gpcse.service.LookupDataService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class LookupDataControllerTest {

    @Mock
    private LookupDataService lookupDataService;

    @InjectMocks
    private LookupDataController lookupDataController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        // Set up MockMvc with the controller under test
        mockMvc = MockMvcBuilders.standaloneSetup(lookupDataController).build();
    }

    @Test
    void testFetchActiveSuppliers() throws Exception {
        // Mock service method
        List<SupplierView> suppliers = List.of(new SupplierView("Bosch", "Bosch"),
                new SupplierView("Delphi", "Delphi"));
        when(lookupDataService.fetchActiveSuppliers()).thenReturn(suppliers);

        // Perform test with MockMvc
        mockMvc.perform(get("/api/v1/lookup/suppliers")).andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].supplierName", is("Bosch")))
                .andExpect(jsonPath("$[0].supplierCode", is("Bosch")))
                .andExpect(jsonPath("$[1].supplierName", is("Delphi")))
                .andExpect(jsonPath("$[1].supplierCode", is("Delphi")));
    }

    @Test
    void testFetchActiveModuleTypes() throws Exception {
        List<ModuleTypeView> moduleTypes = List.of(new ModuleTypeView("BCCMI", "BCCMI"),
                new ModuleTypeView("AWDCH", "AWDCH"));
        when(lookupDataService.fetchActiveModuleTypes()).thenReturn(moduleTypes);

        mockMvc.perform(get("/api/v1/lookup/module-types")).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].moduleTypeCode", is("BCCMI")))
                .andExpect(jsonPath("$[0].moduleTypeName", is("BCCMI")))
                .andExpect(jsonPath("$[1].moduleTypeCode", is("AWDCH")))
                .andExpect(jsonPath("$[1].moduleTypeName", is("AWDCH")));
    }

    @Test
    void testFetchReleasedMicroTypesByModuleType() throws Exception {
        List<MicroTypeView> microTypes = List.of(new MicroTypeView(1L, "SPANISH OAK 1024"),
                new MicroTypeView(2L, "MPC-563 Green Oak"));
        when(lookupDataService.fetchReleasedMicroTypesByModuleType("BCCMI")).thenReturn(microTypes);

        mockMvc.perform(get("/api/v1/lookup/micro-types").param("moduleTypeCode", "BCCMI")).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].microTypeCode", is(1)))
                .andExpect(jsonPath("$[0].microTypeName", is("SPANISH OAK 1024")))
                .andExpect(jsonPath("$[1].microTypeCode", is(2)))
                .andExpect(jsonPath("$[1].microTypeName", is("MPC-563 Green Oak")));
    }

    @Test
    void testFetchActiveMicroNames() throws Exception {
        List<String> microNames = List.of("MicroName1", "MicroName2");
        when(lookupDataService.fetchActiveMicroNames()).thenReturn(microNames);

        mockMvc.perform(get("/api/v1/lookup/micro-names")).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0]", is("MicroName1")))
                .andExpect(jsonPath("$[1]", is("MicroName2")));
    }

    @Test
    void testFetchActiveModuleNames() throws Exception {
        List<String> moduleNames = List.of("ModuleName1", "ModuleName2");
        when(lookupDataService.fetchActiveModuleNames()).thenReturn(moduleNames);

        mockMvc.perform(get("/api/v1/lookup/module-names")).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0]", is("ModuleName1")))
                .andExpect(jsonPath("$[1]", is("ModuleName2")));
    }

    @Test
    void testFetchActiveReleaseUsages() throws Exception {
        // Mock service method
        List<ReleaseUsageView> releaseUsages = List.of(new ReleaseUsageView("releaseUsageCode1", "releaseUsageName1"),
                new ReleaseUsageView("releaseUsageCode2", "releaseUsageName2"));
        when(lookupDataService.fetchActiveReleaseUsages()).thenReturn(releaseUsages);

        // Perform test with MockMvc
        mockMvc.perform(get("/api/v1/lookup/release-usages")).andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].releaseUsageName", is("releaseUsageName1")))
                .andExpect(jsonPath("$[0].releaseUsageCode", is("releaseUsageCode1")))
                .andExpect(jsonPath("$[1].releaseUsageName", is("releaseUsageName2")))
                .andExpect(jsonPath("$[1].releaseUsageCode", is("releaseUsageCode2")));
    }

    @Test
    void testFetchReleaseTypesByModuleType() throws Exception {
        // Arrange: Set up the mock behavior
        List<String> releaseTypes = List.of("releaseType1", "releaseType2");
        when(lookupDataService.fetchReleaseTypesByModuleType("moduleTypeCode")).thenReturn(releaseTypes);

        // Act & Assert: Perform the mock request and assert the response
        mockMvc.perform(get("/api/v1/lookup/release-types/module-type/{moduleTypeCode}", "moduleTypeCode"))
                .andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0]", is("releaseType1"))).andExpect(jsonPath("$[1]", is("releaseType2")));
    }

    @Test
    void testFetchDistinctPrograms() throws Exception {
        // Arrange: Set up the mock behavior for the service method
        List<ProgramDescriptionDto> programs = List.of(
                new ProgramDescriptionDto(1L, "2023", "PGM1", "Platform1", "English1", "Translation1"),
                new ProgramDescriptionDto(2L, "2024", "PGM2", "Platform2", "English2", "Translation2"));
        when(lookupDataService.fetchDistinctPrograms()).thenReturn(programs);

        // Act & Assert: Perform the mock request and assert the response
        mockMvc.perform(get("/api/v1/lookup/programs")).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].programKey", is(1)))
                .andExpect(jsonPath("$[0].mdlYrR", is("2023"))).andExpect(jsonPath("$[0].pgmN", is("PGM1")))
                .andExpect(jsonPath("$[0].platN", is("Platform1"))).andExpect(jsonPath("$[0].engN", is("English1")))
                .andExpect(jsonPath("$[0].transN", is("Translation1"))).andExpect(jsonPath("$[1].programKey", is(2)))
                .andExpect(jsonPath("$[1].mdlYrR", is("2024"))).andExpect(jsonPath("$[1].pgmN", is("PGM2")))
                .andExpect(jsonPath("$[1].platN", is("Platform2"))).andExpect(jsonPath("$[1].engN", is("English2")))
                .andExpect(jsonPath("$[1].transN", is("Translation2")));
    }

    @Test
    void testFetchAllProgramsWhichHasPartNumber() throws Exception {
        // Arrange: Set up the mock behavior for the service method
        List<String> programsWithPartNumber = List.of("Program1", "Program2", "Program3");
        when(lookupDataService.fetchAllProgramsWhichHasPartNumber()).thenReturn(programsWithPartNumber);

        // Act & Assert: Perform the mock request and assert the response
        mockMvc.perform(get("/api/v1/lookup/programs/with-part-number")).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(3))).andExpect(jsonPath("$[0]", is("Program1")))
                .andExpect(jsonPath("$[1]", is("Program2"))).andExpect(jsonPath("$[2]", is("Program3")));
    }

    @Test
    void testFetchReleaseRequestDetailsById() throws Exception {
        // Arrange: Set up mock data to be returned by the service method
        Long requestId = 1L;
        ReleaseRequestDetail releaseRequestDetail = new ReleaseRequestDetail("REQ-001", "John Doe", "Approved",
                "Module A", "High", "Yes", "Reason X", "Program Y", "R123", "Yes", "Strategy Z", "No", "Build Event A",
                "2024-01-01", "Engineer X", "Usage Y", "Release 1", "CCM123", "No", "Detail A", "Yes", "Alert Detail",
                "No", "Changes A", "2024-02-01", "2024-03-01", "Engineer Y", "Engineer Z", "Support A", "HW123",
                "IPF123", "SP123");

        when(lookupDataService.fetchReleaseRequestDetailsById(requestId)).thenReturn(releaseRequestDetail);

        // Act & Assert: Perform the mock request and assert the response
        mockMvc.perform(get("/api/v1/lookup/release-request/{id}", requestId)).andExpect(status().isOk())
                .andExpect(jsonPath("$.requestId", is("REQ-001"))).andExpect(jsonPath("$.owner", is("John Doe")))
                .andExpect(jsonPath("$.status", is("Approved"))).andExpect(jsonPath("$.moduleType", is("Module A")))
                .andExpect(jsonPath("$.priority", is("High"))).andExpect(jsonPath("$.priorityDriver", is("Yes")))
                .andExpect(jsonPath("$.releaseConcernReason", is("Reason X")))
                .andExpect(jsonPath("$.firmwareProgram", is("Program Y")))
                .andExpect(jsonPath("$.calibrationRNumber", is("R123")))
                .andExpect(jsonPath("$.isCoordinationRequired", is("Yes")))
                .andExpect(jsonPath("$.swStrategy", is("Strategy Z")))
                .andExpect(jsonPath("$.isBackwardCompatChange", is("No")))
                .andExpect(jsonPath("$.buildEvent", is("Build Event A")))
                .andExpect(jsonPath("$.calibrationReleaseDateCfx", is("2024-01-01")))
                .andExpect(jsonPath("$.projectControlEngineer", is("Engineer X")))
                .andExpect(jsonPath("$.firmwareReleaseUsage", is("Usage Y")))
                .andExpect(jsonPath("$.releaseTitle", is("Release 1")))
                .andExpect(jsonPath("$.isCalibrationCCMNumber", is("CCM123")))
                .andExpect(jsonPath("$.isAdditionalHwSwCoordRequired", is("No")))
                .andExpect(jsonPath("$.hwSwCoordDetail", is("Detail A")))
                .andExpect(jsonPath("$.isAlertRequired", is("Yes")))
                .andExpect(jsonPath("$.alertDetail", is("Alert Detail")))
                .andExpect(jsonPath("$.isRollingUsageRequired", is("No")))
                .andExpect(jsonPath("$.rollingUsageChanges", is("Changes A")))
                .andExpect(jsonPath("$.buildStartDate", is("2024-02-01")))
                .andExpect(jsonPath("$.suppliertVbfDeliveryDate", is("2024-03-01")))
                .andExpect(jsonPath("$.appDREngineer", is("Engineer Y")))
                .andExpect(jsonPath("$.calibrationEngineer", is("Engineer Z")))
                .andExpect(jsonPath("$.calibrationReleaseSupport", is("Support A")))
                .andExpect(jsonPath("$.hardwarePartNumber", is("HW123")))
                .andExpect(jsonPath("$.ipfInstalledPartNumber", is("IPF123")))
                .andExpect(jsonPath("$.servicePartNumber", is("SP123")));
    }

    @Test
    void testFetchAllReleaseRequests() throws Exception {
        // Arrange: Set up mock data to be returned by the service method
        List<ReleaseRequestOutput> releaseRequests = List.of(
                new ReleaseRequestOutput(1L, "Module A", "Level 1", "2024", "Program A", "Engine X", "Pending",
                        "2024-01-01", "John Doe"),
                new ReleaseRequestOutput(2L, "Module B", "Level 2", "2024", "Program B", "Engine Y", "Approved",
                        "2024-02-01", "Jane Smith"));

        // Mock the behavior of the service to return the mock data
        when(lookupDataService.fetchAllReleaseRequests()).thenReturn(releaseRequests);

        // Act & Assert: Perform the mock request and assert the response
        mockMvc.perform(get("/api/v1/lookup/release-request")).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].id", is(1)))
                .andExpect(jsonPath("$[0].module", is("Module A"))).andExpect(jsonPath("$[0].rLevel", is("Level 1")))
                .andExpect(jsonPath("$[0].my", is("2024"))).andExpect(jsonPath("$[0].prog", is("Program A")))
                .andExpect(jsonPath("$[0].engine", is("Engine X"))).andExpect(jsonPath("$[0].status", is("Pending")))
                .andExpect(jsonPath("$[0].created", is("2024-01-01"))).andExpect(jsonPath("$[0].owner", is("John Doe")))
                .andExpect(jsonPath("$[1].id", is(2))).andExpect(jsonPath("$[1].module", is("Module B")))
                .andExpect(jsonPath("$[1].rLevel", is("Level 2"))).andExpect(jsonPath("$[1].my", is("2024")))
                .andExpect(jsonPath("$[1].prog", is("Program B"))).andExpect(jsonPath("$[1].engine", is("Engine Y")))
                .andExpect(jsonPath("$[1].status", is("Approved")))
                .andExpect(jsonPath("$[1].created", is("2024-02-01")))
                .andExpect(jsonPath("$[1].owner", is("Jane Smith")));
    }

    @Test
    void testFetchReleaseStatusDetails() throws Exception {
        // Arrange: Set up mock data to be returned by the service method
        List<ReleaseStatus> releaseStatuses = List.of(
                new ReleaseStatus("Concern A", "PN1234", "Type 1", "Released", "2024-01-01"),
                new ReleaseStatus("Concern B", "PN5678", "Type 2", "Pending", "2024-02-01"));

        // Mock the behavior of the service to return the mock data
        when(lookupDataService.fetchReleaseStatusDetails()).thenReturn(releaseStatuses);

        // Act & Assert: Perform the mock request and assert the response
        mockMvc.perform(get("/api/v1/lookup/release-status")).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].concern", is("Concern A")))
                .andExpect(jsonPath("$[0].assemblyPN", is("PN1234")))
                .andExpect(jsonPath("$[0].releaseType", is("Type 1")))
                .andExpect(jsonPath("$[0].status", is("Released")))
                .andExpect(jsonPath("$[0].dateCreated", is("2024-01-01")))
                .andExpect(jsonPath("$[1].concern", is("Concern B")))
                .andExpect(jsonPath("$[1].assemblyPN", is("PN5678")))
                .andExpect(jsonPath("$[1].releaseType", is("Type 2"))).andExpect(jsonPath("$[1].status", is("Pending")))
                .andExpect(jsonPath("$[1].dateCreated", is("2024-02-01")));
    }

    @Test
    void testFetchActiveReleaseTypes() throws Exception {
        // Arrange: Set up mock data to be returned by the service method
        List<ReleaseTypeView> releaseTypes = List.of(new ReleaseTypeView("RT1", "Release Type 1"),
                new ReleaseTypeView("RT2", "Release Type 2"));

        // Mock the behavior of the service to return the mock data
        when(lookupDataService.fetchActiveReleaseTypes()).thenReturn(releaseTypes);

        // Act & Assert: Perform the mock request and assert the response
        mockMvc.perform(get("/api/v1/lookup/release-types")).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].releaseTypeCode", is("RT1")))
                .andExpect(jsonPath("$[0].releaseTypeName", is("Release Type 1")))
                .andExpect(jsonPath("$[1].releaseTypeCode", is("RT2")))
                .andExpect(jsonPath("$[1].releaseTypeName", is("Release Type 2")));
    }

    @Test
    void testFetchModuleBaseInformation() throws Exception {
        // Arrange: Set up mock data to be returned by the service method
        String userId = "user123";
        List<ModuleBaseInformation> moduleBaseInfo = List.of(new ModuleBaseInformation("concern1", "part1"),
                new ModuleBaseInformation("concern2", "part2"));

        // Mock the behavior of the service to return the mock data
        when(lookupDataService.fetchModuleBaseInformation(userId)).thenReturn(moduleBaseInfo);

        // Act & Assert: Perform the mock request and assert the response
        mockMvc.perform(get("/api/v1/lookup/module-base-info/user-id/{userId}", userId)).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].concernNumber", is("concern1")))
                .andExpect(jsonPath("$[0].partNumber", is("part1")))
                .andExpect(jsonPath("$[1].concernNumber", is("concern2")))
                .andExpect(jsonPath("$[1].partNumber", is("part2")));
    }

    @Test
    void testFindPartsByFirmware() throws Exception {
        // Arrange: Set up mock data to be returned by the service method
        ReplacePblSearchRequest request = new ReplacePblSearchRequest("currentPblValue", "newPblValue");

        // Create a mock list of PartFirmwareResponse with nested objects
        List<PartFirmwareResponse> partFirmwareResponses = List.of(
                new PartFirmwareResponse("assemblyPN1", "drcdsId1", "hardwarePN1", "coreHardwarePN1", "microType1",
                        List.of(new LookupProgramDescriptionDto(1L, "2022", "Program1", "Platform1", "Engine1",
                                "Transmission1")),
                        "lineage1",
                        List.of(new LookupPartFirmwareDto("firmware1", "file1", "approverCdsId1", "category1",
                                LocalDate.now()))),
                new PartFirmwareResponse("assemblyPN2", "drcdsId2", "hardwarePN2", "coreHardwarePN2", "microType2",
                        List.of(new LookupProgramDescriptionDto(2L, "2023", "Program2", "Platform2", "Engine2",
                                "Transmission2")),
                        "lineage2", List.of(new LookupPartFirmwareDto("firmware2", "file2", "approverCdsId2",
                        "category2", LocalDate.now()))));

        // Mock the service layer to return the mock list of PartFirmwareResponse
        when(lookupDataService.findPartsByFirmware(request)).thenReturn(partFirmwareResponses);

        // Act & Assert: Perform the mock POST request and assert the response
        mockMvc.perform(post("/api/v1/lookup/parts-by-firmware").contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request))).andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].assemblyPN", is("assemblyPN1")))
                .andExpect(jsonPath("$[1].assemblyPN", is("assemblyPN2")))
                .andExpect(jsonPath("$[0].programDescriptions[0].pgmN", is("Program1")))
                .andExpect(jsonPath("$[0].partFirmwares[0].firmwareN", is("firmware1")));
    }

    private String asJsonString(Object obj) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(obj);
    }

    @Test
    void testFetchPrismInputDataByPartNumber() throws Exception {
        // Arrange: Prepare mock data for PrismDataInputResponse
        PrismDataInputResponse prismDataInputResponse = new PrismDataInputResponse("calibPartNumber123",
                "part2PartNumber456", "inputFileXYZ", "pdxPartNumber789", "catchWordTest", "chipId321", "Test comments",
                "EngineSize1.5L", "hardwarePn111", "modulePn222", "vehicleApplTest", "vehicleCalTest",
                "wersNoticeTest");

        // Mock the service to return the prepared PrismDataInputResponse
        when(lookupDataService.fetchPrismInputDataByPartNumber("partNumber123"))
                .thenReturn(prismDataInputResponse);

        // Act & Assert: Perform the mock GET request and assert the response
        mockMvc.perform(get("/api/v1/lookup/data-prism-input/part-number/partNumber123")).andExpect(status().isOk())

                .andExpect(jsonPath("$.calibPartNumber", is("calibPartNumber123")))
                .andExpect(jsonPath("$.part2PartNumber", is("part2PartNumber456")))
                .andExpect(jsonPath("$.inputFile", is("inputFileXYZ")))
                .andExpect(jsonPath("$.pdxPartNumber", is("pdxPartNumber789")))
                .andExpect(jsonPath("$.catchWord", is("catchWordTest")))
                .andExpect(jsonPath("$.chipId", is("chipId321"))).andExpect(jsonPath("$.comments", is("Test comments")))
                .andExpect(jsonPath("$.engineSize", is("EngineSize1.5L")))
                .andExpect(jsonPath("$.hardwarePn", is("hardwarePn111")))
                .andExpect(jsonPath("$.modulePn", is("modulePn222")))
                .andExpect(jsonPath("$.vehicleAppl", is("vehicleApplTest")))
                .andExpect(jsonPath("$.vehicleCal", is("vehicleCalTest")))
                .andExpect(jsonPath("$.wersNotice", is("wersNoticeTest")));
    }

    @Test
    void testFetchFirmwareDetailsByReleaseType() throws Exception {
        // Arrange: Prepare mock data for FirmwareDetailsResponse
        UserRoleDto userRole = new UserRoleDto("Ram", "Krishna", "ram.krishna@example.com", "supplierName1");
        List<UserRoleDto> owners = List.of(userRole);

        FirmwareDetailsResponse firmwareDetailsResponse = new FirmwareDetailsResponse("Firmware Type 1",
                "Description of Firmware Type 1", "Independent Verifier 1", owners);

        List<FirmwareDetailsResponse> firmwareDetailsList = List.of(firmwareDetailsResponse);

        // Mock the service to return the list of FirmwareDetailsResponse
        when(lookupDataService.fetchFirmwareDetailsByReleaseType("releaseType1")).thenReturn(firmwareDetailsList);

        // Act & Assert: Perform the mock GET request and assert the response
        mockMvc.perform(get("/api/v1/lookup/firmware/release-type/releaseType1")).andExpect(status().isOk())
                .andExpect(jsonPath("$[0].firmwareType", is("Firmware Type 1")))
                .andExpect(jsonPath("$[0].description", is("Description of Firmware Type 1")))
                .andExpect(jsonPath("$[0].independentVerifier", is("Independent Verifier 1")));

    }

    @Test
    void testFetchReleaseRequestDetailsByUserId() throws Exception {
        // Arrange: Prepare mock data for ReleaseRequestDTO
        ReleaseRequestDTO request1 = new ReleaseRequestDTO("REQ123", "2024", "ProgramA", "CFX1", "StateChange1",
                "InProgress");
        ReleaseRequestDTO request2 = new ReleaseRequestDTO("REQ124", "2024", "ProgramB", "CFX2", "StateChange2",
                "Completed");

        List<ReleaseRequestDTO> releaseRequestList = List.of(request1, request2);

        // Mock the service response
        Map<String, List<ReleaseRequestDTO>> mockResponse = new HashMap<>();
        mockResponse.put("user1", releaseRequestList);
        when(lookupDataService.fetchReleaseRequestDetailsByUserId("user1")).thenReturn(mockResponse);

        // Act: Perform the GET request and check the status and body of the response
        mockMvc.perform(get("/api/v1/lookup/release-request/user-id/user1")).andExpect(status().isOk())
                .andExpect(jsonPath("$.user1", hasSize(2))).andExpect(jsonPath("$.user1[0].requestId", is("REQ123")))
                .andExpect(jsonPath("$.user1[1].requestId", is("REQ124")));
    }

    @Test
    void testFetchReleaseInProcessDetailsByUserId() throws Exception {
        // Arrange: Prepare mock data for ReleaseDetailsDto
        List<String> parts1 = List.of("part1", "part2");
        List<String> programs1 = List.of("programA", "programB");
        ReleaseDetailsDto releaseDetails1 = new ReleaseDetailsDto("concern1", parts1, programs1);

        List<String> parts2 = List.of("part3", "part4");
        List<String> programs2 = List.of("programC", "programD");
        ReleaseDetailsDto releaseDetails2 = new ReleaseDetailsDto("concern2", parts2, programs2);

        List<ReleaseDetailsDto> releaseDetailsList = List.of(releaseDetails1, releaseDetails2);

        // Mock the service response
        when(lookupDataService.fetchReleaseInProcessDetailsByUserId("user1")).thenReturn(releaseDetailsList);

        // Act: Perform the GET request and check the status and body of the response
        mockMvc.perform(get("/api/v1/lookup/release-in-process/user-id/user1")).andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].concern", is("concern1")))
                .andExpect(jsonPath("$[0].parts", hasSize(2))).andExpect(jsonPath("$[0].parts[0]", is("part1")))
                .andExpect(jsonPath("$[0].programs", hasSize(2)))
                .andExpect(jsonPath("$[0].programs[0]", is("programA")))
                .andExpect(jsonPath("$[1].concern", is("concern2"))).andExpect(jsonPath("$[1].parts", hasSize(2)))
                .andExpect(jsonPath("$[1].parts[0]", is("part3"))).andExpect(jsonPath("$[1].programs", hasSize(2)))
                .andExpect(jsonPath("$[1].programs[0]", is("programC")));
    }

    @Test
    void testFetchMainMicroTypeDetailsByUserId() throws Exception {
        // Arrange: Prepare mock data for MainMicroTypeDto
        MainMicroTypeDto dto1 = new MainMicroTypeDto("signoff1", 101L, "MicroType1", "owner1", "SignoffType1");
        MainMicroTypeDto dto2 = new MainMicroTypeDto("signoff2", 102L, "MicroType2", "owner2", "SignoffType2");

        // Map simulating the response for a given userId
        Map<String, List<MainMicroTypeDto>> mockResponse = new HashMap<>();
        mockResponse.put("user1", List.of(dto1, dto2));

        // Mock the service call
        when(lookupDataService.fetchMainMicroTypeDetailsByUserId("user1")).thenReturn(mockResponse);

        // Act: Perform the GET request and check the response
        mockMvc.perform(get("/api/v1/lookup/main-micro-type/user-id/user1")).andExpect(status().isOk())
                .andExpect(jsonPath("$['user1']", hasSize(2)))
                .andExpect(jsonPath("$['user1'][0].signoffTypC", is("signoff1")))
                .andExpect(jsonPath("$['user1'][0].microTypC", is(101)))
                .andExpect(jsonPath("$['user1'][0].microTypX", is("MicroType1")))
                .andExpect(jsonPath("$['user1'][0].ownerCdsId", is("owner1")))
                .andExpect(jsonPath("$['user1'][0].signoffTypX", is("SignoffType1")))
                .andExpect(jsonPath("$['user1'][1].signoffTypC", is("signoff2")))
                .andExpect(jsonPath("$['user1'][1].microTypC", is(102)))
                .andExpect(jsonPath("$['user1'][1].microTypX", is("MicroType2")))
                .andExpect(jsonPath("$['user1'][1].ownerCdsId", is("owner2")))
                .andExpect(jsonPath("$['user1'][1].signoffTypX", is("SignoffType2")));
    }

    @Test
    void testFetchReleaseSetupDetailsByUserId() throws Exception {
        // Arrange: Prepare mock data for ReleaseDetailsDto
        List<String> parts = List.of("part1", "part2");
        List<String> programs = List.of("program1", "program2");

        ReleaseDetailsDto dto1 = new ReleaseDetailsDto("concern1", parts, programs);
        ReleaseDetailsDto dto2 = new ReleaseDetailsDto("concern2", parts, programs);

        // Map simulating the response for a given userId
        Map<String, List<ReleaseDetailsDto>> mockResponse = new HashMap<>();
        mockResponse.put("user1", List.of(dto1, dto2));

        // Mock the service to return a list of ReleaseDetailsDto for a given userId
        when(lookupDataService.fetchReleaseSetupDetailsByUserId("user1")).thenReturn(mockResponse);

        // Act: Perform the GET request and check the response
        mockMvc.perform(get("/api/v1/lookup/release-setup/user-id/user1")).andExpect(status().isOk())
                .andExpect(jsonPath("$['user1']", hasSize(2)))
                .andExpect(jsonPath("$['user1'][0].concern", is("concern1")))
                .andExpect(jsonPath("$['user1'][0].parts", hasSize(2)))
                .andExpect(jsonPath("$['user1'][0].programs", hasSize(2)))
                .andExpect(jsonPath("$['user1'][0].programs[0]", is("program1")))
                .andExpect(jsonPath("$['user1'][1].concern", is("concern2")));

    }

}
