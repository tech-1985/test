package com.ford.gpcse.controller.advice;

import com.ford.gpcse.bo.ErrorResponse;
import com.ford.gpcse.exception.AuthServiceException;
import com.ford.gpcse.exception.InvalidInputException;
import com.ford.gpcse.exception.ResourceNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;

import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler globalExceptionHandler;

    @Mock
    private WebRequest mockWebRequest;

    @BeforeEach
    void setup() {
        globalExceptionHandler = new GlobalExceptionHandler();
        mockWebRequest = mock(WebRequest.class);
        when(mockWebRequest.getDescription(false)).thenReturn("Mock Request Description");
    }

    @Test
    void testHandleResourceNotFoundException() {
        ResourceNotFoundException ex = new ResourceNotFoundException("Resource not found");
        ResponseEntity<ErrorResponse> response = globalExceptionHandler.handleResourceNotFoundException(ex, mockWebRequest);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().message()).contains("Resource not found");
    }

    @Test
    void testHandleInvalidInputException() {
        InvalidInputException ex = new InvalidInputException("Invalid input");
        ResponseEntity<ErrorResponse> response = globalExceptionHandler.handleInvalidInputException(ex, mockWebRequest);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().message()).contains("Invalid input");
    }

    @Test
    void testHandleConflictExceptions() {
        IllegalArgumentException ex = new IllegalArgumentException("Conflict error");
        ResponseEntity<ErrorResponse> response = globalExceptionHandler.handleConflictExceptions(ex, mockWebRequest);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().message()).contains("Conflict error");
    }

    @Test
    void testHandleSQLException() {
        SQLException ex = new SQLException("Database error");
        ResponseEntity<ErrorResponse> response = globalExceptionHandler.handleSQLException(ex, mockWebRequest);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().message()).contains("A database error occurred");
    }

    @Test
    void testHandleSQLSyntaxErrorException() {
        SQLSyntaxErrorException ex = new SQLSyntaxErrorException("Syntax error");
        ResponseEntity<ErrorResponse> response = globalExceptionHandler.handleSQLSyntaxError(ex, mockWebRequest);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().message()).contains("There was an issue with the database query");
    }

    @Test
    void testHandleAuthServiceException() {
        AuthServiceException ex = new AuthServiceException("Auth Service Exception");
        ResponseEntity<ErrorResponse> response = globalExceptionHandler.handleAuthServiceException(ex, mockWebRequest);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().message()).contains("Auth Service Exception");
    }

    @Test
    void testHandleVsemServiceException() {
        AuthServiceException ex = new AuthServiceException("Vsem Service Exception");
        ResponseEntity<ErrorResponse> response = globalExceptionHandler.handleVsemServiceException(ex, mockWebRequest);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().message()).contains("Vsem Service Exception");
    }

    @Test
    void testHandleGlobalException() {
        Exception ex = new Exception("Unexpected error");
        ResponseEntity<ErrorResponse> response = globalExceptionHandler.handleGlobalException(ex, mockWebRequest);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().message()).contains("An unexpected error occurred");
    }
}
