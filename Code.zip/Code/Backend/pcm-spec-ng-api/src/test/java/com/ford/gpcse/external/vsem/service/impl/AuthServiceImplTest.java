package com.ford.gpcse.external.vsem.service.impl;

import com.ford.gpcse.bo.TokenResponse;
import com.ford.gpcse.config.AppConfig;
import com.ford.gpcse.exception.AuthServiceException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceImplTest {

    private final String oauthUrl = "https://authserver.com/token";
    private final String clientId = "testClientId";
    private final String clientSecret = "testClientSecret";
    private final String resource = "testResource";
    private final String proxyHost = "test.proxy.com";
    private final int proxyPort = 83;
    @Mock
    private AppConfig appConfig;
    @Mock
    private RestTemplate restTemplateWithProxy;
    @InjectMocks
    private AuthServiceImpl authServiceImpl;
    private TokenResponse tokenResponse;

    @BeforeEach
    void setUp() {
        // Create a mock TokenResponse record
        tokenResponse = new TokenResponse("accessToken", "bearer", 3600, "refreshToken");

        // Mock appConfig behavior
        when(appConfig.getOauthUrl()).thenReturn(oauthUrl);
        when(appConfig.getClientId()).thenReturn(clientId);
        when(appConfig.getClientSecret()).thenReturn(clientSecret);
        when(appConfig.getResource()).thenReturn(resource);

    }

    @Test
    void testFetchToken_Success() {
        // Prepare mock response from RestTemplate
        ResponseEntity<TokenResponse> responseEntity = new ResponseEntity<>(tokenResponse, HttpStatus.OK);
        when(restTemplateWithProxy.exchange(eq(oauthUrl), eq(HttpMethod.POST), any(), eq(TokenResponse.class)))
                .thenReturn(responseEntity);

        // Call the method under test
        TokenResponse result = authServiceImpl.fetchToken();

        // Assert that the token response is correctly returned
        assertNotNull(result);
        assertEquals("accessToken", result.accessToken());
        assertEquals("bearer", result.tokenType());
        assertEquals(3600, result.expiresIn());
        assertEquals("refreshToken", result.refreshToken());
    }

    @Test
    void testFetchToken_ErrorHandling() {
        // Mock a RestClientException to simulate an error
        when(restTemplateWithProxy.exchange(eq(oauthUrl), eq(HttpMethod.POST), any(), eq(TokenResponse.class)))
                .thenThrow(new RestClientException("API call failed"));

        // Call the method under test and expect an AuthServiceException to be thrown
        AuthServiceException exception = assertThrows(AuthServiceException.class, () -> authServiceImpl.fetchToken());

        // Assert that the exception message is correct
        assertEquals("Error fetching token", exception.getMessage());
    }

    @Test
    void testFetchToken_InvalidResponse() {
        // Mock a bad response (null body)
        ResponseEntity<TokenResponse> responseEntity = new ResponseEntity<>(null, HttpStatus.OK);
        when(restTemplateWithProxy.exchange(eq(oauthUrl), eq(HttpMethod.POST), any(), eq(TokenResponse.class)))
                .thenReturn(responseEntity);

        // Call the method and assert that the result is null or handled properly
        TokenResponse result = authServiceImpl.fetchToken();
        assertNull(result);
    }
}
