package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.MicroTypeView;
import com.ford.gpcse.bo.ModuleTypeView;
import com.ford.gpcse.bo.SupplierView;
import com.ford.gpcse.entity.MicroType;
import com.ford.gpcse.entity.ModuleType;
import com.ford.gpcse.entity.Supplier;
import com.ford.gpcse.enums.ModuleTypeCode;
import com.ford.gpcse.enums.ReleaseTypeCode;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class LookupDataServiceImplTest {

    @Mock
    private SupplierRepository supplierRepository;
    @Mock
    private ModuleTypeRepository moduleTypeRepository;
    @Mock
    private MicroTypeRepository microTypeRepository;
    @Mock
    private ModuleNameRepository moduleNameRepository;
    @Mock
    private ProcessorRepository processorRepository;
    @Mock
    private ProgramDescriptionRepository programDescriptionRepository;

    @InjectMocks
    private LookupDataServiceImpl lookupDataServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void fetchActiveSuppliers_WhenSuppliersExist_ShouldReturnSupplierViews() {

        Supplier supplier1 = new Supplier();
        supplier1.setSuplC("Bosch");
        supplier1.setSuplX("Bosch");

        Supplier supplier2 = new Supplier();
        supplier2.setSuplC("Delphi");
        supplier2.setSuplX("Delphi");

        when(supplierRepository.fetchActiveSuppliers()).thenReturn(Optional.of(List.of(supplier1, supplier2)));

        List<SupplierView> result = lookupDataServiceImpl.fetchActiveSuppliers();

        assertNotNull(result);
        assertEquals(2, lookupDataServiceImpl.fetchActiveSuppliers().size());
        assertEquals("Bosch", result.get(0).supplierCode());
        assertEquals("Bosch", result.get(0).supplierName());
        assertEquals("Delphi", result.get(1).supplierCode());
        assertEquals("Delphi", result.get(1).supplierName());
    }

    @Test
    void fetchActiveSuppliers_WhenNoSuppliersExist_ShouldThrowResourceNotFoundException() {
        when(supplierRepository.fetchActiveSuppliers()).thenReturn(Optional.empty());
        Exception exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchActiveSuppliers();
        });
        assertEquals("No Suppliers were found", exception.getMessage());
    }

    @Test
    void fetchActiveModuleTypes_WhenModuleTypesExist_ShouldReturnModuleTypeViews() {

        ModuleType moduleType1 = new ModuleType();
        moduleType1.setModuleTypC("BCCMI");
        moduleType1.setModuleTypX("BCCMI");

        ModuleType moduleType2 = new ModuleType();
        moduleType2.setModuleTypC("AWDCH");
        moduleType2.setModuleTypX("AWDCH");

        when(moduleTypeRepository.fetchActiveModuleTypes()).thenReturn(Optional.of(List.of(moduleType1, moduleType2)));

        List<ModuleTypeView> result = lookupDataServiceImpl.fetchActiveModuleTypes();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("BCCMI", result.get(0).moduleTypeCode());
        assertEquals("BCCMI", result.get(0).moduleTypeName());
        assertEquals("AWDCH", result.get(1).moduleTypeCode());
        assertEquals("AWDCH", result.get(1).moduleTypeName());
    }

    @Test
    void fetchActiveModuleTypes_WhenNoModuleTypesExist_ShouldThrowResourceNotFoundException() {

        when(moduleTypeRepository.fetchActiveModuleTypes()).thenReturn(Optional.empty());

        Exception exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchActiveModuleTypes();
        });

        assertEquals("No Module Types were found", exception.getMessage());
    }

    @Test
    void fetchReleasedMicroTypesByModuleType_WhenMicroTypesExist_ShouldReturnMicroTypeViews() {

        String moduleTypeCode = "BCCMI";
        MicroType microType1 = new MicroType();
        microType1.setMicroTypC(1L);
        microType1.setMicroTypX("SPANISH OAK 1024");

        MicroType microType2 = new MicroType();
        microType2.setMicroTypC(2L);
        microType2.setMicroTypX("MPC-563 Green Oak");

        when(microTypeRepository.fetchReleasedMicroTypesByModuleType(moduleTypeCode))
                .thenReturn(Optional.of(List.of(microType1, microType2)));

        List<MicroTypeView> result = lookupDataServiceImpl.fetchReleasedMicroTypesByModuleType(moduleTypeCode);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(1, result.get(0).microTypeCode());
        assertEquals("SPANISH OAK 1024", result.get(0).microTypeName());
        assertEquals(2, result.get(1).microTypeCode());
        assertEquals("MPC-563 Green Oak", result.get(1).microTypeName());
    }

    @Test
    void fetchReleasedMicroTypesByModuleType_WhenNoMicroTypesExist_ShouldThrowResourceNotFoundException() {

        String moduleTypeCode = "BCCMI";
        when(microTypeRepository.fetchReleasedMicroTypesByModuleType(moduleTypeCode)).thenReturn(Optional.empty());

        Exception exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchReleasedMicroTypesByModuleType(moduleTypeCode);
        });

        assertEquals("No Micro Types were found for the given module type", exception.getMessage());
    }

    @Test
    void fetchActiveModuleNames_WhenModulesExist_ShouldReturnModuleNames() {

        List<String> expectedModuleNames = List.of("ModuleName1", "ModuleName2");
        when(moduleNameRepository.fetchActiveModuleNames()).thenReturn(Optional.of(expectedModuleNames));

        List<String> result = lookupDataServiceImpl.fetchActiveModuleNames();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(expectedModuleNames, result);
    }

    @Test
    void fetchActiveModuleNames_WhenNoModulesExist_ShouldThrowResourceNotFoundException() {
        // Arrange
        when(moduleNameRepository.fetchActiveModuleNames()).thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchActiveModuleNames();
        });

        assertEquals("No Module Names were found", exception.getMessage());
    }

    @Test
    void fetchActiveMicroNames_WhenMicrosExist_ShouldReturnMicroNames() {

        List<String> expectedMicroNames = List.of("MicroName1", "MicroName2");
        when(processorRepository.fetchActiveMicroNames()).thenReturn(Optional.of(expectedMicroNames));

        List<String> result = lookupDataServiceImpl.fetchActiveMicroNames();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(expectedMicroNames, result);
    }

    @Test
    void fetchActiveMicroNames_WhenNoMicrosExist_ShouldThrowResourceNotFoundException() {
        when(processorRepository.fetchActiveMicroNames()).thenReturn(Optional.empty());

        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchActiveMicroNames();
        });

        assertEquals("No Micro Names were found", exception.getMessage());
    }

    @Test
    void testFetchReleaseTypesByModuleTypeValid() {
        String moduleTypeCode = ModuleTypeCode.PCM.name();
        List<String> expectedReleaseTypes = List.of(ReleaseTypeCode.AREUL.name(), ReleaseTypeCode.AFD.name(), ReleaseTypeCode.AFDCX.name(),
                ReleaseTypeCode.AFG.name(), ReleaseTypeCode.AFGO.name(), ReleaseTypeCode.ARNAL.name(),
                ReleaseTypeCode.HRDCN.name(), ReleaseTypeCode.HARDW.name(), ReleaseTypeCode.HWPT.name(),
                ReleaseTypeCode.PSUPR.name());
        List<String> releaseTypes = lookupDataServiceImpl.fetchReleaseTypesByModuleType(moduleTypeCode);

        assertNotNull(releaseTypes);
        assertFalse(releaseTypes.isEmpty());
        assertEquals(expectedReleaseTypes, releaseTypes);

    }

    @Test
    void testFetchReleaseTypesByModuleTypeInvalid() {
        String moduleTypeCode = "INVALID_CODE";

        Exception exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchReleaseTypesByModuleType(moduleTypeCode);
        });

        assertEquals("No Release Types were found for given module type", exception.getMessage());

    }

}
