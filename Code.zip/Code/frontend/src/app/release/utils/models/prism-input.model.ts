export class PrismInputData {
  hardwarePn?: string = "";
  engineSize?: string = "";
  vehicleCal?: string = "";
  wersNotice?: string = "";
  calibPartNumber?: string = "";
  comments?: string = "";
  inputFile?: string = "";
  modulePn?: string = "";
  catchWord?: string = "";
  vehicleAppl?: string = "";
  pdxPartNumber?: string = "";
  chipId?: string = "";
  part2PartNumber?: string = "";
}
