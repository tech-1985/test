export class FindPartNumberModel {
  releaseTypes: string[] = [];
  releaseUsage: string = "";
  assemblyPN: string = "";
  softwarePN: string = "";
  hardwarePN: string = "";
  applicationEngineer: string = "";
  catchWord: string = "";
  calibrationNumber: string = "";
  swMainStrategy: string = "";
  concernNumber: string = "";
  pnStatus: string = "";
  dateCreatedFrom: string = "";
  dateCreatedTo: string = "";
  dateReleasedFrom: string = "";
  dateReleasedTo: string = "";
}

export interface PartDetail {
  assemblyPN: string;
  hardwarePN: string;
  supplier: string;
  catchWord: string;
  calibrationNum: string;
  status: string;
  dateCreated: string;
}

export interface PartNumberRecord {
  concernNumber: string;
  parts: PartDetail[];
}
