export class FirmwareDescriptionModel {
  releaseType: string = "";
  moduleTypeCode: string = "";
  moduleTypeName: string = "";
}
