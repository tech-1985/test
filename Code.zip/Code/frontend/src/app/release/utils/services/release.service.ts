import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse } from "@angular/common/http";
import { Observable, of } from "rxjs";
import { AddSblPostModel, ReplaceSblPutModel } from "../models/sbl.model";
import { AddPartIIPdxPostModel } from "../models/part-II.model";
import { AddPostRequestMainMicroTypeModel } from "../models/request-main-micro-type";
import API_PATH from "./releaseApiPath";
import {
  AddPblData,
  FetchPartDetails,
  ReplacePblPutModel,
} from "../models/pbl.model";
import { Enrollment } from "../models/enrollment.model";
import { ReleaseRequestGetModel } from "../models/release-request.model";
import { FindPartNumberModel } from "../models/find-part-number-model";
import { ExportToXmlPostModel } from "../models/xml.model";
import {
  FindProductionPartNumberPostModel,
  ProductionPartNumberRecord,
} from "../models/find-production-part-number-model";
import { FedebomPlaceholderReleasePartRequest } from "../models/fedebom-placeholder-release.model";

@Injectable({
  providedIn: "root",
})
export class ReleaseService {
  constructor(private http: HttpClient) {}

  /********************************** LOOKUP API CALLS *********************************************/

  getSupplier(): Observable<any> {
    return this.http.get(API_PATH.SUPPLIER_API_PATH);
  }

  getMicroTypes(moduleType: String): Observable<any> {
    return this.http.get(
      `${API_PATH.MICROTYPES_API_PATH}?moduleTypeCode=${moduleType}`
    );
  }

  getModuleTypes(): Observable<any> {
    return this.http.get(API_PATH.MODULETYPES_API_PATH);
  }

  getModuleNames(): Observable<string[]> {
    return this.http.get<string[]>(API_PATH.MODULENAMES_API_PATH);
  }

  getMicroNames(): Observable<string[]> {
    return this.http.get<string[]>(API_PATH.MICRONAMES_API_PATH);
  }

  getReleaseStatusDetails(): Observable<any> {
    return this.http.get(API_PATH.FETCH_RELEASE_STATUS_DETAILS_API_PATH, {
      responseType: "json",
    });
  }

  getReleaseRequestDetails(): Observable<any> {
    return this.http.get(API_PATH.FETCH_RELEASE_REQUEST_DETAILS_API_PATH, {
      responseType: "json",
    });
  }

  getPrograms(): Observable<any[]> {
    return this.http.get<any[]>(API_PATH.FETCH_PROGRAMS_API_PATH);
  }

  getReleaseTypesByModuleType(moduleType: String): Observable<string[]> {
    return this.http.get<string[]>(
      `${API_PATH.RELEASE_TYPE_BY_MODULE_TYPE_CODE_PATH}/${moduleType}`
    );
  }
  getFirmwareDetailsByReleaseType(releaseType: String): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_PATH.FETCH_FIRMDETAILS_BY_RELEASETYPE_PATH}/${releaseType}`
    );
  }

  getRequestDetailById(id: String): Observable<any> {
    return this.http.get<any[]>(
      `${API_PATH.FETCH_RELEASE_REQUEST_DETAILS_BY_ID_PATH}/${id}`,
      {
        responseType: "json",
      }
    );
  }

  getReleaseTypes(): Observable<any> {
    return this.http.get(API_PATH.RELEASETYPES_API_PATH);
  }

  getReleaseUsages(): Observable<any> {
    return this.http.get(API_PATH.RELEASEUSAGES_API_PATH);
  }

  getPrismInputDetailsByPartNumber(partNumber: String): Observable<any> {
    return this.http.get<any[]>(
      `${API_PATH.PRISM_INPUT_DETAILS_API_PATH}/${partNumber}`,
      {
        responseType: "json",
      }
    );
  }

  getReleaseRequestsByUser(userId: string): Observable<any> {
    return this.http.get<any>(
      `${API_PATH.RELEASE_REQUEST_BY_USER_ID_PATH}/${userId}`
    );
  }

  getReleaseInProcessDetailsByUser(userId: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_PATH.RELEASE_IN_PROCESS_BY_USER_ID_PATH}/${userId}`
    );
  }

  getReleaseSetupDetailsByUser(userId: string): Observable<any> {
    return this.http.get<any>(
      `${API_PATH.RELEASE_SETUP_BY_USER_ID_PATH}/${userId}`
    );
  }

  getPreSoftLockSignoffDetailsByUser(userId: string): Observable<any> {
    return this.http.get<any>(
      `${API_PATH.PRE_SOFT_LOCK_SIGNOFF_BY_USER_ID_PATH}/${userId}`
    );
  }

  getHardLockSignoffDetailsByUser(userId: string): Observable<any> {
    return this.http.get<any>(
      `${API_PATH.HARD_LOCK_SIGNOFF_BY_USER_ID_PATH}/${userId}`
    );
  }

  getPostHardLockSignoffDetailsByUser(userId: string): Observable<any> {
    return this.http.get<any>(
      `${API_PATH.POST_HARD_LOCK_SIGNOFF_BY_USER_ID_PATH}/${userId}`
    );
  }

  getMainMicroTypeDetailsByUser(userId: string): Observable<any> {
    return this.http.get<any>(
      `${API_PATH.MAIN_MICRO_TYPE_BY_USER_ID_PATH}/${userId}`
    );
  }
  getHardwarePartNumbersByReleaseTypeAndModuleType(
    releaseTypeCode: string,
    moduleTypeCode: string
  ): Observable<string[]> {
    return this.http.get<string[]>(
      `${API_PATH.HARDWARE_PART_NUMBERS_PATH}/release-type/${releaseTypeCode}/module-type/${moduleTypeCode}`
    );
  }

  /********************************** SEARCH API CALLS ***************************************************/

  getFirmwareDetailsByWersConcern(wersConcern: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_PATH.WERS_CONCERN_SEARCH_API_PATH}/${wersConcern}`
    );
  }

  getFirmwareDetailsByWersNotice(wersNotice: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_PATH.WERS_NOTICE_SEARCH_API_PATH}/${wersNotice}`
    );
  }

  getFirmwareDetailsByPrograms(programs: string[]): Observable<any[]> {
    return this.http.post<any[]>(API_PATH.PROGRAMS_SEARCH_API_PATH, programs);
  }

  getReleaseStatusDetailsByWersConcern(concern: String): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_PATH.RELEASE_STATUS_SEARCH_BY_WERS_CONCERN_API_PATH}/${concern}`,
      { responseType: "json" }
    );
  }

  getReleaseRequestSearchDetails(
    releaseRequests: ReleaseRequestGetModel
  ): Observable<any[]> {
    return this.http.post<any[]>(
      API_PATH.RELEASE_REQUEST_SEARCH_API_PATH,
      releaseRequests
    );
  }

  getFirmwareDetailsByPartNumber(
    findPartNumberData: FindPartNumberModel
  ): Observable<any[]> {
    return this.http.post<any[]>(
      API_PATH.PART_NUMBER_SEARCH_API_PATH,
      findPartNumberData,
      { responseType: "json" }
    );
  }

  getFirmwareDetailsByProductionPartNumber(
    findProductionPartNumberData: FindProductionPartNumberPostModel
  ): Observable<any[]> {
    return this.http.post<any[]>(
      API_PATH.PRODUCTION_PART_NUMBER_SEARCH_API_PATH,
      findProductionPartNumberData,
      { responseType: "json" }
    );
  }

  getWersTextDetailsByWersConcern(wersConcern: String): Observable<string> {
    return this.http.get<string>(
      `${API_PATH.WERS_TEXT_SEARCH_API_PATH}/${wersConcern}`,
      { responseType: "text" as "json" }
    );
  }

  /********************************** MODULE RELEASE API CALLS *******************************************/
  addSbl(newSblData: AddSblPostModel): Observable<any> {
    return this.http.post(
      API_PATH.ADD_REPLACE_SBL_API_PATH,
      { ...newSblData },
      { responseType: "text" }
    );
  }

  replaceSbl(replaceSblData: ReplaceSblPutModel): Observable<any> {
    return this.http.put(
      API_PATH.ADD_REPLACE_SBL_API_PATH,
      { ...replaceSblData },
      { responseType: "text" }
    );
  }

  addPBL(pblData: AddPblData): Observable<any> {
    return this.http.post(
      API_PATH.ADD_REPLACE_PBL_API_PATH,
      { ...pblData },
      { responseType: "text" }
    );
  }

  replacePBL(pblData: ReplacePblPutModel): Observable<any> {
    return this.http.put(
      API_PATH.ADD_REPLACE_PBL_API_PATH,
      { ...pblData },
      { responseType: "text" }
    );
  }

  getPartsByFirmware(fetchPartDetails: FetchPartDetails): Observable<any> {
    return this.http.post(
      API_PATH.FETCH_PARTS_BY_FIRMWARE_API_PATH,
      { ...fetchPartDetails },
      { responseType: "json" }
    );
  }

  addPartIIPDX(partIIPdxData: AddPartIIPdxPostModel): Observable<any> {
    return this.http.post(
      API_PATH.ADD_PARTII_PDX_API_PATH,
      { ...partIIPdxData },
      { responseType: "text" }
    );
  }

  addNewMainMicroType(
    addNewMainMicroTypeData: AddPostRequestMainMicroTypeModel
  ): Observable<any> {
    return this.http.post(
      API_PATH.ADD_NEW_MICRO_TYPE_API_PATH,
      { ...addNewMainMicroTypeData },
      { responseType: "text" }
    );
  }

  addFedebomPlaceholderReleaseParts(
    addfedebomPlaceholderReleasePartRequestData: FedebomPlaceholderReleasePartRequest
  ): Observable<any> {
    return this.http.post(
      API_PATH.ADD_FEDEBOM_PLACEHOLDER_RELEASE_PARTS_API_PATH,
      { ...addfedebomPlaceholderReleasePartRequestData },
      { responseType: "text" }
    );
  }

  /********************************** EXPORT API CALLS *******************************************/

  exportPartsToExcel(partNumbers: string[]): Observable<any> {
    return this.http.post(API_PATH.EXPORT_EXCEL_PARTS_API_PATH, partNumbers, {
      responseType: "blob",
    });
  }

  exportPartsToCSV(
    firmwareRecords: ProductionPartNumberRecord[]
  ): Observable<any> {
    return this.http.post(
      API_PATH.EXPORT_EXCEL_PRISM_PARTS_API_PATH,
      firmwareRecords,
      {
        responseType: "blob",
      }
    );
  }

  exportPartsToXML(
    exportToExcelData: ExportToXmlPostModel
  ): Observable<HttpResponse<Blob>> {
    return this.http.post<Blob>(
      API_PATH.EXPORT_XML_PARTS_API_PATH,
      exportToExcelData,
      {
        responseType: "blob" as "json",
        observe: "response",
      }
    );
  }

  exportReleaseRequestDetailsToExcel(
    releaseRequest: ReleaseRequestGetModel
  ): Observable<any> {
    return this.http.post(
      API_PATH.EXPORT_EXCEL_RELEASE_REQUEST_API_PATH,
      { ...releaseRequest },
      {
        responseType: "blob",
      }
    );
  }

  /********************************** Enrollment API CALLS *******************************************/
  submitUserEnrollment(userForm: Enrollment): Observable<any> {
    return this.http.post(
      API_PATH.SUPPLIER_ENROLLMENT_PATH,
      { ...userForm },
      { responseType: "text" }
    );
  }
}
