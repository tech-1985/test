import { ComponentFixture, TestBed } from "@angular/core/testing";

import { DisplayCalibrationFileSignoffComponent } from "./display-calibration-file-signoff.component";

describe("DisplayCalibrationFileSignoffComponent", () => {
  let component: DisplayCalibrationFileSignoffComponent;
  let fixture: ComponentFixture<DisplayCalibrationFileSignoffComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DisplayCalibrationFileSignoffComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DisplayCalibrationFileSignoffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
