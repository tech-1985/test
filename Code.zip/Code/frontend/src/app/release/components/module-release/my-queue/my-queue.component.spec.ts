import { ComponentFixture, TestBed } from "@angular/core/testing";

import { MyQueueComponent } from "./my-queue.component";

describe("MyQueueComponent", () => {
  let component: MyQueueComponent;
  let fixture: ComponentFixture<MyQueueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MyQueueComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(MyQueueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
