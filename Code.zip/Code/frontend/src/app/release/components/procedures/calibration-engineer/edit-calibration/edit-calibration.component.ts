import { Component } from "@angular/core";

@Component({
  selector: "app-edit-calibration",
  templateUrl: "./edit-calibration.component.html",
  styleUrl: "./edit-calibration.component.scss",
})
export class EditCalibrationComponent {}
