import { Component, OnDestroy, OnInit } from "@angular/core";
import { HttpErrorResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../../utils/ReleaseUtils";
import { ReleaseService } from "../../../../utils/services/release.service";
import { Router } from "@angular/router";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
@Component({
  selector: "app-release-status",
  templateUrl: "./release-status.component.html",
})
export class ReleaseStatusComponent implements OnInit, OnDestroy {
  releaseStatuses: any[] = [];
  concern: string = "";
  displayConcernDetails: boolean = false;
  firmwareRecords: any[] = [];
  private unsubscribe$ = new Subject<void>();
  loading: boolean = false;

  constructor(private router: Router, private releaseService: ReleaseService) {}

  ngOnInit() {
    this.firmwareRecords = [];
    this.displayConcernDetails = false;
    this.fetchReleaseStatuses();
    this.loading = false;
  }

  fetchReleaseStatuses() {
    this.releaseService.getReleaseStatusDetails().subscribe((data) => {
      this.releaseStatuses = data;
    });
  }

  onSubmit(concern: string) {
    this.concern = concern;
    this.loading = true;
    if (this.concern) {
      this.releaseService
        .getReleaseStatusDetailsByWersConcern(this.concern)
        .pipe(takeUntil(this.unsubscribe$))
        .subscribe({
          next: (response: any) => {
            this.loading = false;
            this.firmwareRecords = response;
            this.displayConcernDetails = true;
          },
          error: (error: HttpErrorResponse) => {
            this.loading = false;
            this.handleError(error);
          },
        });
    }
  }

  cancelSubmit() {
    this.firmwareRecords = [];
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage =
      "Unfortunately, an error has occurred. Please check back later.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }
}
