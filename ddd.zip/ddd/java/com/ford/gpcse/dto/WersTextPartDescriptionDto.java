package com.ford.gpcse.dto;

public record WersTextPartDescriptionDto(Long pgmK, String mdlYrR, String pgmN, String platN, String engN,
		String transN) {
}
