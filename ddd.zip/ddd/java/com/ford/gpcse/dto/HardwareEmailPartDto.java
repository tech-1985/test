package com.ford.gpcse.dto;

public record HardwareEmailPartDto(String partR, String engineerCdsidC, String hardwarePartR, String coreHardwarePartR,
		String microTypX) {
}
