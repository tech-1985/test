package com.ford.gpcse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The main entry point for the Gpcse Spring Boot application. This class runs
 * the Spring Boot application using the {@link SpringApplication#run} method.
 * 
 */

@SpringBootApplication
public class GpcseApplication {

	public static void main(String[] args) {
		SpringApplication.run(GpcseApplication.class, args);
	}

}
