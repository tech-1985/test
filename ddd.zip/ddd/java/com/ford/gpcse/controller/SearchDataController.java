package com.ford.gpcse.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.FirmwareResponse;
import com.ford.gpcse.bo.GroupedFirmwareSearchResponse;
import com.ford.gpcse.bo.PartNumberSearchRequest;
import com.ford.gpcse.bo.PartNumberSearchResponse;
import com.ford.gpcse.bo.ProductionPartNumberSearchRequest;
import com.ford.gpcse.bo.ProductionPartNumberSearchResponse;
import com.ford.gpcse.bo.ReleaseRequestOutput;
import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.bo.ReleaseStatusConcernResponse;
import com.ford.gpcse.service.SearchDataService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Controller for managing search operations related to firmware and release
 * requests. This class provides endpoints for various search functionalities By
 * Wers Concern, Wers Notice, programs, part numbers, and release statuses.
 */
@RestController

@RequestMapping("/api/v1/search")
@Tag(description = " Wers Concern Search, Wers Notice Search, Program Search, Part Number/Catchword/Date Range Search, Release Request Search, Production Part Number Search, Wers Text By Wers Concern Search, Release Status Details By Concern Search.", name = "Search Data")
public class SearchDataController {

	private final SearchDataService searchDataService;

	public SearchDataController(SearchDataService searchDataService) {
		super();
		this.searchDataService = searchDataService;
	}

	/**
	 * Endpoint to search firmware details by Wers Concern.
	 *
	 * @param wersConcern the Wers concern to search for
	 * @return a list of firmware details matching the Wers concern
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/wers-concern/{wersConcern}")
	@Operation(description = "Wers Concern Search", summary = "Wers Concern Search")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<GroupedFirmwareSearchResponse> fetchFirmwareDetailsByWersConcern(@PathVariable String wersConcern) {
		return searchDataService.fetchFirmwareDetailsByWersConcern(wersConcern);
	}

	/**
	 * Endpoint to search firmware details by Wers Notice.
	 *
	 * @param wersNotice the Wers notice to search for
	 * @return a list of firmware details matching the Wers notice
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/wers-notice/{wersNotice}")
	@Operation(description = "Wers Notice Search", summary = "Wers Notice Search")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<GroupedFirmwareSearchResponse> fetchFirmwareDetailsByWersNotice(@PathVariable String wersNotice) {
		return searchDataService.fetchFirmwareDetailsByWersNotice(wersNotice);
	}

	/**
	 * Endpoint to search firmware details by program keys.
	 *
	 * @param programKeys the list of program keys to search for
	 * @return a list of firmware details matching the program keys
	 */
	@LoggingAspect
	@TrackExecutionTime
	@PostMapping("/programs")
	@Operation(description = "Program Search", summary = "Program Search")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<FirmwareResponse> fetchFirmwareDetailsByPrograms(@RequestBody List<Long> programKeys) {
		return searchDataService.fetchFirmwareDetailsByPrograms(programKeys);
	}

	/**
	 * Endpoint to search firmware details by part number, catchword, or date range.
	 *
	 * @param partNumberSearchRequest the search request containing part number
	 *                                criteria
	 * @return a list of part number search responses
	 */
	@LoggingAspect
	@TrackExecutionTime
	@PostMapping("/part-number")
	@Operation(description = "Part Number/Catchword/Date Range Search", summary = "Part Number/Catchword/Date Range Search")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(
			@RequestBody PartNumberSearchRequest partNumberSearchRequest) {
		return searchDataService.fetchFirmwareDetailsByPartNumber(partNumberSearchRequest);
	}

	/**
	 * Endpoint to search for release requests.
	 *
	 * @param releaseRequestSearchInput the input criteria for release request
	 *                                  search
	 * @return a list of release requests matching the search criteria
	 */
	@LoggingAspect
	@TrackExecutionTime
	@PostMapping("/release-request")
	@Operation(description = "Release Request Search", summary = "Release Request Search")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ReleaseRequestOutput> fetchReleaseRequests(
			@RequestBody ReleaseRequestSearchInput releaseRequestSearchInput) {
		return searchDataService.fetchReleaseRequests(releaseRequestSearchInput);
	}

	/**
	 * Endpoint to search for production part numbers.
	 *
	 * @param productionPartNumberSearchRequest the request containing production
	 *                                          part number search criteria
	 * @return a list of production part number search responses
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping(value = "/production-part-number")
	@Operation(summary = "Production Part Number Search", description = "Production Part Number Search")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ProductionPartNumberSearchResponse> fetchProductionPartNumber(
			@RequestBody ProductionPartNumberSearchRequest productionPartNumberSearchRequest) {
		return searchDataService.fetchProductionPartNumber(productionPartNumberSearchRequest);

	}

	/**
	 * Endpoint to fetch Wers text By Wers concern.
	 *
	 * @param wersConcern the Wers concern to search for
	 * @return the Wers text associated with the given concern
	 */
	@TrackExecutionTime
	@LoggingAspect
	@GetMapping(value = "/wers-text/wers-concern/{wersConcern}")
	@Operation(summary = "Wers Text By Wers Concern Search", description = "Wers Text By Wers Concern Search")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public String fetchWersTextByConcern(@PathVariable String wersConcern) {
		return searchDataService.fetchWersTextByConcern(wersConcern);
	}

	/**
	 * Endpoint to fetch release status details By Wers concern.
	 *
	 * @param wersConcern the Wers concern to search for
	 * @return the release status response associated with the given concern
	 */
	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/release-status/wers-concern/{wersConcern}")
	@Operation(description = "Release Status Details By Concern Search", summary = "Release Status Details By Concern Search")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found") })
	public List<ReleaseStatusConcernResponse> fetchReleaseStatusDetailsByWersConcern(@PathVariable String wersConcern) {
		return searchDataService.fetchReleaseStatusDetailsByWersConcern(wersConcern);

	}

}
