package com.ford.gpcse.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.CreatePblRequest;
import com.ford.gpcse.bo.CreateSblRequest;
import com.ford.gpcse.bo.FedebomPlaceholderReleasePartRequest;
import com.ford.gpcse.bo.NewMicroMicroTypeRequest;
import com.ford.gpcse.bo.Part2PdxRequest;
import com.ford.gpcse.bo.ReplacePblRequest;
import com.ford.gpcse.bo.ReplaceSblRequest;
import com.ford.gpcse.service.FedebomPlaceholderRequestService;
import com.ford.gpcse.service.NewMainMicroTypeService;
import com.ford.gpcse.service.Part2PdxService;
import com.ford.gpcse.service.PblService;
import com.ford.gpcse.service.SblService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Controller for managing module release operations. This class provides
 * endpoints for creating and replacing SBLs, PBLs, main micro types, and
 * handling Part 2 or PDX requests.
 */
@RestController
@RequestMapping("/api/v1/module-release")
@Tag(description = "Request New Main Micro Type, Add New Part 2 or PDX, Add New PBL, Add New SBL, Add Fedebom Placeholder Release Parts.", name = "Module Release Operations")
public class ModuleReleaseController {

	private final SblService sblService;
	private final PblService pblService;
	private final NewMainMicroTypeService newMainMicroTypeService;
	private final Part2PdxService part2PdxService;
	private final FedebomPlaceholderRequestService fedebomPlaceholderRequestService;

	public ModuleReleaseController(SblService sblService, PblService pblService,
			NewMainMicroTypeService newMainMicroTypeService, Part2PdxService part2PdxService,
			FedebomPlaceholderRequestService fedebomPlaceholderRequestService) {
		super();
		this.sblService = sblService;
		this.pblService = pblService;
		this.newMainMicroTypeService = newMainMicroTypeService;
		this.part2PdxService = part2PdxService;
		this.fedebomPlaceholderRequestService = fedebomPlaceholderRequestService;

	}

	/**
	 * Endpoint to add a new SBL.
	 *
	 * @param createSblRequest the request object containing details of the SBL to
	 *                         create
	 * @return a response entity indicating the status of the creation
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping("/sbl")
	@Operation(summary = "Add New SBL Section - Add New SBL", description = "Endpoint to add a new SBL under the Add New SBL section.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found"),
			@ApiResponse(responseCode = "400", description = "Invalid request") })
	public ResponseEntity<String> createSbl(@RequestBody CreateSblRequest createSblRequest) {
		sblService.createSbl(createSblRequest);
		return ResponseEntity.status(HttpStatus.CREATED).body("Part request has been submitted.");
	}

	/**
	 * Endpoint to replace an existing SBL.
	 *
	 * @param replaceSblRequest the request object containing details for the SBL to
	 *                          replace
	 * @return a response entity indicating the status of the replacement
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PutMapping("/sbl")
	@Operation(summary = "Add New SBL Section - Replace Existing SBL", description = "Endpoint to replace an existing SBL under the Add New SBL section.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found"),
			@ApiResponse(responseCode = "400", description = "Invalid request") })
	public ResponseEntity<String> replaceSbl(@RequestBody ReplaceSblRequest replaceSblRequest) {
		sblService.replaceSbl(replaceSblRequest);
		return ResponseEntity.ok().body("Part request has been submitted.");
	}

	/**
	 * Endpoint to add a new PBL.
	 *
	 * @param createPblRequest the request object containing details of the PBL to
	 *                         create
	 * @return a response entity indicating the status of the creation
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping(value = "/pbl")
	@Operation(summary = "Add New PBL Section - Add New PBL", description = "Endpoint to add a new PBL under the Add New PBL section.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found"),
			@ApiResponse(responseCode = "400", description = "Invalid request") })
	public ResponseEntity<String> createPbl(@RequestBody CreatePblRequest createPblRequest) {
		pblService.createPbl(createPblRequest);
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(createPblRequest.newPbl() + " has been added to the firmware drop down list");
	}

	/**
	 * Endpoint to replace an existing PBL.
	 *
	 * @param replacePblRequest the request object containing details for the PBL to
	 *                          replace
	 * @return a response entity indicating the status of the replacement
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PutMapping(value = "/pbl")
	@Operation(summary = "Add New PBL Section - Replace Existing PBL", description = "Endpoint to replace an existing PBL under the Add New PBL section.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found"),
			@ApiResponse(responseCode = "400", description = "Invalid request") })
	public ResponseEntity<String> replacePbl(@RequestBody ReplacePblRequest replacePblRequest) {
		pblService.replacePbl(replacePblRequest);
		return ResponseEntity.ok(replacePblRequest.newPbl() + " has been added to the firmware drop down list");
	}

	/**
	 * Endpoint to request a new main micro type.
	 *
	 * @param newMicroMicroTypeRequest the request object containing details of the
	 *                                 main micro type to request
	 * @return the status of the request
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping("/main-micro-type")
	@Operation(summary = "Request New Main Micro Type Section - Request New Main Micro Type", description = "Endpoint to request a new main micro type under the Request New Main Micro Type section.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found"),
			@ApiResponse(responseCode = "400", description = "Invalid request") })
	public String addNewMainMicroType(@RequestBody NewMicroMicroTypeRequest newMicroMicroTypeRequest) {
		newMainMicroTypeService.addNewMainMicroType(newMicroMicroTypeRequest);
		return newMicroMicroTypeRequest.mainMicroTypeName()
				+ " has been sent for review.  You will be emailed when this Main Micro Type is ready to be used in a release.";
	}

	/**
	 * Endpoint to add a new Part 2 or PDX.
	 *
	 * @param part2PdxRequest the request object containing details of the Part 2 or
	 *                        PDX to add
	 * @return the status of the addition
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping("/part2-pdx")
	@Operation(summary = "Add New Part2 or Pdx Section - Add New Part2 or Pdx", description = "Endpoint to add a new Part2 or PDX under the Add New Part2 or PDX section.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found"),
			@ApiResponse(responseCode = "400", description = "Invalid request") })
	public String addNewPart2OrPdx(@RequestBody Part2PdxRequest part2PdxRequest) {
		return part2PdxService.addNewPart2OrPdx(part2PdxRequest);
	}

	/**
	 * Endpoint to add a Fedebom Placeholder Request Parts.
	 *
	 * @param fedebomPlaceholderReleasePartRequest the request object containing
	 *                                             details of the fedebom
	 *                                             placeholder request parts to add
	 * @return the status of the addition
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping("/fedebom-placeholder-release")
	@Operation(summary = "Add Fedebom Placeholder Release Parts", description = "Add Fedebom Placeholder Release Parts")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
			@ApiResponse(responseCode = "404", description = "Resource not found"),
			@ApiResponse(responseCode = "400", description = "Invalid request") })
	public String addFedebomPlaceholderReleaseParts(
			@RequestBody FedebomPlaceholderReleasePartRequest fedebomPlaceholderReleasePartRequest) {
		return fedebomPlaceholderRequestService.addFedebomPlaceholderReleaseParts(fedebomPlaceholderReleasePartRequest);
	}
}
