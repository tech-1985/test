package com.ford.gpcse.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import com.ford.gpcse.bo.ProductionPartNumber;
import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.service.ExportToExcelService;
import com.ford.gpcse.service.ExportToXmlService;
import com.ford.gpcse.util.DateFormatterUtility;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Controller for exporting data, including parts and firmware XML. This class
 * provides endpoints to export parts By part numbers and to fetch
 * firmware XML files, with logging and execution time tracking.
 */
@RestController
@RequestMapping("/api/v1/export")
@Tag(description = "Export Parts To Excel By Part Numbers, Export Prism Parts To CSV By Part Numbers, Export Firmware Data To XML and Export Release Request Details To Excel.", name = "Export Data")
public class ExportDataController {

	private static final String ERROR_OCCURED_MSG = "Error occurred: ";

	private final ExportToXmlService exportToXmlService;
	private final ExportToExcelService exportToExcelService;

	public ExportDataController(ExportToXmlService exportToXmlService, ExportToExcelService exportToExcelService) {
		super();
		this.exportToXmlService = exportToXmlService;
		this.exportToExcelService = exportToExcelService;
	}

	/**
	 * Endpoint for Export Parts To Excel By Part Numbers.
	 *
	 * @param partNumbers the list of part numbers to be exported
	 * @return a ResponseEntity containing the Excel report as a resource
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping(value = "/parts")
	@Operation(summary = "Export Parts To Excel By Part Numbers", description = "Export Parts To Excel By Part Numbers")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Exported Parts to Excel") })
	public ResponseEntity<Resource> exportPartsToExcelByPartNumbers(@RequestBody List<String> partNumbers) {
		try {
			var partsExcelReportStream = exportToExcelService.exportPartsByPartNumbers(partNumbers);
			var headers = new HttpHeaders();
			headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=FirmwareExport.xlsx");
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

			return ResponseEntity.ok().headers(headers).body(new InputStreamResource(partsExcelReportStream));
		} catch (IOException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
					new InputStreamResource(new ByteArrayInputStream((ERROR_OCCURED_MSG + e.getMessage()).getBytes())));
		}
	}

	/**
	 * Endpoint for Export Prism Parts To CSV By Part Numbers.
	 *
	 * @param productionPartNumbers the list of part numbers to be exported
	 * @return a ResponseEntity containing the CSV report as a resource
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping(value = "/prism/parts")
	@Operation(summary = "Export Prism Parts To CSV By Part Numbers", description = "Export Prism Parts To CSV By Part Numbers")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Exported Parts to Excel") })
	public ResponseEntity<Resource> exportPrismPartsToCSVByPartNumbers(
			@RequestBody List<ProductionPartNumber> productionPartNumbers) {
		try {
			var partsExcelReportStream = exportToExcelService.exportPrismPartsByPartNumbers(productionPartNumbers);
			var headers = new HttpHeaders();
			headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=FirmwareExport.csv");
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

			return ResponseEntity.ok().headers(headers).body(new InputStreamResource(partsExcelReportStream));
		} catch (IOException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
					new InputStreamResource(new ByteArrayInputStream((ERROR_OCCURED_MSG + e.getMessage()).getBytes())));
		}
	}

	/**
	 * Endpoint for Export Firmware Data To XML.
	 *
	 * @param exportFirmwareXmlRequest the request object containing parameters for
	 *                                 fetching firmware XML
	 * @return a ResponseEntity containing the firmware XML as a resource
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping(value = "/firmware-xml")
	@Operation(summary = "Export Firmware Data To XML", description = "Export Firmware Data To XML")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successfully Retrieved the Firmware Xml") })
	public ResponseEntity<Resource> exportFirmwareDataToXML(@RequestBody ExportFirmwareXmlRequest exportFirmwareXmlRequest) {
		var resource = exportToXmlService.exportFirmwareDataToXML(exportFirmwareXmlRequest);
		var filename = (exportFirmwareXmlRequest.exportFilename() != null
				&& !exportFirmwareXmlRequest.exportFilename().isEmpty()) ? exportFirmwareXmlRequest.exportFilename()
						: "FirmwareExport" + DateFormatterUtility.dateTimeStringFormatFilename(LocalDateTime.now())
								+ ".xml";

		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
				.header(HttpHeaders.CONTENT_TYPE, "application/xml").body(resource);
	}

	/**
	 * Endpoint for Export Release Request Details To Excel
	 *
	 * @param releaseRequestSearchInput Release Request Search Input
	 * @return a ResponseEntity containing the Excel report as a resource
	 */
	@TrackExecutionTime
	@LoggingAspect
	@PostMapping(value = "/release-request")
	@Operation(summary = "Export Release Request Details To Excel", description = "Export Release Request Details To Excel")
	public ResponseEntity<Resource> exportReleaseRequestDetailsToExcel(
			@RequestBody ReleaseRequestSearchInput releaseRequestSearchInput) {
		try {
			var partsExcelReportStream = exportToExcelService.exportReleaseRequestDetails(releaseRequestSearchInput);
			var headers = new HttpHeaders();
			headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ReleaseRequestSearchResult"
					+ LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".xlsx");
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

			return ResponseEntity.ok().headers(headers).body(new InputStreamResource(partsExcelReportStream));
		} catch (IOException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
					new InputStreamResource(new ByteArrayInputStream((ERROR_OCCURED_MSG + e.getMessage()).getBytes())));
		}
	}
}
