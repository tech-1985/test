package com.ford.gpcse.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMR24_REL_USG")
public class RelUsg {

	@Id
	@Column(name = "PCMR24_REL_USG_C", nullable = false)
	private String relUsgC;

	@Column(name = "PCMR24_REL_USG_X")
	private String relUsgX;

	@Column(name = "PCMR24_ARCH_F")
	private String archF;

	@Column(name = "PCMR24_SORT_ORD_R")
	private String sortOrdR;

	@Column(name = "PCMR24_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMR24_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMR24_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMR24_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;
	
	public String getRelUsgC() {
		return relUsgC;
	}

	public void setRelUsgC(String relUsgC) {
		this.relUsgC = relUsgC;
	}

	public String getRelUsgX() {
		return relUsgX;
	}

	public void setRelUsgX(String relUsgX) {
		this.relUsgX = relUsgX;
	}

	public String getArchF() {
		return archF;
	}

	public void setArchF(String archF) {
		this.archF = archF;
	}

	public String getSortOrdR() {
		return sortOrdR;
	}

	public void setSortOrdR(String sortOrdR) {
		this.sortOrdR = sortOrdR;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}
}
