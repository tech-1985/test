package com.ford.gpcse.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMR26_BACKWARD_COMPAT")
public class BackwardCompat {

	@Id
	@Column(name = "PCMR26_BACKWARD_COMPAT_C", nullable = false)
	private String backwardCompatC;

	@Column(name = "PCMR26_BACKWARD_COMPAT_X")
	private String backwardCompatX;

	@Column(name = "PCMR26_ARCH_F", nullable = false)
	private String archF;

	@Column(name = "PCMR26_SORT_ORD_R")
	private Long sortOrdR;

	@Column(name = "PCMR26_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMR26_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMR26_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMR26_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;

	public String getBackwardCompatC() {
		return backwardCompatC;
	}

	public void setBackwardCompatC(String backwardCompatC) {
		this.backwardCompatC = backwardCompatC;
	}

	public String getBackwardCompatX() {
		return backwardCompatX;
	}

	public void setBackwardCompatX(String backwardCompatX) {
		this.backwardCompatX = backwardCompatX;
	}

	public String getArchF() {
		return archF;
	}

	public void setArchF(String archF) {
		this.archF = archF;
	}

	public Long getSortOrdR() {
		return sortOrdR;
	}

	public void setSortOrdR(Long sortOrdR) {
		this.sortOrdR = sortOrdR;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}
}
