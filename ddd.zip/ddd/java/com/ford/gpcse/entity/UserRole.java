package com.ford.gpcse.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "WPCM003_USER_ROLE")
public class UserRole {

	@EmbeddedId
	private UserRoleId userRoleId;

	@ManyToOne
	@JoinColumn(name = "PCM001_USER_CDSID_C", referencedColumnName = "PCM001_USER_CDSID_C", insertable = false, updatable = false)
	private User user;

	@ManyToOne
	@JoinColumn(name = "PCM002_ROLE_K", referencedColumnName = "PCM002_ROLE_K", insertable = false, updatable = false)
	private Role role;

	@Column(name = "PCM003_CREATE_USER_C", length = 8, nullable = false)
	private String createUserC;

	@NotNull
	@CreationTimestamp
	@Column(name = "PCM003_CREATE_S", nullable = false, updatable = false)
	private LocalDateTime createS;

	@Column(name = "PCM003_LAST_UPDT_USER_C", length = 8, nullable = false)
	private String lastUpdtUserC;

	@NotNull
	@UpdateTimestamp
	@Column(name = "PCM003_LAST_UPDT_S", nullable = false)
	private LocalDateTime lastUpdtS;
	
	public UserRoleId getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(UserRoleId userRoleId) {
		this.userRoleId = userRoleId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}

}
