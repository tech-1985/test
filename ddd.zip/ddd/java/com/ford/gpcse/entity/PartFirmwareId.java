package com.ford.gpcse.entity;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class PartFirmwareId {

	@Column(name = "PCMR01_PART_R", length = 24)
	private String partR;

	@Column(name = "PCMR03_FIRMWARE_K")
	private Long firmwareK;

	public PartFirmwareId() {
	}

	public PartFirmwareId(String partR, Long firmwareK) {
		this.partR = partR;
		this.firmwareK = firmwareK;
	}

	public String getPartR() {
		return partR;
	}

	public void setPartR(String partR) {
		this.partR = partR;
	}

	public Long getFirmwareK() {
		return firmwareK;
	}

	public void setFirmwareK(Long firmwareK) {
		this.firmwareK = firmwareK;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		PartFirmwareId that = (PartFirmwareId) o;
		return Objects.equals(partR, that.partR) && Objects.equals(firmwareK, that.firmwareK);
	}

	@Override
	public int hashCode() {
		return Objects.hash(partR, firmwareK);
	}
}
