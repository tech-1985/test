package com.ford.gpcse.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public record VsemServiceResponse(@JsonProperty("partstatus") String partstatus, @JsonProperty("status") int status,
		@JsonProperty("message") String message, @JsonProperty("partnumber") String partnumber,
		@JsonProperty("partfilenames") List<String> partfilenames) {
}
