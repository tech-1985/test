package com.ford.gpcse.bo;

public record ReplaceSblRequest(String moduleTypeCode, String currentPartNumber, String description, String userId) {
}
