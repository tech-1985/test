package com.ford.gpcse.bo;

import java.util.List;

public record PartNumberSearchResponse(String concernNumber, List<PartDetail> parts) {
}
