package com.ford.gpcse.bo;

public record ReleaseStatus(String concern, String assemblyPN, String releaseType, String status, String dateCreated) {
}
