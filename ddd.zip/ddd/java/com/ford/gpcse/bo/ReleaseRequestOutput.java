package com.ford.gpcse.bo;

public record ReleaseRequestOutput(Long id, String module, String rLevel, String my, String prog, String engine,
		String status, String created, String owner) {
}
