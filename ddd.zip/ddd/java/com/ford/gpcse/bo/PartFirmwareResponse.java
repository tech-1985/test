package com.ford.gpcse.bo;

import java.util.List;

import com.ford.gpcse.dto.LookupPartFirmwareDto;
import com.ford.gpcse.dto.LookupProgramDescriptionDto;

public record PartFirmwareResponse(String assemblyPN, String drcdsId, String hardwarePN, String coreHardwarePN,
		String mainMicroType, List<LookupProgramDescriptionDto> programDescriptions, String lineage,
		List<LookupPartFirmwareDto> partFirmwares) {
}
