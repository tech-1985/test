package com.ford.gpcse.bo;

public record NewMicroMicroTypeRequest(String mainMicroTypeName, String createUser, String lastUpdateUser,
		String moduleTypeCode, String supplierCode, String supplierName) {
}
