package com.ford.gpcse.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ford.gpcse.bo.CreatePblRequest;
import com.ford.gpcse.bo.Email;
import com.ford.gpcse.bo.ReplacePblRequest;
import com.ford.gpcse.dto.HardwareEmailPartDto;
import com.ford.gpcse.entity.FirmwareItem;
import com.ford.gpcse.exception.FirmwareAlreadyRequestedException;
import com.ford.gpcse.exception.UnableToInsertException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.repository.FirmwareItemRepository;
import com.ford.gpcse.repository.FirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.service.PblService;

@Service
public class PblServiceImpl implements PblService {
	private static final Logger log = LoggerFactory.getLogger(PblServiceImpl.class);

	private final FirmwareItemRepository firmwareItemRepository;
	private final PartRepository partRepository;
	private final EmailService emailService;
	private final FirmwareRepository firmwareRepository;

	public PblServiceImpl(FirmwareItemRepository firmwareItemRepository, PartRepository partRepository,
			EmailService emailService, FirmwareRepository firmwareRepository) {
		this.firmwareItemRepository = firmwareItemRepository;
		this.partRepository = partRepository;
		this.emailService = emailService;
		this.firmwareRepository = firmwareRepository;
	}

	@Override
	@Transactional
	public void createPbl(CreatePblRequest createPblRequest) {
		// Check if the firmware item already exists
		var count = firmwareItemRepository.countByFirmwareItmX(createPblRequest.newPbl());

		if (count > 0) {
			throw new FirmwareAlreadyRequestedException(createPblRequest.newPbl() + "  has already been requested.");
		}

		// Get the firmwareK based on the module type code
		var optionalFirmwares = firmwareRepository.fetchFirmwareByModuleTypeCode(createPblRequest.moduleTypeCode(),
				"PBL");
		if (optionalFirmwares.isEmpty()) {
			throw new UnableToInsertException(
					"No firmware found for module type: " + createPblRequest.moduleTypeCode());
		} else {
			var firmwares = optionalFirmwares.get();
			// Select the top firmwareK
			var firmwareK = firmwares.get(0).getFirmwareK();
			// Create the FirmwareItem entity
			var firmwareItem = new FirmwareItem();
			firmwareItem.setFirmwareItmX(createPblRequest.newPbl());
			firmwareItem.setFirmwareK(firmwareK);
			firmwareItem.setSortOrdR(0L);
			firmwareItem.setCreateUserC(createPblRequest.createUser());
			firmwareItem.setLastUpdtUserC(createPblRequest.lastUpdateUser());

			// Save the FirmwareItem entity
			try {
				firmwareItemRepository.save(firmwareItem);
			} catch (Exception e) {
				throw new UnableToInsertException("Unable to insert " + createPblRequest.newPbl()
						+ " firmware found for " + createPblRequest.moduleTypeCode() + " module type.");
			}

		}

		log.info("Part {} has been added to the firmware drop down list", createPblRequest.newPbl());
	}

	@Override
	@Transactional
	public void replacePbl(ReplacePblRequest replacePblRequest) {

		// Check if the firmware item already exists
		var count = firmwareItemRepository.countByFirmwareItmX(replacePblRequest.newPbl());

		if (count > 0) {
			throw new FirmwareAlreadyRequestedException(replacePblRequest.newPbl() + "  has already been requested.");
		}

		// Get the firmwareK based on the module type code
		var optionalFirmwares = firmwareRepository.fetchFirmwareByModuleTypeCode(replacePblRequest.moduleTypeCode(),
				"PBL");
		if (optionalFirmwares.isEmpty()) {
			throw new UnableToInsertException(
					"No firmware found for module type: " + replacePblRequest.moduleTypeCode());
		} else {

			// Select the top firmwareK
			Long firmwareK = optionalFirmwares.get().get(0).getFirmwareK();

			// Create the FirmwareItem entity
			var firmwareItem = new FirmwareItem();
			firmwareItem.setFirmwareItmX(replacePblRequest.newPbl());
			firmwareItem.setFirmwareK(firmwareK);
			firmwareItem.setSortOrdR(0L);
			firmwareItem.setCreateUserC(replacePblRequest.createUser());
			firmwareItem.setLastUpdtUserC(replacePblRequest.lastUpdateUser());

			// Save the FirmwareItem entity
			try {
				firmwareItemRepository.save(firmwareItem);
			} catch (Exception e) {
				throw new UnableToInsertException("Unable to insert " + replacePblRequest.newPbl()
						+ " firmware found for " + replacePblRequest.moduleTypeCode() + " module type.");
			}

			if (replacePblRequest.partNumbers().isEmpty()) {
				sendHardwareEmail(replacePblRequest.partNumbers());
			}

			log.info("Part {} has been added to the firmware drop down list", replacePblRequest.newPbl());
		}
	}

	private void sendHardwareEmail(List<String> partNumbers) {
		if (partNumbers == null || partNumbers.isEmpty()) {
			return;
		}
		var optionalResults = partRepository.fetchPartsForEmail(partNumbers);
		if (!optionalResults.isEmpty()) {
			var results = optionalResults.get();
			StringBuilder emailBody = new StringBuilder();
			emailBody.append("<html><body><div>Please revise the following parts.</div><table border='1'>").append(
					"<tr><th>Assembly PN</th><th>Hardware PN</th><th>Core Hardware PN</th><th>Micro Type</th><th>D&R Eng</th></tr>");
			List<String> engineers = new ArrayList<>();
			for (HardwareEmailPartDto part : results) {
				String engineer = part.engineerCdsidC();
				if (!engineers.contains(engineer)) {
					engineers.add(engineer);
				}
				StringJoiner rowJoiner = new StringJoiner("</td><td>", "<tr><td>", "</td></tr>");
				rowJoiner.add(part.partR()).add(part.hardwarePartR()).add(part.coreHardwarePartR())
						.add(part.microTypX()).add(engineer);
				emailBody.append(rowJoiner.toString());
			}

			emailBody.append("</table></body></html>");

			emailService.sendMail(new Email(engineers, "Revise hardware release. Replace PBL", emailBody.toString(),
					"pcserel@ford.com"));

		}
	}

}
