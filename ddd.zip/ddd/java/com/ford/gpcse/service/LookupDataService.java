package com.ford.gpcse.service;

import java.util.List;
import java.util.Map;

import com.ford.gpcse.bo.FirmwareDetailsResponse;
import com.ford.gpcse.bo.MicroTypeView;
import com.ford.gpcse.bo.ModuleBaseInformation;
import com.ford.gpcse.bo.ModuleTypeView;
import com.ford.gpcse.bo.PartFirmwareResponse;
import com.ford.gpcse.bo.PrismDataInputResponse;
import com.ford.gpcse.bo.ReleaseRequestDetail;
import com.ford.gpcse.bo.ReleaseRequestOutput;
import com.ford.gpcse.bo.ReleaseStatus;
import com.ford.gpcse.bo.ReleaseTypeView;
import com.ford.gpcse.bo.ReleaseUsageView;
import com.ford.gpcse.bo.ReplacePblSearchRequest;
import com.ford.gpcse.bo.SupplierView;
import com.ford.gpcse.dto.MainMicroTypeDto;
import com.ford.gpcse.dto.ProgramDescriptionDto;
import com.ford.gpcse.dto.ReleaseDetailsDto;
import com.ford.gpcse.dto.ReleaseRequestDTO;

public interface LookupDataService {
	List<SupplierView> fetchActiveSuppliers();

	List<ModuleTypeView> fetchActiveModuleTypes();

	List<ReleaseUsageView> fetchActiveReleaseUsages();

	List<MicroTypeView> fetchReleasedMicroTypesByModuleType(String moduleTypC);

	List<String> fetchReleaseTypesByModuleType(String moduleTypeCode);

	List<String> fetchActiveModuleNames();

	List<String> fetchActiveMicroNames();

	List<ProgramDescriptionDto> fetchDistinctPrograms();

	List<ReleaseRequestOutput> fetchAllReleaseRequests();

	List<ReleaseStatus> fetchReleaseStatusDetails();

	List<ModuleBaseInformation> fetchModuleBaseInformation(String userId);

	List<PartFirmwareResponse> findPartsByFirmware(ReplacePblSearchRequest replacePblSearchRequest);

	PrismDataInputResponse fetchPrismInputDataByPartNumber(String partNumber);

	List<FirmwareDetailsResponse> fetchFirmwareDetailsByReleaseType(String releaseType);

	List<ReleaseTypeView> fetchActiveReleaseTypes();

	List<String> fetchAllProgramsWhichHasPartNumber();

	ReleaseRequestDetail fetchReleaseRequestDetailsById(Long id);

	Map<String, List<ReleaseRequestDTO>> fetchReleaseRequestDetailsByUserId(String userId);

	List<ReleaseDetailsDto> fetchReleaseInProcessDetailsByUserId(String userId);

	Map<String, List<MainMicroTypeDto>> fetchMainMicroTypeDetailsByUserId(String userId);

	Map<String, List<ReleaseDetailsDto>> fetchReleaseSetupDetailsByUserId(String userId);

	Map<String, List<ReleaseDetailsDto>> fetchPreSoftLockSignoffDetailsByUserId(String userId);

	Map<String, List<ReleaseDetailsDto>> fetchHardLockSignoffDetailsByUserId(String userId);

	Map<String, List<ReleaseDetailsDto>> fetchPostHardLockSignoffDetailsByUserId(String userId);

	List<String> fetchHardwarePartNumbersByReleaseTypeAndModuleType(String releaseType, String moduleType);
}
