package com.ford.gpcse.service;

import java.util.List;

import com.ford.gpcse.bo.FirmwareResponse;
import com.ford.gpcse.bo.GroupedFirmwareSearchResponse;
import com.ford.gpcse.bo.PartNumberSearchRequest;
import com.ford.gpcse.bo.PartNumberSearchResponse;
import com.ford.gpcse.bo.ProductionPartNumberSearchRequest;
import com.ford.gpcse.bo.ProductionPartNumberSearchResponse;
import com.ford.gpcse.bo.ReleaseRequestOutput;
import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.bo.ReleaseStatusConcernResponse;

public interface SearchDataService {

	List<GroupedFirmwareSearchResponse> fetchFirmwareDetailsByWersConcern(String wersConcern);

	List<GroupedFirmwareSearchResponse> fetchFirmwareDetailsByWersNotice(String wersNotice);

	List<FirmwareResponse> fetchFirmwareDetailsByPrograms(List<Long> programKeys);

	List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(PartNumberSearchRequest partNumberSearchRequest);

	List<ReleaseRequestOutput> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput);

	List<ProductionPartNumberSearchResponse> fetchProductionPartNumber(
			ProductionPartNumberSearchRequest productionPartNumberSearchRequest);

	String fetchWersTextByConcern(String wersConcern);

	List<ReleaseStatusConcernResponse> fetchReleaseStatusDetailsByWersConcern(String wersConcern);
}
