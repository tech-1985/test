package com.ford.gpcse.service;

import com.ford.gpcse.bo.FedebomPlaceholderReleasePartRequest;

public interface FedebomPlaceholderRequestService {

	String addFedebomPlaceholderReleaseParts(FedebomPlaceholderReleasePartRequest fedebomPlaceholderReleasePartRequest);

}
