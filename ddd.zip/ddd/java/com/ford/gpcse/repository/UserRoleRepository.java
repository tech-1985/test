package com.ford.gpcse.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.gpcse.dto.UserRoleDto;
import com.ford.gpcse.entity.UserRole;
import com.ford.gpcse.entity.UserRoleId;

/**
 * Repository interface for accessing UserRole entities. Extends JpaRepository
 * to provide standard CRUD operations.
 */
@Repository
public interface UserRoleRepository extends JpaRepository<UserRole, UserRoleId> {

	/**
	 * Fetches a list of UserRoleDto objects based on the specified firmware key.
	 * This query retrieves user information along with the associated supplier name
	 * for each user's roles linked to the specified firmware.
	 *
	 * @param firmwareK the firmware key to filter user roles
	 * @return a list of UserRoleDto containing user details and associated supplier
	 *         information
	 */
	@Query("SELECT new com.ford.gpcse.dto.UserRoleDto(u.frstN, u.lstN, u.emailAddrX, "
			+ "(SELECT s.suplX FROM Supplier s WHERE s.suplC = r.supplier.suplC)) " + "FROM User u "
			+ "JOIN u.userRoles ur " + "JOIN ur.role r " + "JOIN r.firmwareRoles fr " + "JOIN fr.firmware f "
			+ "WHERE f.firmwareK = :firmwareK " + "ORDER BY r.supplier.suplC, u.userCdsidC")
	Optional<List<UserRoleDto>> fetchUserRolesByFirmwareKey(@Param("firmwareK") Long firmwareK);
}
