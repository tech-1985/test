package com.ford.gpcse.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.gpcse.entity.MicroType;

/**
 * Repository interface for managing MicroType entities. This interface extends
 * JpaRepository to provide CRUD operations for MicroType entities.
 */
@Repository
public interface MicroTypeRepository extends JpaRepository<MicroType, Long> {

	/**
	 * Fetches a list of released MicroType entities filtered by a specific module
	 * type.
	 *
	 * @param moduleTypeCode The module type code to filter by
	 * @return A list of MicroType entities that are released and associated with
	 *         the specified module type
	 */
	@Query("SELECT m FROM MicroType m WHERE m.microTypStatC = 'Released' AND m.archF = 'N' "
			+ "AND (m.moduleType.moduleTypC = :moduleTypeCode OR m.moduleType.moduleTypC IS NULL) "
			+ "ORDER BY m.microTypX")
	Optional<List<MicroType>> fetchReleasedMicroTypesByModuleType(@Param("moduleTypeCode") String moduleTypeCode);

	/**
	 * Counts the number of MicroType entities with a specific name.
	 *
	 * @param mainMicroTypeName The name of the MicroType to count
	 * @return The count of MicroType entities matching the specified name
	 */
	@Query("SELECT COUNT(m) FROM MicroType m WHERE m.microTypX = :mainMicroTypeName")
	int countByMicroTypeName(@Param("mainMicroTypeName") String mainMicroTypeName);

	/**
	 * Fetches the next available MicroType ID. If no MicroType exists, it returns
	 * 10001.
	 *
	 * @return The next available MicroType ID
	 */
	@Query("SELECT COALESCE(MAX(m.microTypC), 10000) + 1 FROM MicroType m")
	Long fetchMicroId();
	

	@Query(value = "SELECT WPCMR46_SIGNOFF_MICRO_TYP.PCMR20_SIGNOFF_TYP_C, WPCMR19_MICRO_TYP.PCMR19_MICRO_TYP_C, "
			+ "PCMR19_MICRO_TYP_X, PCMR19_MICRO_TYP_OWNR_CDSID_C, PCMR20_SIGNOFF_TYP_X " + "FROM WPCMR19_MICRO_TYP "
			+ "INNER JOIN WPCMR46_SIGNOFF_MICRO_TYP "
			+ "ON WPCMR19_MICRO_TYP.PCMR19_MICRO_TYP_C = WPCMR46_SIGNOFF_MICRO_TYP.PCMR19_MICRO_TYP_C "
			+ "INNER JOIN WPCMR20_SIGNOFF "
			+ "ON WPCMR46_SIGNOFF_MICRO_TYP.PCMR20_SIGNOFF_TYP_C = WPCMR20_SIGNOFF.PCMR20_SIGNOFF_TYP_C "
			+ "WHERE PCMR46_SIGNOFF_S IS NULL AND PCMR46_REQT_Y IS NOT NULL "
			+ "AND WPCMR19_MICRO_TYP.PCMR19_MICRO_TYP_STAT_C IN ('Pending Review') " + "AND EXISTS ("
			+ "    SELECT tblUserRoles.PCM002_ROLE_K " + "    FROM WPCMR38_SIGNOFF_DIST "
			+ "    INNER JOIN WPCM003_USER_ROLE tblUserRoles "
			+ "    ON WPCMR38_SIGNOFF_DIST.PCM002_ROLE_K = tblUserRoles.PCM002_ROLE_K "
			+ "    INNER JOIN WPCM002_ROLE tblRole " + "    ON tblUserRoles.PCM002_ROLE_K = tblRole.PCM002_ROLE_K "
			+ "    WHERE upper(tblUserRoles.PCM001_USER_CDSID_C) = :userId "
			+ "    AND WPCMR38_SIGNOFF_DIST.PCMR15_REL_TYP_C = 'MMICR' "
			+ "    AND WPCMR38_SIGNOFF_DIST.PCMR20_SIGNOFF_TYP_C = WPCMR46_SIGNOFF_MICRO_TYP.PCMR20_SIGNOFF_TYP_C "
			+ "    AND tblRole.PCM002_ROLE_TYP_C = 'Signoff Access' "
			+ "    AND (WPCMR19_MICRO_TYP.PCMR17_SUPL_C = tblRole.PCMR17_SUPL_C OR tblRole.PCMR17_SUPL_C IS NULL)"
			+ ") " + "ORDER BY PCMR20_SORT_ORD_R, PCMR20_SIGNOFF_TYP_C, PCMR19_MICRO_TYP_X", nativeQuery = true)
	List<Object[]> findSignoffsByUser(@Param("userId") String userId);
}
