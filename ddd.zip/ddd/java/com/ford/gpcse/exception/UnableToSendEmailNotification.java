package com.ford.gpcse.exception;

public class UnableToSendEmailNotification extends RuntimeException {

	private static final long serialVersionUID = -7416053165885015876L;

	public UnableToSendEmailNotification(String message) {
		super(message);
	}

	public UnableToSendEmailNotification(String message, Throwable cause) {
		super(message, cause);
	}
}
