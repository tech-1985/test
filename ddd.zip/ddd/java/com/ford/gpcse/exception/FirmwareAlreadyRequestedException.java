package com.ford.gpcse.exception;

public class FirmwareAlreadyRequestedException extends RuntimeException {

	private static final long serialVersionUID = 7304102960376691285L;

	public FirmwareAlreadyRequestedException(String message) {
		super(message);
	}

	public FirmwareAlreadyRequestedException(String message, Throwable cause) {
		super(message, cause);
	}
}