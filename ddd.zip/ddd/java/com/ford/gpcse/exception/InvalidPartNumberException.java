package com.ford.gpcse.exception;

public class InvalidPartNumberException extends RuntimeException {

	private static final long serialVersionUID = -6875515272487381462L;

	public InvalidPartNumberException(String message) {
		super(message);
	}

	public InvalidPartNumberException(String message, Throwable cause) {
		super(message, cause);
	}
}