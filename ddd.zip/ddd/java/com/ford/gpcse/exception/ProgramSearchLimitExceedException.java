package com.ford.gpcse.exception;

public class ProgramSearchLimitExceedException extends RuntimeException {

	private static final long serialVersionUID = 6871790295331809714L;

	public ProgramSearchLimitExceedException(String message) {
		super(message);
	}

	public ProgramSearchLimitExceedException(String message, Throwable cause) {
		super(message, cause);
	}
}
