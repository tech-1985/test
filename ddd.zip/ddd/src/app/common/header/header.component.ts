import { Component } from "@angular/core";
import { UrlManager } from "../../utils/shared-constants.model";
import { Router, RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import Swal from "sweetalert2";

@Component({
  selector: "app-header",
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: "./header.component.html",
  styleUrl: "./header.component.scss",
})
export class HeaderComponent {
  urlMngr: UrlManager;
  isLoggedIn: boolean = true;
  username: String = "Test User";
  constructor(private router: Router) {
    this.urlMngr = new UrlManager();
  }

  navigateTo(url: string) {
    if (url === null || typeof url === "undefined" || url === "") return;
    this.router.navigate([this.urlMngr.getModuleUrl(url)]);
  }

  onLogin() {}

  onLogout() {
   
    Swal.fire({
      icon: "warning",
      title: "Warning",
      text: "Authentication Module Implementation is in Progress!!",
      confirmButtonColor: "#00467f",
    }).then(() => {
      document.body.style.overflow = "auto";
      this.router.navigate(["/"]);
    });
  }
}
