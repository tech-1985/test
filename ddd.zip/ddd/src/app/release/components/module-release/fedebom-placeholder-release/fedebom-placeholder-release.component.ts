import { Component, OnDestroy, OnInit } from "@angular/core";
import { ReleaseService } from "../../../utils/services/release.service";
import {
  FedebomPlaceholderReleasePartRequest,
  FedebomReleaseModel,
} from "../../../utils/models/fedebom-placeholder-release.model";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { takeUntil } from "rxjs/operators";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";
import { Subject } from "rxjs";
import { HttpErrorResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../utils/models/error-response.model";

@Component({
  selector: "app-fedebom-placeholder-release",
  templateUrl: "./fedebom-placeholder-release.component.html",
  styleUrl: "./fedebom-placeholder-release.component.scss",
})
export class FedebomPlaceholderReleaseComponent implements OnInit, OnDestroy {
  constructor(private router: Router, private releaseService: ReleaseService) {}
  private unsubscribe$ = new Subject<void>();
  fedebomReleaseData!: FedebomReleaseModel;
  loading: boolean = false;

  releaseOptions = [
    { code: "AREUL", name: "PCM Assembly - EU/APA Legacy" },
    { code: "AFG", name: "PCM Assembly - FGEC" },
    { code: "AFGO", name: "PCM Assembly - Ford App Signing" },
    { code: "AFD", name: "PCM Assembly - FDEC" },
    { code: "AFDCX", name: "PCM Assembly - FDEC CFX" },
    { code: "UTCU2", name: "TCM Assembly - UTCU" },
  ];

  // Parts array
  parts = [
    { pnPrefix: "", hardwarePn: "" },
    { pnPrefix: "", hardwarePn: "" },
  ];

  // Flag to control display of release type name after selection
  displayReleaseType: boolean = false;

  ngOnInit() {
    this.fedebomReleaseData = new FedebomReleaseModel();
    this.parts = [];
    this.displayReleaseType = false;
    this.loading = false;
  }

  // Method to handle when user clicks "Next"
  onNext(): void {
    const selectedRelease = this.releaseOptions.find(
      (option) => option.code === this.fedebomReleaseData.releaseTypeCode
    );
    if (!selectedRelease) {
      Swal.fire({
        icon: "error",
        title: "Validation Error",
        text: "Please make sure the Release Type is selected.",
        confirmButtonColor: "#00467f",
      });
      return;
    }
    this.loading = true;
    this.fedebomReleaseData.releaseTypeName = selectedRelease.name;
    const releaseTypeCode = this.fedebomReleaseData.releaseTypeCode || "";
    this.fedebomReleaseData.moduleTypeCode =
      this.fetchModuleTypeCode(releaseTypeCode);
    this.fetchHardwarePartNumbers();
  }

  // Submit part request logic
  onSubmitPartRequest() {
    const releaseTypeCode = this.fedebomReleaseData.releaseTypeCode || "";
    const moduleTypeCode = this.fedebomReleaseData.moduleTypeCode || "";
    const sraComment = this.fedebomReleaseData.sraComment || "";
    const userId = "DSADASH1";

    if (
      !releaseTypeCode ||
      !moduleTypeCode ||
      !this.parts ||
      this.parts.length === 0
    ) {
      Swal.fire({
        icon: "error",
        title: "Validation Error",
        text: "Please make sure all required fields are filled and parts are provided.",
        confirmButtonColor: "#00467f",
      });
      return;
    }

    this.loading = true;

    const requestData: FedebomPlaceholderReleasePartRequest = {
      moduleTypeCode: moduleTypeCode,
      releaseTypeCode: releaseTypeCode,
      userId: userId,
      sraComment: sraComment,
      fedebomPlaceholderReleaseParts: this.parts,
    };

    this.releaseService
      .addFedebomPlaceholderReleaseParts(requestData)
      .subscribe({
        next: (response: any) => {
          this.loading = false;
          const successMessage = response;
          Swal.fire({
            icon: "success",
            title: "Success",
            text: successMessage,
            confirmButtonColor: "#00467f",
          }).then(() => {
            this.router.navigate(["/"]);
          });
        },
        error: (error: any) => {
          this.loading = false;
          let errorResponse: ErrorResponse;
          try {
            errorResponse = JSON.parse(error.error);
          } catch (e) {
            errorResponse = {
              status: "error",
              message:
                "Unfortunately, an error has occurred. Please check back later.",
            };
          }

          const errorMessage =
            errorResponse.message ||
            "Unfortunately, an error has occurred. Please check back later.";
          ReleaseUtils.showErrorSweetAlert("Error", `${errorMessage}`);
        },
      });
  }

  fetchModuleTypeCode(mReleaseTypeCode: string): string {
    let mModuleTypeCode: string;

    switch (mReleaseTypeCode) {
      case "AREUL":
      case "AFD":
      case "AFDCX":
      case "AFG":
      case "AFGO":
      case "ARNAL":
      case "HRDCN":
      case "HARDW":
      case "HWPT":
      case "PSUPR":
        mModuleTypeCode = "PCM";
        break;
      case "GSMA":
        mModuleTypeCode = "GSM";
        break;
      case "HASM":
      case "HASMS":
        mModuleTypeCode = "HPCM";
        break;
      case "DPS6":
      case "UTCU2":
      case "HWUTC":
      case "TSUPS":
      case "HWPUT":
      case "HWCUT":
        mModuleTypeCode = "TCM";
        break;
      case "TRCMA":
        mModuleTypeCode = "TRCM";
        break;
      case "VCMA":
      case "VCMH":
      case "VCMHP":
      case "VCMHC":
        mModuleTypeCode = "VCM";
        break;
      case "DLCMA":
      case "DLCMS":
        mModuleTypeCode = "DLCM";
        break;
      case "DCUA":
        mModuleTypeCode = "DCU";
        break;
      default:
        throw new Error("Invalid Module Type");
    }

    return mModuleTypeCode;
  }

  fetchHardwarePartNumbers() {
    const releaseTypeCode = this.fedebomReleaseData.releaseTypeCode || "";
    const moduleTypeCode = this.fedebomReleaseData.moduleTypeCode || "";

    this.releaseService
      .getHardwarePartNumbersByReleaseTypeAndModuleType(
        releaseTypeCode,
        moduleTypeCode
      )
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.fedebomReleaseData.hardwarePartNumbers = response;
          this.loading = false;
          this.displayReleaseType = true;
          this.adjustPartsArray();
        },
        error: (error: HttpErrorResponse) => {
          this.loading = false;
          this.handleError(error);
        },
      });
  }

  adjustPartsArray(): void {
    const numParts = Math.min(
      this.fedebomReleaseData.hardwarePartNumbers.length,
      10
    );

    this.parts = Array.from({ length: numParts }, (_, index) => ({
      pnPrefix: "",
      hardwarePn: this.fedebomReleaseData.hardwarePartNumbers[index] || "",
    }));
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage =
      "Something went wrong while fetching the hardware part numbers.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
    this.router.navigate(["/"]);
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
