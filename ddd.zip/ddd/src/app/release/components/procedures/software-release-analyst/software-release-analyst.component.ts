import { Component } from "@angular/core";

@Component({
  selector: "app-software-release-analyst",
  templateUrl: "./software-release-analyst.component.html",
  styleUrl: "./software-release-analyst.component.scss",
})
export class SoftwareReleaseAnalystComponent {}
