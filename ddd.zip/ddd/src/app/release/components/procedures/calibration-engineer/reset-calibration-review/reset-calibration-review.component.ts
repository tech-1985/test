import { Component } from "@angular/core";

@Component({
  selector: "app-reset-calibration-review",
  templateUrl: "./reset-calibration-review.component.html",
  styleUrl: "./reset-calibration-review.component.scss",
})
export class ResetCalibrationReviewComponent {}
