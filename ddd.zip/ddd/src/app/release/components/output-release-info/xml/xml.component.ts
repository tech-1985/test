import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ReleaseService } from "../../../utils/services/release.service";
import {
  ExportToXmlPostModel,
  FirmwareExportForm,
} from "../../../utils/models/xml.model";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";
import { HttpResponse } from "@angular/common/http";

@Component({
  selector: "app-xml",
  templateUrl: "./xml.component.html",
  styleUrl: "./xml.component.scss",
})
export class XmlComponent implements OnInit {
  constructor(private router: Router, private releaseService: ReleaseService) {}
  firmwareExportForm!: FirmwareExportForm;

  ngOnInit() {
    this.firmwareExportForm = new FirmwareExportForm();
  }

  handleKeyDown(event: KeyboardEvent) {
    if (event.key === "Enter") {
      event.preventDefault();
    }
  }

  validateInputs(): boolean {
    const { concernNumber, wersNoticeNumber, partNumbers } =
      this.firmwareExportForm;

    const isPartNumberFilled = partNumbers.some((part) => part.trim() !== "");
    return !!(concernNumber || wersNoticeNumber || isPartNumberFilled);
  }
  onOKClick() {
    if (this.validateInputs()) {
      const {
        exportVersion,
        exportFilename,
        concernNumber,
        wersNoticeNumber,
        partNumbers,
      } = this.firmwareExportForm;

      const uniquePartNumbers = Array.from(
        new Set(partNumbers.filter((part) => part.trim() !== ""))
      );

      const exportToXmlData: ExportToXmlPostModel = {
        partNumbers: uniquePartNumbers,
        exportFilename,
        concernNumber,
        wersNoticeNumber,
        exportVersion,
        createUser: "DSADASH1",
      };

      ReleaseUtils.exportToXML(this.releaseService, exportToXmlData);
    } else {
      ReleaseUtils.showErrorSweetAlert(
        "Error",
        "Please provide at least one of the following:<br> Concern Number <br> WERS Notice Number <br> Atleast one Part Number"
      );
    }
  }

  onCancelClick() {
    this.firmwareExportForm = new FirmwareExportForm();
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }
}
