import { Component } from "@angular/core";

@Component({
  selector: "app-ford-ivs-calibration-download",
  templateUrl: "./ford-ivs-calibration-download.component.html",
  styleUrl: "./ford-ivs-calibration-download.component.scss",
})
export class FordIvsCalibrationDownloadComponent {}
