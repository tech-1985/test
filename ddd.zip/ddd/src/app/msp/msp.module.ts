import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { MspRoutingModule } from "./msp-routing.module";

@NgModule({
  declarations: [],
  imports: [CommonModule, MspRoutingModule],
})
export class MspModule {}
