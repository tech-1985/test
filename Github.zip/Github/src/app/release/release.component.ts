import { Component, OnInit, Renderer2 } from "@angular/core";
import { Router, NavigationEnd } from "@angular/router";
import { filter } from "rxjs";

@Component({
  selector: "app-release",
  templateUrl: "./release.component.html",
  styleUrls: ["./release.component.scss"],
})
export class ReleaseComponent implements OnInit {
  hasRouteContent = false;
  defaultMessage = "Welcome to the Release Home page!";

  constructor(private router: Router, private renderer: Renderer2) {}

  ngOnInit(): void {
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe(() => {
        const isDefaultTextRoute =
          this.router.url === "/release" || this.router.url === "/";
        this.hasRouteContent = !isDefaultTextRoute;

        const releaseWrapper = document.querySelector(".release-wrapper");
        if (releaseWrapper) {
          if (isDefaultTextRoute) {
            this.renderer.setStyle(releaseWrapper, "overflow-y", "hidden");
          } else {
            this.renderer.setStyle(releaseWrapper, "overflow-y", "scroll");
          }
        }
      });
  }
}
