import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FedebomPlaceholderReleaseComponent } from './fedebom-placeholder-release.component';

describe('FedebomPlaceholderReleaseComponent', () => {
  let component: FedebomPlaceholderReleaseComponent;
  let fixture: ComponentFixture<FedebomPlaceholderReleaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FedebomPlaceholderReleaseComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FedebomPlaceholderReleaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
