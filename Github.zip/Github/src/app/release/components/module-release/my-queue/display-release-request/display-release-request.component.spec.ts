import { ComponentFixture, TestBed } from "@angular/core/testing";

import { DisplayReleaseRequestComponent } from "./display-release-request.component";

describe("DisplayReleaseRequestComponent", () => {
  let component: DisplayReleaseRequestComponent;
  let fixture: ComponentFixture<DisplayReleaseRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DisplayReleaseRequestComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DisplayReleaseRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
