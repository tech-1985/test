import { Component, OnInit } from "@angular/core";
import { ReleaseService } from "../../../utils/services/release.service";
import {
  AddPartIIModel,
  AddPartIIPdxPostModel,
} from "../../../utils/models/part-II.model";
import {
  MicroTypesOptionModel,
  ModuleTypesOptionsModel,
} from "../../../utils/models/shared.model";
import { ErrorResponse } from "../../../utils/models/error-response.model";
import Swal from "sweetalert2";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";

import { Router } from "@angular/router";
@Component({
  selector: "app-add-new-part-ii-or-pdx",
  templateUrl: "./add-new-part-ii-or-pdx.component.html",
  styleUrl: "./add-new-part-ii-or-pdx.component.scss",
})
export class AddNewPartIIOrPdxComponent implements OnInit {
  constructor(private router: Router, private releaseService: ReleaseService) {}

  addPartIIData: AddPartIIModel = new AddPartIIModel();
  moduleTypeOptions: Array<ModuleTypesOptionsModel> = new Array();
  microTypeOptions: Array<MicroTypesOptionModel> = new Array();

  filteredOptionsModuleType: Array<ModuleTypesOptionsModel> = new Array();
  filteredOptionsMicroType: Array<MicroTypesOptionModel> = new Array();

  ngOnInit() {
    this.addPartIIData.releaseType = "PII";
    this.getModuleTypes();
  }

  filterOptions(changeOpt: String) {
    if (changeOpt === "module_type") {
      if (this.addPartIIData.moduleTypeName) {
        this.filteredOptionsModuleType = this.moduleTypeOptions.filter(
          (option) =>
            option.moduleTypeName
              .toLowerCase()
              .includes(String(this.addPartIIData.moduleTypeName.toLowerCase()))
        );
      } else {
        this.filteredOptionsModuleType = this.moduleTypeOptions;
      }
    }

    if (changeOpt === "micro_type") {
      if (this.addPartIIData.microTypeName) {
        this.filteredOptionsMicroType = this.microTypeOptions.filter((option) =>
          option.microTypeName
            .toLowerCase()
            .includes(String(this.addPartIIData.microTypeName.toLowerCase()))
        );
      } else {
        this.filteredOptionsMicroType = this.microTypeOptions;
      }
    }
  }

  getModuleTypes() {
    try {
      this.releaseService.getModuleTypes().subscribe((res) => {
        if (res.length > 0) {
          this.moduleTypeOptions = res;
          this.filterOptions("module_type");
        } else {
          console.error(
            "Something went wrong while fetching the module types."
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  handleModuleType(moduleTypeName: string) {
    this.addPartIIData.microTypeName = "";

    if (!moduleTypeName) {
      this.microTypeOptions = [];
    } else {
      const option = this.moduleTypeOptions.find(
        (option) => option.moduleTypeName === moduleTypeName
      );

      this.getMicroTypes(option ? option.moduleTypeCode : "");
    }
  }

  getMicroTypes(moduleTypeCode: string) {
    try {
      this.releaseService.getMicroTypes(moduleTypeCode).subscribe(
        (res) => {
          if (res.length > 0) {
            this.microTypeOptions = res;
            this.filterOptions("micro_type");
          } else {
            console.error(
              "Something went wrong while fetching the micro types."
            );
            this.resetMicroType();
          }
        },
        (error) => {
          console.error("Error fetching micro types:", error);
          this.resetMicroType();
        }
      );
    } catch (err) {
      console.error(err);
      this.resetMicroType();
    }
  }

  resetMicroType() {
    this.addPartIIData.microTypeName = "";
    this.microTypeOptions = [];
  }
  cancelSubmit() {
    this.addPartIIData = new AddPartIIModel();
    this.addPartIIData.releaseType === "PII";
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  validatePartIIData() {
    const {
      releaseType,
      microTypeName,
      moduleTypeCode,
      ggdsVersion,
      swdlVersion,
      partNumber,
    } = this.addPartIIData;

    let errorMessages = [];

    if (!microTypeName) {
      errorMessages.push("* Select Main Micro Type.");
    }
    if (!releaseType) {
      errorMessages.push("* Select Release Type.");
    }
    if (!moduleTypeCode) {
      errorMessages.push("* Select Module Type.");
    }

    if (!ggdsVersion) {
      errorMessages.push("* GGDS Version Part Required.");
    }

    if (!swdlVersion) {
      errorMessages.push("* SWDL Version Part.");
    }

    if (ReleaseUtils.TestPartNumber(partNumber, releaseType) === false) {
      if (releaseType === "PDX") {
        errorMessages.push(
          `'${partNumber}' is not a valid part number. Must start with PX.`
        );
      } else {
        errorMessages.push(
          `'${partNumber}' is not a valid part number. Must start with DS.`
        );
      }
    } else {
      const basePartValidationResult =
        ReleaseUtils.ValidateAssemblyBasePartNumberFromModuleType(
          moduleTypeCode,
          partNumber
        );
      if (basePartValidationResult) {
        errorMessages.push(basePartValidationResult);
      }
    }

    if (errorMessages.length > 0) {
      const fullMessage =
        errorMessages.join("<br>") +
        "<br><br>Please correct the issues listed above and try again.";
      ReleaseUtils.showErrorSweetAlert("Error", fullMessage);
      return false;
    }

    return true;
  }

  addPart() {
    if (this.validatePartIIData()) {
      const {
        releaseType,
        microTypeCode,
        moduleTypeCode,
        ggdsVersion,
        swdlVersion,
        partNumber,
        description,
        uploadedToVSEM,
      } = this.addPartIIData;

      const dataToSend: AddPartIIPdxPostModel = {
        releaseType,
        microTypeCode,
        moduleTypeCode,
        ggdsVersion,
        swdlVersion,
        partNumber,
        createUser: "DSADASH1",
        lastUpdateUser: "DSADASH1",
        description,
        uploadedToVSEM,
      };

      this.releaseService.addPartIIPDX(dataToSend).subscribe({
        next: (response: any) => {
          const successMessage = response;
          Swal.fire({
            icon: "success",
            title: "Success",
            text: successMessage,
            confirmButtonColor: "#00467f",
          }).then(() => {
            this.router.navigate(["/"]);
          });
        },
        error: (error: any) => {
          let errorResponse: ErrorResponse;
          try {
            errorResponse = JSON.parse(error.error);
          } catch (e) {
            errorResponse = {
              status: "error",
              message:
                "Unfortunately, an error has occurred. Please check back later.",
            };
          }

          const errorMessage =
            errorResponse.message ||
            "Unfortunately, an error has occurred. Please check back later.";
          ReleaseUtils.showErrorSweetAlert("Error", `${errorMessage}`);
        },
      });
    }
  }
}
