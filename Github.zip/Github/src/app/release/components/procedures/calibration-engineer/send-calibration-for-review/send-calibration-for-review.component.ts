import { Component } from "@angular/core";

@Component({
  selector: "app-send-calibration-for-review",
  templateUrl: "./send-calibration-for-review.component.html",
  styleUrl: "./send-calibration-for-review.component.scss",
})
export class SendCalibrationForReviewComponent {}
