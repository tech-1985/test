import { Component, OnDestroy, OnInit } from "@angular/core";
import {
  FindProductionPartNumberModel,
  FindProductionPartNumberPostModel,
  ProductionPartNumberRecord,
} from "../../../utils/models/find-production-part-number-model";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";
import { Router } from "@angular/router";
import { ReleaseService } from "../../../utils/services/release.service";
import { Subject, takeUntil } from "rxjs";
import { HttpErrorResponse, HttpResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../utils/models/error-response.model";
import { PrismInputData } from "../../../utils/models/prism-input.model";

@Component({
  selector: "app-prism-input",
  templateUrl: "./prism-input.component.html",
  styleUrl: "./prism-input.component.scss",
})
export class PrismInputComponent implements OnInit, OnDestroy {
  productionPartNumberData!: FindProductionPartNumberModel;
  prismInputData!: PrismInputData;
  displayProductionPartNumberResults: boolean = false;
  displayPrismInput: boolean = false;
  firmwareRecords: ProductionPartNumberRecord[] = [];
  private unsubscribe$ = new Subject<void>();

  constructor(private router: Router, private releaseService: ReleaseService) {}

  ngOnInit() {
    this.resetState();
    this.productionPartNumberData.pnBase = "12A650";
    this.productionPartNumberData.swpnBase = "14C204";
  }

  resetState() {
    this.productionPartNumberData = new FindProductionPartNumberModel();
    this.firmwareRecords = [];
    this.displayProductionPartNumberResults = false;
  }

  onSearch() {
    const {
      pnPre,
      pnBase,
      pnSuffix,
      wersNotice,
      catchWord,
      swpnPre,
      swpnBase,
      swpnSuffix,
      calibrationNumber,
      stratRelName,
      chipID,
    } = this.productionPartNumberData;

    if (this.validateWersNotice(wersNotice)) {
      const findProductionPartNumberData: FindProductionPartNumberPostModel = {
        partNumber: this.getPartNumber(pnPre, pnBase, pnSuffix),
        wersNotice,
        catchWord,
        softwarePartNumber: this.getSwPartNumber(swpnPre, swpnBase, swpnSuffix),
        calibrationNumber,
        stratRelName,
        chipID,
      };
      this.displayProductionPartNumberResults = true;
      this.releaseService
        .getFirmwareDetailsByProductionPartNumber(findProductionPartNumberData)
        .pipe(takeUntil(this.unsubscribe$))
        .subscribe({
          next: (response: any) => {
            this.firmwareRecords = Array.isArray(response) ? response : [];
          },
          error: (error: HttpErrorResponse) => this.handleError(error),
        });
    }
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage =
      "Unfortunately, an error has occurred. Please check back later.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }

  onCancelClick() {
    this.resetState();
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  getPartNumber(pnPre: string, pnBase: string, pnSuffix: string): string {
    let strPartNum: string;

    strPartNum = pnPre.length === 0 ? "*" : pnPre;
    strPartNum += "-";
    strPartNum += pnBase.length === 0 ? "*" : pnBase;
    strPartNum += "-";
    strPartNum += pnSuffix.length === 0 ? "*" : pnSuffix;
    strPartNum = strPartNum.toUpperCase();

    return strPartNum !== "*-*-*" && strPartNum !== "*-12A650-*"
      ? strPartNum
      : "";
  }

  getSwPartNumber(
    swPnPre: string,
    swPnBase: string,
    swPnSuffix: string
  ): string {
    let strSwPartNum: string;

    strSwPartNum = swPnPre.length === 0 ? "*" : swPnPre;
    strSwPartNum += "-";
    strSwPartNum += swPnBase.length === 0 ? "*" : swPnBase;
    strSwPartNum += "-";
    strSwPartNum += swPnSuffix.length === 0 ? "*" : swPnSuffix;
    strSwPartNum = strSwPartNum.toUpperCase();

    return strSwPartNum !== "*-*-*" && strSwPartNum !== "*-14C204-*"
      ? strSwPartNum
      : "";
  }

  validateWersNotice(wersNotice: string): boolean {
    const trimmedNotice = wersNotice.trim();

    if (trimmedNotice.length > 0) {
      const noticePattern = /^[A-Z]{4} [EeIi] \d{8} \d{3}$/;

      if (!noticePattern.test(trimmedNotice)) {
        ReleaseUtils.showErrorSweetAlert(
          "Error",
          "WERS Notice has the incorrect format. The format must be 'APED E 12345678 000'.<br>4 characters, space, e or i, space, 8 digits, space, 3 digits"
        );

        return false;
      }

      const sanitizedNotice = trimmedNotice.replace(/-/g, " ");
      this.productionPartNumberData.wersNotice = sanitizedNotice;
    }

    return true;
  }

  exportToCSV() {
    this.releaseService.exportPartsToCSV(this.firmwareRecords).subscribe(
      (response) => {
        const blob = new Blob([response], {
          type: "text/csv;charset=utf-8;",
        });

        const url = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = "FirmwareExport.csv";

        document.body.appendChild(a);

        a.click();

        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      },
      (error) => {
        console.error("Error exporting parts to CSV:", error);
      }
    );
  }

  exportToExcel() {
    ReleaseUtils.exportToExcel(
      this.releaseService,
      Array.from(this.firmwareRecords.map((record) => record.partNumber))
    );
  }

  displayPrismInputDetails(partNumber: String) {
    this.displayProductionPartNumberResults = false;
    this.displayPrismInput = true;

    this.releaseService
      .getPrismInputDetailsByPartNumber(partNumber)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.prismInputData = response;
        },
        error: (error: HttpErrorResponse) => this.handleError(error),
      });
  }
  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
