import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ReleaseService } from "../../../utils/services/release.service";
import { Subject, takeUntil } from "rxjs";
import { HttpErrorResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";
import { DomSanitizer, SafeHtml } from "@angular/platform-browser"; // Import DomSanitizer

@Component({
  selector: "app-wers-power-select-table",
  templateUrl: "./wers-power-select-table.component.html",
  styleUrls: ["./wers-power-select-table.component.scss"],
})
export class WersPowerSelectTableComponent implements OnInit {
  wersConcern: string = "";
  generatedHtml: SafeHtml = "";
  constructor(
    private router: Router,
    private releaseService: ReleaseService,
    private sanitizer: DomSanitizer
  ) {}

  private unsubscribe$ = new Subject<void>();

  ngOnInit() {
    this.wersConcern = "";
  }

  displayWersTextDetails() {
    if (this.wersConcern) {
      this.releaseService
        .getWersTextDetailsByWersConcern(this.wersConcern)
        .pipe(takeUntil(this.unsubscribe$))
        .subscribe({
          next: (response: any) => {
            this.generateHtmlForm(response);
          },
          error: (error: HttpErrorResponse) => this.handleError(error),
        });
    }
  }

  generateHtmlForm(wersText: string) {
    const sanitizedText = this.sanitizeHtml(wersText);

    const escapedText = this.escapeHtml(sanitizedText);
    const displayedText = this.replaceLineBreaks(sanitizedText);

    this.generatedHtml = this.sanitizer.bypassSecurityTrustHtml(`
      <div>
        <!-- Display the generated WERS text -->
        <pre>${displayedText}</pre>
        <!-- Button to trigger the "Open in Notepad" functionality -->
        <button (click)="openTextInNotepad()" class="btn btn-sm btn-warning">
          Open Text in Notepad
        </button>
      </div>
    `);
  }

  escapeHtml(unsafe: string): string {
    return unsafe.replace(/["&'<>]/g, function (char) {
      switch (char) {
        case '"':
          return "&quot;";
        case "&":
          return "&amp;";
        case "'":
          return "&#039;";
        case "<":
          return "&lt;";
        case ">":
          return "&gt;";
        default:
          return char;
      }
    });
  }

  replaceLineBreaks(text: string): string {
    return text.replace(/\n/g, "<br>");
  }

  sanitizeHtml(input: string): string {
    const allowedTags = ["b", "i", "em", "strong", "u", "br", "p"];
    const tagPattern = /<([^>]+)>/g;

    return input.replace(tagPattern, (match, tag) => {
      const tagName = tag.split(" ")[0].toLowerCase();
      if (allowedTags.includes(tagName)) {
        return match;
      } else {
        return "";
      }
    });
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage =
      "Unfortunately, an error has occurred. Please check back later.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }

  cancelSubmit() {
    this.wersConcern = "";
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  openTextInNotepad() {
    const escapedText = this.escapeHtml(this.wersConcern);
    const blob = new Blob([escapedText], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "wers_text.txt";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
