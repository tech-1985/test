import { API_BASE_URL } from "../../../utils/shared-constants.model";

const API_V: string = "api/v1";
const COMMON_API_PATH: string = `${API_BASE_URL}/${API_V}`;

const API_PATH = Object.freeze({
  /********************************** LOOKUP API PATH *******************************************/
  SUPPLIER_API_PATH: `${COMMON_API_PATH}/lookup/suppliers`,
  MICROTYPES_API_PATH: `${COMMON_API_PATH}/lookup/micro-types`,
  MODULETYPES_API_PATH: `${COMMON_API_PATH}/lookup/module-types`,
  FETCH_PARTS_BY_FIRMWARE_API_PATH: `${COMMON_API_PATH}/lookup/parts-by-firmware`,
  MODULENAMES_API_PATH: `${COMMON_API_PATH}/lookup/module-names`,
  MICRONAMES_API_PATH: `${COMMON_API_PATH}/lookup/micro-names`,
  FETCH_RELEASE_STATUS_DETAILS_API_PATH: `${COMMON_API_PATH}/lookup/release-status`,
  FETCH_RELEASE_REQUEST_DETAILS_API_PATH: `${COMMON_API_PATH}/lookup/release-request`,
  FETCH_PROGRAMS_API_PATH: `${COMMON_API_PATH}/lookup/programs`,
  RELEASE_TYPE_BY_MODULE_TYPE_CODE_PATH: `${COMMON_API_PATH}/lookup/release-types/module-type`,
  FETCH_FIRMDETAILS_BY_RELEASETYPE_PATH: `${COMMON_API_PATH}/lookup/firmware/release-type`,
  FETCH_RELEASE_REQUEST_DETAILS_BY_ID_PATH: `${COMMON_API_PATH}/lookup/release-request`,
  RELEASETYPES_API_PATH: `${COMMON_API_PATH}/lookup/release-types`,
  RELEASEUSAGES_API_PATH: `${COMMON_API_PATH}/lookup/release-usages`,
  PRISM_INPUT_DETAILS_API_PATH: `${COMMON_API_PATH}/lookup/data-prism-input/part-number`,
  RELEASE_REQUEST_BY_USER_ID_PATH: `${COMMON_API_PATH}/lookup/release-request/user-id`,
  RELEASE_IN_PROCESS_BY_USER_ID_PATH: `${COMMON_API_PATH}/lookup/release-in-process/user-id`,
  RELEASE_SETUP_BY_USER_ID_PATH: `${COMMON_API_PATH}/lookup/release-setup/user-id`,
  PRE_SOFT_LOCK_SIGNOFF_BY_USER_ID_PATH: `${COMMON_API_PATH}/lookup/pre-soft-lock-signoff/user-id`,
  HARD_LOCK_SIGNOFF_BY_USER_ID_PATH: `${COMMON_API_PATH}/lookup/hard-lock-signoff/user-id`,
  POST_HARD_LOCK_SIGNOFF_BY_USER_ID_PATH: `${COMMON_API_PATH}/lookup/post-hard-lock-signoff/user-id`,
  MAIN_MICRO_TYPE_BY_USER_ID_PATH: `${COMMON_API_PATH}/lookup/main-micro-type/user-id`,
  HARDWARE_PART_NUMBERS_PATH: `${COMMON_API_PATH}/lookup/hardware-part-numbers`,

  /********************************** SEARCH API PATH *******************************************/
  WERS_CONCERN_SEARCH_API_PATH: `${COMMON_API_PATH}/search/wers-concern`,
  WERS_NOTICE_SEARCH_API_PATH: `${COMMON_API_PATH}/search/wers-notice`,
  PROGRAMS_SEARCH_API_PATH: `${COMMON_API_PATH}/search/programs`,
  RELEASE_STATUS_SEARCH_BY_WERS_CONCERN_API_PATH: `${COMMON_API_PATH}/search/release-status/wers-concern`,
  RELEASE_REQUEST_SEARCH_API_PATH: `${COMMON_API_PATH}/search/release-request`,
  PART_NUMBER_SEARCH_API_PATH: `${COMMON_API_PATH}/search/part-number`,
  PRODUCTION_PART_NUMBER_SEARCH_API_PATH: `${COMMON_API_PATH}/search/production-part-number`,
  WERS_TEXT_SEARCH_API_PATH: `${COMMON_API_PATH}/search/wers-text/wers-concern`,

  /********************************** MODULE RELEASE API PATH *******************************************/
  ADD_REPLACE_SBL_API_PATH: `${COMMON_API_PATH}/module-release/sbl`,
  FIND_PARTS_BY_FIRMWARE_API_PATH: `${COMMON_API_PATH}/lookup/findPartsByFirmware`,
  ADD_REPLACE_PBL_API_PATH: `${COMMON_API_PATH}/module-release/pbl`,
  ADD_PARTII_PDX_API_PATH: `${COMMON_API_PATH}/module-release/part2-pdx`,
  ADD_NEW_MICRO_TYPE_API_PATH: `${COMMON_API_PATH}/module-release/main-micro-type`,
  ADD_FEDEBOM_PLACEHOLDER_RELEASE_PARTS_API_PATH:  `${COMMON_API_PATH}/module-release/fedebom-placeholder-release`,
  /********************************** Export API PATH *******************************************/
  EXPORT_EXCEL_PARTS_API_PATH: `${COMMON_API_PATH}/export/parts`,
  EXPORT_XML_PARTS_API_PATH: `${COMMON_API_PATH}/export/firmware-xml`,
  EXPORT_EXCEL_RELEASE_REQUEST_API_PATH: `${COMMON_API_PATH}/export/release-request`,
  EXPORT_EXCEL_PRISM_PARTS_API_PATH: `${COMMON_API_PATH}/export/prism/parts`,

  /********************************** Enrollment API PATH *******************************************/
  SUPPLIER_ENROLLMENT_PATH: `${COMMON_API_PATH}/enrollment/supplier`,
});

export default API_PATH;
