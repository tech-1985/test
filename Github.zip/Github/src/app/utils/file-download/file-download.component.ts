import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { FileDownloadService } from "../services/file-download.service";

@Component({
  selector: "app-file-download",
  template: "", 
})
export class FileDownloadComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private fileDownloadService: FileDownloadService,
    private router: Router
  ) {}

  ngOnInit() {
    const filePath = this.route.snapshot.routeConfig?.path;
    if (filePath) {
      this.fileDownloadService.openFile(filePath);
      this.router.navigate(["/"]);
    }
  }
}
