package com.ford.gpcse.enums;

public enum ModuleTypeCode {
	PCM, GSM, HPCM, TCM, TRCM, VCM, DCU, DLCM;
}
