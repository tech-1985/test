package com.ford.gpcse.service;

import org.springframework.core.io.Resource;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;

public interface FirmwareXmlExportV3Service {
	Resource generateFirmwareV3Xml(ExportFirmwareXmlRequest exportFirmwareXmlRequest);
}
