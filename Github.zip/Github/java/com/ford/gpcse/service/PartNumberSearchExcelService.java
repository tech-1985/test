package com.ford.gpcse.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

public interface PartNumberSearchExcelService {

	ByteArrayInputStream exportPartsByPartNumbers(List<String> partNumbers) throws IOException;
}
