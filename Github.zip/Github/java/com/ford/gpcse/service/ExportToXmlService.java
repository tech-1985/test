package com.ford.gpcse.service;

import org.springframework.core.io.Resource;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;

public interface ExportToXmlService {

	Resource exportFirmwareDataToXML(ExportFirmwareXmlRequest exportFirmwareXmlRequest);
}
