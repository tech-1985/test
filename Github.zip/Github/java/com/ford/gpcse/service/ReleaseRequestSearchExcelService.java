package com.ford.gpcse.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import com.ford.gpcse.bo.ReleaseRequestSearchInput;

public interface ReleaseRequestSearchExcelService {
	ByteArrayInputStream exportReleaseRequestDetails(ReleaseRequestSearchInput releaseRequestSearchInput)
			throws IOException;

}
