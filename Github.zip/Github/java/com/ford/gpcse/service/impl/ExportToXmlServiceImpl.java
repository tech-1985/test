package com.ford.gpcse.service.impl;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.ford.gpcse.bo.ExportFirmwareXmlRequest;
import com.ford.gpcse.service.ExportToXmlService;
import com.ford.gpcse.service.FirmwareXmlExportV10Service;
import com.ford.gpcse.service.FirmwareXmlExportV3Service;
import com.ford.gpcse.service.FirmwareXmlExportV4Service;
import com.ford.gpcse.service.FirmwareXmlExportV5Service;
import com.ford.gpcse.service.FirmwareXmlExportV6Service;
import com.ford.gpcse.service.FirmwareXmlExportV7Service;
import com.ford.gpcse.service.FirmwareXmlExportV8Service;
import com.ford.gpcse.service.FirmwareXmlExportV9Service;

@Service
public class ExportToXmlServiceImpl implements ExportToXmlService {

	private static final Logger log = LoggerFactory.getLogger(ExportToXmlServiceImpl.class);

	private final FirmwareXmlExportV3Service firmwareXmlExportV3Service;
	private final FirmwareXmlExportV4Service firmwareXmlExportV4Service;
	private final FirmwareXmlExportV5Service firmwareXmlExportV5Service;
	private final FirmwareXmlExportV6Service firmwareXmlExportV6Service;
	private final FirmwareXmlExportV7Service firmwareXmlExportV7Service;
	private final FirmwareXmlExportV8Service firmwareXmlExportV8Service;
	private final FirmwareXmlExportV9Service firmwareXmlExportV9Service;
	private final FirmwareXmlExportV10Service firmwareXmlExportV10Service;

	public ExportToXmlServiceImpl(FirmwareXmlExportV3Service firmwareXmlExportV3Service,
			FirmwareXmlExportV4Service firmwareXmlExportV4Service,
			FirmwareXmlExportV5Service firmwareXmlExportV5Service,
			FirmwareXmlExportV6Service firmwareXmlExportV6Service,
			FirmwareXmlExportV7Service firmwareXmlExportV7Service,
			FirmwareXmlExportV8Service firmwareXmlExportV8Service,
			FirmwareXmlExportV9Service firmwareXmlExportV9Service,
			FirmwareXmlExportV10Service firmwareXmlExportV10Service) {
		this.firmwareXmlExportV3Service = firmwareXmlExportV3Service;
		this.firmwareXmlExportV4Service = firmwareXmlExportV4Service;
		this.firmwareXmlExportV5Service = firmwareXmlExportV5Service;
		this.firmwareXmlExportV6Service = firmwareXmlExportV6Service;
		this.firmwareXmlExportV7Service = firmwareXmlExportV7Service;
		this.firmwareXmlExportV8Service = firmwareXmlExportV8Service;
		this.firmwareXmlExportV9Service = firmwareXmlExportV9Service;
		this.firmwareXmlExportV10Service = firmwareXmlExportV10Service;
	}

	@Override
	public Resource exportFirmwareDataToXML(ExportFirmwareXmlRequest exportFirmwareXmlRequest) {

		if ((exportFirmwareXmlRequest.concernNumber() == null || exportFirmwareXmlRequest.concernNumber().isEmpty())
				&& (exportFirmwareXmlRequest.partNumbers() == null || exportFirmwareXmlRequest.partNumbers().isEmpty())
				&& (exportFirmwareXmlRequest.wersNoticeNumber() == null
						|| exportFirmwareXmlRequest.wersNoticeNumber().isEmpty())) {
			try {
				var outputStream = new ByteArrayOutputStream();
				outputStream.write("<ROOT><ERROR>YOU MUST PROVIDE A WHERE CLAUSE.</ERROR></ROOT>"
						.getBytes(StandardCharsets.UTF_8));
				return new ByteArrayResource(outputStream.toByteArray());
			} catch (Exception e) {
				log.error("Error occurred while generating Firmware Xml : {}", e.getMessage());
			}
		}

		String exportVersion = exportFirmwareXmlRequest.exportVersion();
		return switch (exportVersion != null ? exportVersion : "default") {
		case "3" -> firmwareXmlExportV3Service.generateFirmwareV3Xml(exportFirmwareXmlRequest);
		case "4" -> firmwareXmlExportV4Service.generateFirmwareV4Xml(exportFirmwareXmlRequest);
		case "5" -> firmwareXmlExportV5Service.generateFirmwareV5Xml(exportFirmwareXmlRequest);
		case "6" -> firmwareXmlExportV6Service.generateFirmwareV6Xml(exportFirmwareXmlRequest);
		case "7" -> firmwareXmlExportV7Service.generateFirmwareV7Xml(exportFirmwareXmlRequest);
		case "8" -> firmwareXmlExportV8Service.generateFirmwareV8Xml(exportFirmwareXmlRequest);
		case "9" -> firmwareXmlExportV9Service.generateFirmwareV9Xml(exportFirmwareXmlRequest);
		default -> firmwareXmlExportV10Service.generateFirmwareV10Xml(exportFirmwareXmlRequest);
		};
	}
}
