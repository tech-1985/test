package com.ford.gpcse.service.impl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ford.gpcse.bo.Part2PdxRequest;
import com.ford.gpcse.bo.VsemServiceResponse;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.exception.InvalidPartNumberException;
import com.ford.gpcse.exception.UnableToInsertException;
import com.ford.gpcse.external.vsem.service.VsemService;
import com.ford.gpcse.repository.FirmwareItemRepository;
import com.ford.gpcse.repository.MicroTypeRepository;
import com.ford.gpcse.repository.ModuleTypeRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.ReleaseTypeRepository;
import com.ford.gpcse.service.Part2PdxService;

@Service
public class Part2PdxServiceImpl implements Part2PdxService {

	private final VsemService vsemService;
	private final PartRepository partRepository;
	private final FirmwareItemRepository firmwareItemRepository;
	private final ModuleTypeRepository moduleTypeRepository;
	private final ReleaseTypeRepository releaseTypeRepository;
	private final MicroTypeRepository microTypeRepository;

	public Part2PdxServiceImpl(VsemService vsemService, PartRepository partRepository,
			FirmwareItemRepository firmwareItemRepository, ModuleTypeRepository moduleTypeRepository,
			ReleaseTypeRepository releaseTypeRepository, MicroTypeRepository microTypeRepository) {
		super();
		this.vsemService = vsemService;
		this.partRepository = partRepository;
		this.firmwareItemRepository = firmwareItemRepository;
		this.moduleTypeRepository = moduleTypeRepository;
		this.releaseTypeRepository = releaseTypeRepository;
		this.microTypeRepository = microTypeRepository;
	}

	@Override
	@Transactional
	public String addNewPart2OrPdx(Part2PdxRequest part2PdxRequest) {

		if (part2PdxRequest.releaseType().equals("PII")) {
			var vsemServiceResponse = vsemService.fetchPartFilenames(part2PdxRequest.partNumber());
			if (vsemServiceResponse == null || vsemServiceResponse.partfilenames() == null) {
				return "Unable to find part in VSEM";
			}

			if (vsemServiceResponse.status() != 200 || !vsemServiceResponse.message().isEmpty()) {
				return vsemServiceResponse.message();
			}

			var retVal = getStringBuilder(part2PdxRequest, vsemServiceResponse);

			if (!retVal.isEmpty()) {
				return retVal.toString();
			}
			return "VSEM validation failed.  Your part has not been added.  Please fix VSEM issues and try again.";
		}

		var count = partRepository.countByPartNumber(part2PdxRequest.partNumber());

		if (count > 0) {
			throw new InvalidPartNumberException("Invalid part number " + part2PdxRequest.partNumber() + ".  Part number has already been used.");
		}

		var moduleType = moduleTypeRepository.findById(part2PdxRequest.moduleTypeCode());
		var releaseType = releaseTypeRepository.findById(part2PdxRequest.releaseType());
		var microType = microTypeRepository.findById(part2PdxRequest.microTypeCode());

		if (moduleType.isPresent() && releaseType.isPresent() && microType.isPresent()) {
			var part = new Part();
			part.setPartR(part2PdxRequest.partNumber());
			part.setProdnF("Y");
			part.setArchF("N");
			part.setReldF("Y");
			part.setCreateUserC(part2PdxRequest.createUser());
			part.setLastUpdtUserC(part2PdxRequest.lastUpdateUser());
			part.setModuleType(moduleType.get());
			part.setReleaseType(releaseType.get());
			part.setMicroType(microType.get());
			part.setPartNumX(part2PdxRequest.description());
			part.setEngineerCdsidC(part2PdxRequest.createUser());
			part.setReldY(LocalDate.now());
			part.setSwDlSpecR(part2PdxRequest.swdlVersion());
			part.setGenGlblSpecR(part2PdxRequest.ggdsVersion());
			partRepository.save(part);

			var fwType = "PII";

			if (part2PdxRequest.releaseType().equals("PDX")) {
				fwType = "PDX ";
			}

			firmwareItemRepository.addFirmwareItemToDropdown("%" + fwType + "%", part2PdxRequest.moduleTypeCode(),
					part2PdxRequest.partNumber(), part2PdxRequest.createUser());
			return part2PdxRequest.partNumber() + " has been added to the firmware drop down list.";
		} else {
			throw new UnableToInsertException("Mandatory Fields Missing");
		}
	}

	private static StringBuilder getStringBuilder(Part2PdxRequest part2PdxRequest,
			VsemServiceResponse vsemServiceResponse) {
		var retVal = new StringBuilder();

		if (vsemServiceResponse.partfilenames().contains(part2PdxRequest.partNumber() + ".mdx")) {
			retVal.append("Missing mdx file\n");
		}

		if (!vsemServiceResponse.partfilenames().contains(part2PdxRequest.partNumber() + ".mdx.log")) {
			retVal.append("Missing mdx.log file\n");
		}

		if (!vsemServiceResponse.partfilenames().contains(part2PdxRequest.partNumber() + ".docx")
				&& !vsemServiceResponse.partfilenames().contains(part2PdxRequest.partNumber() + ".doc")) {
			retVal.append("Missing doc or docx file\n");
		}

		// Check part 2 status
		var approvedPart2Status = List.of("Definition Approved", "Vehicle Configuration Complete");

		if (!approvedPart2Status.contains(vsemServiceResponse.partstatus())) {
			retVal.append("Part 2 is not approved. Part 2 status must be approved.\n");
		}
		return retVal;
	}
}
