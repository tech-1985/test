package com.ford.gpcse.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ford.gpcse.entity.Signoff;

/**
 * Repository interface for accessing Signoff entities. Extends JpaRepository to
 * provide standard CRUD operations.
 */
public interface SignoffRepository extends JpaRepository<Signoff, String> {

	/**
	 * Retrieves signoff details based on the specified part reference and signoff
	 * types. The query joins two tables and filters the results where the signoff
	 * status is null and the request date is not null. It also calculates the
	 * difference in minutes from the current date to the request date.
	 *
	 * @param partR        the part reference to filter the signoff details
	 * @param signOffTypes a list of signoff types to filter the results
	 * @return a list of Object arrays containing signoff details
	 */
	@Query(value = "SELECT tblB.PCMR20_SIGNOFF_TYP_X, tblA.PCMR20_SIGNOFF_TYP_C, "
			+ "DATEDIFF(MINUTE, PCMR21_REQT_Y, GETDATE()) " + "FROM dbo.WPCMR21_SIGNOFF_PART tblA "
			+ "INNER JOIN dbo.WPCMR20_SIGNOFF tblB ON tblA.PCMR20_SIGNOFF_TYP_C = tblB.PCMR20_SIGNOFF_TYP_C "
			+ "WHERE tblA.PCMR01_PART_R = :partR " + "AND tblA.PCMR21_SIGNOFF_S IS NULL "
			+ "AND tblA.PCMR21_REQT_Y IS NOT NULL " + "AND tblA.PCMR20_SIGNOFF_TYP_C IN (:signOffTypes) "
			+ "ORDER BY tblB.PCMR20_SIGNOFF_TYP_X", nativeQuery = true)
	Optional<List<Object[]>> findSignoffDetails(@Param("partR") String partR,
			@Param("signOffTypes") List<String> signOffTypes);

	@Query(value = "SELECT s.PCMR20_SIGNOFF_TYP_C, s.PCMR20_SIGNOFF_TYP_X " + "FROM dbo.WPCMR20_SIGNOFF s "
			+ "WHERE s.PCMR20_ARCH_F = 'N' " + "ORDER BY s.PCMR20_SORT_ORD_R", nativeQuery = true)
	List<Object[]> findActiveSignoffProcesses();
}
