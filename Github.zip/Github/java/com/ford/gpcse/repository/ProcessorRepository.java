package com.ford.gpcse.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ford.gpcse.entity.Processor;

/**
 * Repository interface for accessing Processor entities. Extends JpaRepository
 * to provide standard CRUD operations.
 */
@Repository
public interface ProcessorRepository extends JpaRepository<Processor, String> {

	/**
	 * Fetches the names of active processors, formatted as "procN_flashSizeNumX".
	 * Only processors marked as active ('Y') are included in the result, sorted by
	 * their sort order.
	 *
	 * @return a list of active processor names in the specified format
	 */
	@Query("SELECT CONCAT(p.procN, '_', p.flashSizeNumX) FROM Processor p WHERE p.actvF = 'Y' ORDER BY p.sortOrdR")
	Optional<List<String>> fetchActiveMicroNames();
}
