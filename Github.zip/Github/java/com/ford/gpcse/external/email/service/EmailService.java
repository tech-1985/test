package com.ford.gpcse.external.email.service;

import org.springframework.stereotype.Service;

import com.ford.gpcse.bo.Email;

@Service
public interface EmailService {
	boolean sendMail(Email email);
}
