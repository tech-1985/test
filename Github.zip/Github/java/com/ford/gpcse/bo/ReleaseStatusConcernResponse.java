package com.ford.gpcse.bo;

import java.util.List;

import com.ford.gpcse.dto.LookupProgramDescriptionDto;

public record ReleaseStatusConcernResponse(String assemblyPN, String calibration, String drcdsId, String hardwarePN,
		String coreHardwarePN, String mainMicroType, String softwarePN, String mainStrategy, String chipD,
		List<LookupProgramDescriptionDto> programDescriptions, String lineage, ReleaseStatusDetails statusDetails) {
}
