package com.ford.gpcse.bo;

public record SupplierEnrollmentRequest(String userId, String firstName, String lastName, String emailAddress,
		String comments) {
}
