package com.ford.gpcse.bo;

public record ReleaseRequestSearchInput(Long id, String moduleTypeCode, String calibrationLevel, String status,
		String owner, String modelYear, String program, String engine, String createUser, String lastUpdateUser) {
}
