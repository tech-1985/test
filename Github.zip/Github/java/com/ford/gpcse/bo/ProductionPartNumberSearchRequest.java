package com.ford.gpcse.bo;

public record ProductionPartNumberSearchRequest(String partNumber, String wersNotice, String catchWord,
		String softwarePartNumber, String calibrationNumber, String stratRelName, String chipId) {
}
