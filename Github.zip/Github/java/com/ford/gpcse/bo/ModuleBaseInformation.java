package com.ford.gpcse.bo;

public record ModuleBaseInformation(String concernNumber, String partNumber) {
}
