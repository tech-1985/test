package com.ford.gpcse.dto;

import java.time.LocalDate;

public record ReleaseStatusDto(String concernC, String partR, String statC, String moduleTypX, String relTypX,
		LocalDate concernY) {
}
