package com.ford.gpcse.dto;

public record ReleaseStatusConcernDto(String partR, String partNumX, String calibR, String stratRelC,
		String engineerCdsidC, String hardwarePartR, String microTypX, String chipD, String stratCalibPartR,
		String statC, String suplC, String coreHardwarePartR, String relTypC, String relUsgC) {
}
