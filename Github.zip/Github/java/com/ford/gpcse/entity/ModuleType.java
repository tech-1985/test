package com.ford.gpcse.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMR14_MODULE_TYP")
public class ModuleType {

	@Id
	@Column(name = "PCMR14_MODULE_TYP_C")
	private String moduleTypC;

	@Column(name = "PCMR14_MODULE_TYP_X")
	private String moduleTypX;

	@Column(name = "PCMR14_ARCH_F")
	private String archF;

	@Column(name = "PCMR14_SORT_ORD_R", precision = 4, scale = 0)
	private BigDecimal sortOrdR;

	@Column(name = "PCMR14_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMR14_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMR14_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMR14_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;

	@Column(name = "PCMR14_VADR_MODULE_TYP_C")
	private String vadrModuleTypC;

	@Column(name = "PCMR14_CAN_NODE_D")
	private String canNodeD;

	@Column(name = "PCMR14_CAN_EXPLCT_GTWY_C")
	private String canExplctGtwyC;

	@Column(name = "PCMR14_CAN_SUB_NETWRK_ADDR_X")
	private String canSubNetwrkAddrX;

	@Column(name = "PCMR14_CAN_SUB_NODE_ADDR_X")
	private String canSubNodeAddrX;

	public String getModuleTypC() {
		return moduleTypC;
	}

	public void setModuleTypC(String moduleTypC) {
		this.moduleTypC = moduleTypC;
	}

	public String getModuleTypX() {
		return moduleTypX;
	}

	public void setModuleTypX(String moduleTypX) {
		this.moduleTypX = moduleTypX;
	}

	public String getArchF() {
		return archF;
	}

	public void setArchF(String archF) {
		this.archF = archF;
	}

	public BigDecimal getSortOrdR() {
		return sortOrdR;
	}

	public void setSortOrdR(BigDecimal sortOrdR) {
		this.sortOrdR = sortOrdR;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}

	public String getVadrModuleTypC() {
		return vadrModuleTypC;
	}

	public void setVadrModuleTypC(String vadrModuleTypC) {
		this.vadrModuleTypC = vadrModuleTypC;
	}

	public String getCanNodeD() {
		return canNodeD;
	}

	public void setCanNodeD(String canNodeD) {
		this.canNodeD = canNodeD;
	}

	public String getCanExplctGtwyC() {
		return canExplctGtwyC;
	}

	public void setCanExplctGtwyC(String canExplctGtwyC) {
		this.canExplctGtwyC = canExplctGtwyC;
	}

	public String getCanSubNetwrkAddrX() {
		return canSubNetwrkAddrX;
	}

	public void setCanSubNetwrkAddrX(String canSubNetwrkAddrX) {
		this.canSubNetwrkAddrX = canSubNetwrkAddrX;
	}

	public String getCanSubNodeAddrX() {
		return canSubNodeAddrX;
	}

	public void setCanSubNodeAddrX(String canSubNodeAddrX) {
		this.canSubNodeAddrX = canSubNodeAddrX;
	}
}
