package com.ford.gpcse.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMR04_PGM_PART")
public class ProgramPart {

	@Id
	@Column(name = "PCMS01_PGM_K")
	private Long pgmK;

	@ManyToOne
	@JoinColumn(name = "PCMR01_PART_R", referencedColumnName = "PCMR01_PART_R")
	private Part part;

	@Column(name = "PCMR04_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMR04_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMR04_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMR04_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;

	@Column(name = "PCMR04_VADR_ICE_PACK_UL_CMPL_F")
	private String vadrIcePackUlCmplF;

	@Column(name = "PCMR04_SW_PRTL_UPLOAD_CMPLT_F")
	private String swPrtlUploadCmpltF;

	@Column(name = "PCMR04_CRIS_UPLOAD_CMPLT_F")
	private String crisUploadCmpltF;

	@Column(name = "PCMR04_VADR_ICE_PACK_ARTFCT_D")
	private String vadrIcePackArtfctD;
	
	public Long getPgmK() {
		return pgmK;
	}

	public void setPgmK(Long pgmK) {
		this.pgmK = pgmK;
	}

	public Part getPart() {
		return part;
	}

	public void setPart(Part part) {
		this.part = part;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}

	public String getVadrIcePackUlCmplF() {
		return vadrIcePackUlCmplF;
	}

	public void setVadrIcePackUlCmplF(String vadrIcePackUlCmplF) {
		this.vadrIcePackUlCmplF = vadrIcePackUlCmplF;
	}

	public String getSwPrtlUploadCmpltF() {
		return swPrtlUploadCmpltF;
	}

	public void setSwPrtlUploadCmpltF(String swPrtlUploadCmpltF) {
		this.swPrtlUploadCmpltF = swPrtlUploadCmpltF;
	}

	public String getCrisUploadCmpltF() {
		return crisUploadCmpltF;
	}

	public void setCrisUploadCmpltF(String crisUploadCmpltF) {
		this.crisUploadCmpltF = crisUploadCmpltF;
	}

	public String getVadrIcePackArtfctD() {
		return vadrIcePackArtfctD;
	}

	public void setVadrIcePackArtfctD(String vadrIcePackArtfctD) {
		this.vadrIcePackArtfctD = vadrIcePackArtfctD;
	}
}
