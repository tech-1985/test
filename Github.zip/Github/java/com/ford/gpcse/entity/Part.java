package com.ford.gpcse.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMR01_PART")
public class Part {
	@Id
	@Column(name = "PCMR01_PART_R", nullable = false, length = 24)
	private String partR;

	@Column(name = "PCMR01_IPF_PART_R", length = 24)
	private String ipfPartR;

	@Column(name = "PCMR01_REPLACED_PART_R", length = 24)
	private String replacedPartR;

	@Column(name = "PCMR01_PARNT_PART_R", length = 24)
	private String parntPartR;
	@ManyToOne
	@JoinColumn(name = "PCMR08_CATCHWORD_C", referencedColumnName = "PCMR08_CATCHWORD_C")
	private Catchword catchword;

	@ManyToOne
	@JoinColumn(name = "PCMR08_CATCHWORD_TYP_C", referencedColumnName = "PCMR08_CATCHWORD_TYP_C")
	private Catchword catchwordType;

	@ManyToOne
	@JoinColumn(name = "PCMR14_MODULE_TYP_C", referencedColumnName = "PCMR14_MODULE_TYP_C")
	private ModuleType moduleType;

	@ManyToOne
	@JoinColumn(name = "PCMR15_REL_TYP_C", referencedColumnName = "PCMR15_REL_TYP_C")
	private ReleaseType releaseType;

	@ManyToOne
	@JoinColumn(name = "PCMR17_SUPL_C", referencedColumnName = "PCMR17_SUPL_C")
	private Supplier supplier;

	@ManyToOne
	@JoinColumn(name = "PCMR19_MICRO_TYP_C", referencedColumnName = "PCMR19_MICRO_TYP_C")
	private MicroType microType;

	@ManyToOne
	@JoinColumn(name = "PCMR24_REL_USG_C", referencedColumnName = "PCMR24_REL_USG_C")
	private RelUsg releaseUsage;
	@ManyToOne
	@JoinColumn(name = "PCMR26_BACKWARD_COMPAT_C", referencedColumnName = "PCMR26_BACKWARD_COMPAT_C")
	private BackwardCompat backwardCompat;

	@ManyToOne
	@JoinColumn(name = "PCMR39_LABEL_USG_K", referencedColumnName = "PCMR39_LABEL_USG_K")
	private LabelUsg labelUsage;

	@ManyToOne
	@JoinColumn(name = "PCMR40_RGN_BUILT_C", referencedColumnName = "PCMR40_RGN_BUILT_C")
	private RgnBuilt regionBuilt;

	@OneToMany(mappedBy = "part")
	List<PartSignoff> partSignoffs;

	@OneToMany(mappedBy = "part", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<ProgramPart> programParts;

	@Column(name = "PCMR01_PRODN_F")
	private String prodnF;

	@Column(name = "PCMR01_ARCH_F")
	private String archF;

	@Column(name = "PCMR01_SALEABLE_F")
	private String saleableF;

	@Column(name = "PCMR01_INDSTR_COST_A", precision = 19, scale = 4)
	private BigDecimal indstrCostA;

	@Column(name = "PCMR01_VEH_LVL_COORD_F")
	private String vehLvlCoordF;

	@Column(name = "PCMR01_CATCHWORD_C")
	private String catchWordC;

	@Column(name = "PCMR01_PART_NUM_X")
	private String partNumX;

	@Column(name = "PCMR01_ENGINEER_CDSID_C")
	private String engineerCdsidC;
	@Column(name = "PCMR01_STRAT_REL_C")
	private String stratRelC;

	@Column(name = "PCMR01_CALIB_R")
	private String calibR;

	@Column(name = "PCMR01_CONCERN_C")
	private String concernC;

	@Column(name = "PCMR01_CONCERN_Y")
	private LocalDate concernY;

	@Column(name = "PCMR01_CAL_REL_PLAN_Y")
	private LocalDate calRelPlanY;

	@Column(name = "PCMR01_CAL_REL_ACT_Y")
	private LocalDate calRelActY;

	@Column(name = "PCMR01_CMT_X")
	private String cmtX;

	@Column(name = "PCMR01_STAT_C")
	private String statC;

	@Column(name = "PCMR01_RELD_F")
	private String reldF;

	@Column(name = "PCMR01_RELD_Y")
	private LocalDate reldY;

	@Column(name = "PCMR01_CHIP_D")
	private String chipD;

	@Column(name = "PCMR01_HARDWARE_PART_R")
	private String hardwarePartR;

	@Column(name = "PCMR01_STRAT_CALIB_PART_R")
	private String stratCalibPartR;

	@Column(name = "PCMR01_STRAT_PART_R")
	private String stratPartR;

	@Column(name = "PCMR01_CALIB_PART_R")
	private String calibPartR;

	@Column(name = "PCMR01_WERS_NTC_R")
	private String wersNtcR;

	@Column(name = "PCMR01_HCR_R")
	private String hcrR;
	@Column(name = "PCMR01_SVC_MODULE_PART_R")
	private String svcModulePartR;

	@Column(name = "PCMR01_SVC_MODULE_F")
	private String svcModuleF;

	@Column(name = "PCMR01_PWRTRN_CALIB_CDSID_C")
	private String pwrtrnCalibCdsidC;

	@Column(name = "PCMR01_SW_REL_ANLST_CDSID_C")
	private String swRelAnlstCdsidC;

	@Column(name = "PCMR01_SW_DV_MODULE_REQR_F")
	private String swDvModuleReqrF;

	@Column(name = "PCMR01_CVN_C")
	private String cvnC;

	@Column(name = "PCMR01_BACKWARD_COMPAT_GRP_C")
	private String backwardCompatGrpC;

	@Column(name = "PCMR01_PROC_CMT_X")
	private String procCmtX;

	@Column(name = "PCMR01_SYMPTOM_CMT_X")
	private String symptomCmtX;

	@Column(name = "PCMR01_PROJ_CTL_ENG_CDSID_C")
	private String projCtlEngCdsidC;

	@Column(name = "PCMR01_CHECKSUM_C")
	private String checksumC;

	@Column(name = "PCMR01_BLD_LVL_C")
	private String bldLvlC;

	@Column(name = "PCMR01_PRTY_C")
	private String prtyC;

	@Column(name = "PCMR01_PRTY_DTL_X")
	private String prtyDtlX;

	@Column(name = "PCMR01_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMR01_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMR01_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMR01_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;

	@Column(name = "PCMR01_OTA_F")
	private String otaF;

	@Column(name = "PCMR01_HMLGN_F")
	private String hmlgnF;

	@Column(name = "PCMR01_ALERT_BNCH_FLASH_F")
	private String alertBnchFlashF;

	@Column(name = "PCMR01_ALERT_REQR_ONSITE_MOD_F")
	private String alertReqrOnsiteModF;

	@Column(name = "PCMR01_ALERT_REQR_USE_PPM_F")
	private String alertReqrUsePpmF;

	@Column(name = "PCMR01_PLN_EFF_Y")
	private Date plnEffY;

	@Column(name = "PCMR01_DOMAIN_N")
	private String domainN;

	@Column(name = "PCMR01_DOMAIN_INSTNC_N")
	private String domainInstncN;

	@Column(name = "PCMR01_VEH_CAN_TYP_C")
	private String vehCanTypC;
	@Column(name = "PCMR01_CFX_REL_TGT_Y")
	private Date cfxRelTgtY;

	@Column(name = "PCMR01_CORE_HARDWARE_PART_R")
	private String coreHardwarePartR;

	@Column(name = "PCMR01_CORE_HARDWARE_CDSID_C")
	private String coreHardwareCdsidC;

	@Column(name = "PCMR01_SW_DL_SPEC_R")
	private String swDlSpecR;

	@Column(name = "PCMR01_GEN_GLBL_SPEC_R")
	private String genGlblSpecR;

	@Column(name = "PCMR01_DOMAIN_INSTNC_VER_R")
	private String domainInstncVerR;

	@Column(name = "PCMR01_APP_INSTNC_N")
	private String appInstncN;

	@Column(name = "PCMR01_APP_INSTNC_VER_R")
	private String appInstncVerR;

	@Column(name = "PCMR01_REUSE_SW_F")
	private String reuseSwF;

	@Column(name = "PCMR01_STRAT_BUILD_COMP_F")
	private String stratBuildCompF;

	public String getPartR() {
		return partR;
	}

	public void setPartR(String partR) {
		this.partR = partR;
	}

	public String getIpfPartR() {
		return ipfPartR;
	}

	public void setIpfPartR(String ipfPartR) {
		this.ipfPartR = ipfPartR;
	}

	public String getReplacedPartR() {
		return replacedPartR;
	}

	public void setReplacedPartR(String replacedPartR) {
		this.replacedPartR = replacedPartR;
	}

	public String getParntPartR() {
		return parntPartR;
	}

	public void setParntPartR(String parntPartR) {
		this.parntPartR = parntPartR;
	}

	public Catchword getCatchword() {
		return catchword;
	}

	public void setCatchword(Catchword catchword) {
		this.catchword = catchword;
	}

	public Catchword getCatchwordType() {
		return catchwordType;
	}

	public void setCatchwordType(Catchword catchwordType) {
		this.catchwordType = catchwordType;
	}

	public ModuleType getModuleType() {
		return moduleType;
	}

	public void setModuleType(ModuleType moduleType) {
		this.moduleType = moduleType;
	}

	public ReleaseType getReleaseType() {
		return releaseType;
	}

	public void setReleaseType(ReleaseType releaseType) {
		this.releaseType = releaseType;
	}

	public Supplier getSupplier() {
		return supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public MicroType getMicroType() {
		return microType;
	}

	public void setMicroType(MicroType microType) {
		this.microType = microType;
	}

	public RelUsg getReleaseUsage() {
		return releaseUsage;
	}

	public void setReleaseUsage(RelUsg releaseUsage) {
		this.releaseUsage = releaseUsage;
	}

	public BackwardCompat getBackwardCompat() {
		return backwardCompat;
	}

	public void setBackwardCompat(BackwardCompat backwardCompat) {
		this.backwardCompat = backwardCompat;
	}

	public LabelUsg getLabelUsage() {
		return labelUsage;
	}

	public void setLabelUsage(LabelUsg labelUsage) {
		this.labelUsage = labelUsage;
	}

	public RgnBuilt getRegionBuilt() {
		return regionBuilt;
	}

	public void setRegionBuilt(RgnBuilt regionBuilt) {
		this.regionBuilt = regionBuilt;
	}

	public List<PartSignoff> getPartSignoffs() {
		return partSignoffs;
	}

	public void setPartSignoffs(List<PartSignoff> partSignoffs) {
		this.partSignoffs = partSignoffs;
	}

	public List<ProgramPart> getProgramParts() {
		return programParts;
	}

	public void setProgramParts(List<ProgramPart> programParts) {
		this.programParts = programParts;
	}

	public String getProdnF() {
		return prodnF;
	}

	public void setProdnF(String prodnF) {
		this.prodnF = prodnF;
	}

	public String getArchF() {
		return archF;
	}

	public void setArchF(String archF) {
		this.archF = archF;
	}

	public String getSaleableF() {
		return saleableF;
	}

	public void setSaleableF(String saleableF) {
		this.saleableF = saleableF;
	}

	public BigDecimal getIndstrCostA() {
		return indstrCostA;
	}

	public void setIndstrCostA(BigDecimal indstrCostA) {
		this.indstrCostA = indstrCostA;
	}

	public String getVehLvlCoordF() {
		return vehLvlCoordF;
	}

	public void setVehLvlCoordF(String vehLvlCoordF) {
		this.vehLvlCoordF = vehLvlCoordF;
	}

	public String getCatchWordC() {
		return catchWordC;
	}

	public void setCatchWordC(String catchWordC) {
		this.catchWordC = catchWordC;
	}

	public String getPartNumX() {
		return partNumX;
	}

	public void setPartNumX(String partNumX) {
		this.partNumX = partNumX;
	}

	public String getEngineerCdsidC() {
		return engineerCdsidC;
	}

	public void setEngineerCdsidC(String engineerCdsidC) {
		this.engineerCdsidC = engineerCdsidC;
	}

	public String getStratRelC() {
		return stratRelC;
	}

	public void setStratRelC(String stratRelC) {
		this.stratRelC = stratRelC;
	}

	public String getCalibR() {
		return calibR;
	}

	public void setCalibR(String calibR) {
		this.calibR = calibR;
	}

	public String getConcernC() {
		return concernC;
	}

	public void setConcernC(String concernC) {
		this.concernC = concernC;
	}

	public LocalDate getConcernY() {
		return concernY;
	}

	public void setConcernY(LocalDate concernY) {
		this.concernY = concernY;
	}

	public LocalDate getCalRelPlanY() {
		return calRelPlanY;
	}

	public void setCalRelPlanY(LocalDate calRelPlanY) {
		this.calRelPlanY = calRelPlanY;
	}

	public LocalDate getCalRelActY() {
		return calRelActY;
	}

	public void setCalRelActY(LocalDate calRelActY) {
		this.calRelActY = calRelActY;
	}

	public String getCmtX() {
		return cmtX;
	}

	public void setCmtX(String cmtX) {
		this.cmtX = cmtX;
	}

	public String getStatC() {
		return statC;
	}

	public void setStatC(String statC) {
		this.statC = statC;
	}

	public String getReldF() {
		return reldF;
	}

	public void setReldF(String reldF) {
		this.reldF = reldF;
	}

	public LocalDate getReldY() {
		return reldY;
	}

	public void setReldY(LocalDate reldY) {
		this.reldY = reldY;
	}

	public String getChipD() {
		return chipD;
	}

	public void setChipD(String chipD) {
		this.chipD = chipD;
	}

	public String getHardwarePartR() {
		return hardwarePartR;
	}

	public void setHardwarePartR(String hardwarePartR) {
		this.hardwarePartR = hardwarePartR;
	}

	public String getStratCalibPartR() {
		return stratCalibPartR;
	}

	public void setStratCalibPartR(String stratCalibPartR) {
		this.stratCalibPartR = stratCalibPartR;
	}

	public String getStratPartR() {
		return stratPartR;
	}

	public void setStratPartR(String stratPartR) {
		this.stratPartR = stratPartR;
	}

	public String getCalibPartR() {
		return calibPartR;
	}

	public void setCalibPartR(String calibPartR) {
		this.calibPartR = calibPartR;
	}

	public String getWersNtcR() {
		return wersNtcR;
	}

	public void setWersNtcR(String wersNtcR) {
		this.wersNtcR = wersNtcR;
	}

	public String getHcrR() {
		return hcrR;
	}

	public void setHcrR(String hcrR) {
		this.hcrR = hcrR;
	}

	public String getSvcModulePartR() {
		return svcModulePartR;
	}

	public void setSvcModulePartR(String svcModulePartR) {
		this.svcModulePartR = svcModulePartR;
	}

	public String getSvcModuleF() {
		return svcModuleF;
	}

	public void setSvcModuleF(String svcModuleF) {
		this.svcModuleF = svcModuleF;
	}

	public String getPwrtrnCalibCdsidC() {
		return pwrtrnCalibCdsidC;
	}

	public void setPwrtrnCalibCdsidC(String pwrtrnCalibCdsidC) {
		this.pwrtrnCalibCdsidC = pwrtrnCalibCdsidC;
	}

	public String getSwRelAnlstCdsidC() {
		return swRelAnlstCdsidC;
	}

	public void setSwRelAnlstCdsidC(String swRelAnlstCdsidC) {
		this.swRelAnlstCdsidC = swRelAnlstCdsidC;
	}

	public String getSwDvModuleReqrF() {
		return swDvModuleReqrF;
	}

	public void setSwDvModuleReqrF(String swDvModuleReqrF) {
		this.swDvModuleReqrF = swDvModuleReqrF;
	}

	public String getCvnC() {
		return cvnC;
	}

	public void setCvnC(String cvnC) {
		this.cvnC = cvnC;
	}

	public String getBackwardCompatGrpC() {
		return backwardCompatGrpC;
	}

	public void setBackwardCompatGrpC(String backwardCompatGrpC) {
		this.backwardCompatGrpC = backwardCompatGrpC;
	}

	public String getProcCmtX() {
		return procCmtX;
	}

	public void setProcCmtX(String procCmtX) {
		this.procCmtX = procCmtX;
	}

	public String getSymptomCmtX() {
		return symptomCmtX;
	}

	public void setSymptomCmtX(String symptomCmtX) {
		this.symptomCmtX = symptomCmtX;
	}

	public String getProjCtlEngCdsidC() {
		return projCtlEngCdsidC;
	}

	public void setProjCtlEngCdsidC(String projCtlEngCdsidC) {
		this.projCtlEngCdsidC = projCtlEngCdsidC;
	}

	public String getChecksumC() {
		return checksumC;
	}

	public void setChecksumC(String checksumC) {
		this.checksumC = checksumC;
	}

	public String getBldLvlC() {
		return bldLvlC;
	}

	public void setBldLvlC(String bldLvlC) {
		this.bldLvlC = bldLvlC;
	}

	public String getPrtyC() {
		return prtyC;
	}

	public void setPrtyC(String prtyC) {
		this.prtyC = prtyC;
	}

	public String getPrtyDtlX() {
		return prtyDtlX;
	}

	public void setPrtyDtlX(String prtyDtlX) {
		this.prtyDtlX = prtyDtlX;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}

	public String getOtaF() {
		return otaF;
	}

	public void setOtaF(String otaF) {
		this.otaF = otaF;
	}

	public String getHmlgnF() {
		return hmlgnF;
	}

	public void setHmlgnF(String hmlgnF) {
		this.hmlgnF = hmlgnF;
	}

	public String getAlertBnchFlashF() {
		return alertBnchFlashF;
	}

	public void setAlertBnchFlashF(String alertBnchFlashF) {
		this.alertBnchFlashF = alertBnchFlashF;
	}

	public String getAlertReqrOnsiteModF() {
		return alertReqrOnsiteModF;
	}

	public void setAlertReqrOnsiteModF(String alertReqrOnsiteModF) {
		this.alertReqrOnsiteModF = alertReqrOnsiteModF;
	}

	public String getAlertReqrUsePpmF() {
		return alertReqrUsePpmF;
	}

	public void setAlertReqrUsePpmF(String alertReqrUsePpmF) {
		this.alertReqrUsePpmF = alertReqrUsePpmF;
	}

	public Date getPlnEffY() {
		return plnEffY;
	}

	public void setPlnEffY(Date plnEffY) {
		this.plnEffY = plnEffY;
	}

	public String getDomainN() {
		return domainN;
	}

	public void setDomainN(String domainN) {
		this.domainN = domainN;
	}

	public String getDomainInstncN() {
		return domainInstncN;
	}

	public void setDomainInstncN(String domainInstncN) {
		this.domainInstncN = domainInstncN;
	}

	public String getVehCanTypC() {
		return vehCanTypC;
	}

	public void setVehCanTypC(String vehCanTypC) {
		this.vehCanTypC = vehCanTypC;
	}

	public Date getCfxRelTgtY() {
		return cfxRelTgtY;
	}

	public void setCfxRelTgtY(Date cfxRelTgtY) {
		this.cfxRelTgtY = cfxRelTgtY;
	}

	public String getCoreHardwarePartR() {
		return coreHardwarePartR;
	}

	public void setCoreHardwarePartR(String coreHardwarePartR) {
		this.coreHardwarePartR = coreHardwarePartR;
	}

	public String getCoreHardwareCdsidC() {
		return coreHardwareCdsidC;
	}

	public void setCoreHardwareCdsidC(String coreHardwareCdsidC) {
		this.coreHardwareCdsidC = coreHardwareCdsidC;
	}

	public String getSwDlSpecR() {
		return swDlSpecR;
	}

	public void setSwDlSpecR(String swDlSpecR) {
		this.swDlSpecR = swDlSpecR;
	}

	public String getGenGlblSpecR() {
		return genGlblSpecR;
	}

	public void setGenGlblSpecR(String genGlblSpecR) {
		this.genGlblSpecR = genGlblSpecR;
	}

	public String getDomainInstncVerR() {
		return domainInstncVerR;
	}

	public void setDomainInstncVerR(String domainInstncVerR) {
		this.domainInstncVerR = domainInstncVerR;
	}

	public String getAppInstncN() {
		return appInstncN;
	}

	public void setAppInstncN(String appInstncN) {
		this.appInstncN = appInstncN;
	}

	public String getAppInstncVerR() {
		return appInstncVerR;
	}

	public void setAppInstncVerR(String appInstncVerR) {
		this.appInstncVerR = appInstncVerR;
	}

	public String getReuseSwF() {
		return reuseSwF;
	}

	public void setReuseSwF(String reuseSwF) {
		this.reuseSwF = reuseSwF;
	}

	public String getStratBuildCompF() {
		return stratBuildCompF;
	}

	public void setStratBuildCompF(String stratBuildCompF) {
		this.stratBuildCompF = stratBuildCompF;
	}

	@PrePersist
	public void prePersist() {
		this.alertReqrOnsiteModF = "N";
		this.alertBnchFlashF = "N";
		this.reldF = "N";
		this.prodnF = "Y";
		this.archF = "N";
		this.alertReqrUsePpmF = "N";
		this.hmlgnF = "N";
		this.indstrCostA = BigDecimal.ZERO;
		this.otaF = "N";
		this.reuseSwF = "N";
		this.saleableF = "N";
		this.stratBuildCompF = "N";
		this.svcModuleF = "N";
		this.swDvModuleReqrF = "N";
		this.vehLvlCoordF = "N";
	}
}