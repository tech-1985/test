package com.ford.gpcse.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMR39_LABEL_USG")
public class LabelUsg {
	@Id
	@Column(name = "PCMR39_LABEL_USG_K", nullable = false)
	private String labelUsgK;

	@Column(name = "PCMR39_LABEL_USG_X", nullable = false)
	private String labelUsgX;

	@Column(name = "PCMR39_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMR39_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMR39_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMR39_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;

	public String getLabelUsgK() {
		return labelUsgK;
	}

	public void setLabelUsgK(String labelUsgK) {
		this.labelUsgK = labelUsgK;
	}

	public String getLabelUsgX() {
		return labelUsgX;
	}

	public void setLabelUsgX(String labelUsgX) {
		this.labelUsgX = labelUsgX;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}
}
