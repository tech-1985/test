package com.ford.gpcse.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMR13_FIRMWARE_ROLE")
public class FirmwareRole {

	@EmbeddedId
	private FirmwareRoleId firmwareRoleId;

	@ManyToOne
	@JoinColumn(name = "PCMR03_FIRMWARE_K", referencedColumnName = "PCMR03_FIRMWARE_K", insertable = false, updatable = false)
	private Firmware firmware;

	@ManyToOne
	@JoinColumn(name = "PCM002_ROLE_K", referencedColumnName = "PCM002_ROLE_K", insertable = false, updatable = false)
	private Role role;

	@Column(name = "PCMR13_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMR13_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMR13_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMR13_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;

	public FirmwareRoleId getFirmwareRoleId() {
		return firmwareRoleId;
	}

	public void setFirmwareRoleId(FirmwareRoleId firmwareRoleId) {
		this.firmwareRoleId = firmwareRoleId;
	}

	public Firmware getFirmware() {
		return firmware;
	}

	public void setFirmware(Firmware firmware) {
		this.firmware = firmware;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}
}
