package com.ford.gpcse.entity;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class PartSignoffId {

	@Column(name = "PCMR20_SIGNOFF_TYP_C", length = 5)
	private String signoffTypC;

	@Column(name = "PCMR01_PART_R", length = 24)
	private String partR;

	public PartSignoffId() {
	}

	public PartSignoffId(String signoffTypC, String partR) {
		this.signoffTypC = signoffTypC;
		this.partR = partR;
	}

	public String getSignoffTypC() {
		return signoffTypC;
	}

	public void setSignoffTypC(String signoffTypC) {
		this.signoffTypC = signoffTypC;
	}

	public String getPartR() {
		return partR;
	}

	public void setPartR(String partR) {
		this.partR = partR;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		PartSignoffId that = (PartSignoffId) o;
		return Objects.equals(signoffTypC, that.signoffTypC) && Objects.equals(partR, that.partR);
	}

	@Override
	public int hashCode() {
		return Objects.hash(signoffTypC, partR);
	}
}
