package com.ford.gpcse.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMR46_SIGNOFF_MICRO_TYP")
public class SignoffMicroType {

	@EmbeddedId
	private SignoffMicroTypeId id;

	@ManyToOne
	@JoinColumn(name = "PCMR20_SIGNOFF_TYP_C", referencedColumnName = "PCMR20_SIGNOFF_TYP_C", insertable = false, updatable = false)
	private Signoff signoff;

	@ManyToOne
	@JoinColumn(name = "PCMR19_MICRO_TYP_C", referencedColumnName = "PCMR19_MICRO_TYP_C", insertable = false, updatable = false)
	private MicroType microType;

	@Column(name = "PCMR46_SIGNOFF_S")
	private LocalDateTime signoffS;

	@Column(name = "PCMR46_USER_CDSID_C", length = 8)
	private String userCdsidC;

	@Column(name = "PCMR46_REQT_Y")
	private LocalDateTime reqtY;

	@Column(name = "PCMR46_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMR46_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMR46_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMR46_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;

	public SignoffMicroTypeId getId() {
		return id;
	}

	public void setId(SignoffMicroTypeId id) {
		this.id = id;
	}

	public Signoff getSignoff() {
		return signoff;
	}

	public void setSignoff(Signoff signoff) {
		this.signoff = signoff;
	}

	public MicroType getMicroType() {
		return microType;
	}

	public void setMicroType(MicroType microType) {
		this.microType = microType;
	}

	public LocalDateTime getSignoffS() {
		return signoffS;
	}

	public void setSignoffS(LocalDateTime signoffS) {
		this.signoffS = signoffS;
	}

	public String getUserCdsidC() {
		return userCdsidC;
	}

	public void setUserCdsidC(String userCdsidC) {
		this.userCdsidC = userCdsidC;
	}

	public LocalDateTime getReqtY() {
		return reqtY;
	}

	public void setReqtY(LocalDateTime reqtY) {
		this.reqtY = reqtY;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}
}
