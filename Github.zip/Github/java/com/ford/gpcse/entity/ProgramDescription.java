package com.ford.gpcse.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "WPCMS01_PGM_DESC")
public class ProgramDescription {

	@Id
	@Column(name = "PCMS01_PGM_K")
	private Long pgmK;

	@Column(name = "PCMS01_MDL_YR_R", nullable = false)
	private String mdlYrR;

	@Column(name = "PCMS01_PGM_N", nullable = false)
	private String pgmN;

	@Column(name = "PCMS01_ENG_N", nullable = false)
	private String engN;

	@Column(name = "PCMS01_TRANS_N", nullable = false)
	private String transN;

	@Column(name = "PCMS01_ARCH_F", nullable = false)
	private String archF;

	@Column(name = "PCMS01_PLAT_N", nullable = false)
	private String platN;

	@Column(name = "PCMS01_PGM_X", nullable = false)
	private String pgmX;

	@Column(name = "PCMS01_PCM_SRC_N", nullable = false)
	private String pcmSrcN;

	@Column(name = "PCMS01_OTH_ATTR_X", nullable = true)
	private String otherAttributes;

	@Column(name = "PCMS01_EMISSION_GRP_C", nullable = true)
	private String emissionGroupCode;

	@Column(name = "PCMS01_IVS_PGM_D", nullable = true)
	private String ivsProgramDate;

	@Column(name = "PCMS01_WERS_VEH_LN_C", nullable = true)
	private String wersVehicleLineCode;

	@Column(name = "PCMS01_WERS_EFF_PT_C", nullable = true)
	private String wersEffortPointCode;

	@Column(name = "PCMS01_CREATE_USER_C", nullable = false)
	private String createUserC;

	@Column(name = "PCMS01_CREATE_S", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createS;

	@Column(name = "PCMS01_LAST_UPDT_USER_C", nullable = false)
	private String lastUpdtUserC;

	@Column(name = "PCMS01_LAST_UPDT_S", nullable = false)
	@UpdateTimestamp
	private LocalDateTime lastUpdtS;

	@Column(name = "PCMS01_PGM_STAT_C", nullable = false)
	private String programStatus;

	@Column(name = "PCMS01_OTA_F", nullable = true)
	private String otaF;
	
	public Long getPgmK() {
		return pgmK;
	}

	public void setPgmK(Long pgmK) {
		this.pgmK = pgmK;
	}

	public String getMdlYrR() {
		return mdlYrR;
	}

	public void setMdlYrR(String mdlYrR) {
		this.mdlYrR = mdlYrR;
	}

	public String getPgmN() {
		return pgmN;
	}

	public void setPgmN(String pgmN) {
		this.pgmN = pgmN;
	}

	public String getEngN() {
		return engN;
	}

	public void setEngN(String engN) {
		this.engN = engN;
	}

	public String getTransN() {
		return transN;
	}

	public void setTransN(String transN) {
		this.transN = transN;
	}

	public String getArchF() {
		return archF;
	}

	public void setArchF(String archF) {
		this.archF = archF;
	}

	public String getPlatN() {
		return platN;
	}

	public void setPlatN(String platN) {
		this.platN = platN;
	}

	public String getPgmX() {
		return pgmX;
	}

	public void setPgmX(String pgmX) {
		this.pgmX = pgmX;
	}

	public String getPcmSrcN() {
		return pcmSrcN;
	}

	public void setPcmSrcN(String pcmSrcN) {
		this.pcmSrcN = pcmSrcN;
	}

	public String getOtherAttributes() {
		return otherAttributes;
	}

	public void setOtherAttributes(String otherAttributes) {
		this.otherAttributes = otherAttributes;
	}

	public String getEmissionGroupCode() {
		return emissionGroupCode;
	}

	public void setEmissionGroupCode(String emissionGroupCode) {
		this.emissionGroupCode = emissionGroupCode;
	}

	public String getIvsProgramDate() {
		return ivsProgramDate;
	}

	public void setIvsProgramDate(String ivsProgramDate) {
		this.ivsProgramDate = ivsProgramDate;
	}

	public String getWersVehicleLineCode() {
		return wersVehicleLineCode;
	}

	public void setWersVehicleLineCode(String wersVehicleLineCode) {
		this.wersVehicleLineCode = wersVehicleLineCode;
	}

	public String getWersEffortPointCode() {
		return wersEffortPointCode;
	}

	public void setWersEffortPointCode(String wersEffortPointCode) {
		this.wersEffortPointCode = wersEffortPointCode;
	}

	public String getCreateUserC() {
		return createUserC;
	}

	public void setCreateUserC(String createUserC) {
		this.createUserC = createUserC;
	}

	public LocalDateTime getCreateS() {
		return createS;
	}

	public void setCreateS(LocalDateTime createS) {
		this.createS = createS;
	}

	public String getLastUpdtUserC() {
		return lastUpdtUserC;
	}

	public void setLastUpdtUserC(String lastUpdtUserC) {
		this.lastUpdtUserC = lastUpdtUserC;
	}

	public LocalDateTime getLastUpdtS() {
		return lastUpdtS;
	}

	public void setLastUpdtS(LocalDateTime lastUpdtS) {
		this.lastUpdtS = lastUpdtS;
	}

	public String getProgramStatus() {
		return programStatus;
	}

	public void setProgramStatus(String programStatus) {
		this.programStatus = programStatus;
	}

	public String getOtaF() {
		return otaF;
	}

	public void setOtaF(String otaF) {
		this.otaF = otaF;
	}
}
