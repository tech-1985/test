package com.ford.gpcse.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

/**
 * Aspect that tracks the execution time of methods annotated
 * with @TrackExecutionTime. It uses Spring AOP to intercept method calls and
 * measure their execution duration.
 */
@Aspect
@Component
public class ExecutionTimeTrackerAdvice {

	private static final Logger log = LoggerFactory.getLogger(ExecutionTimeTrackerAdvice.class);

	/**
	 * Advice that wraps around method execution to measure and log execution time.
	 *
	 * @param pjp the join point representing the method execution
	 * @return the result of the method execution
	 * @throws Throwable if the method execution throws an exception
	 */
	@Around("@annotation(com.ford.gpcse.aop.TrackExecutionTime)")
	public Object trackTime(ProceedingJoinPoint pjp) throws Throwable {
		var methodSignature = (MethodSignature) pjp.getSignature();

		// Get intercepted method details
		var className = methodSignature.getDeclaringType().getSimpleName();
		var methodName = methodSignature.getName();
		final var stopWatch = new StopWatch();

		// Measure method execution time
		stopWatch.start();
		Object result = pjp.proceed(); // Proceed with method execution
		stopWatch.stop();

		// Log method execution time
		log.info("Execution time of {}.{} :: {} ms", className, methodName, stopWatch.getTotalTimeMillis());

		return result; // Return the result of the method
	}

}
