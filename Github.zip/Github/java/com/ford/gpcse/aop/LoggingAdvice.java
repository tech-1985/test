package com.ford.gpcse.aop;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ford.gpcse.common.Constants;

/**
 * Aspect that handles logging for method executions and exceptions. It
 * intercepts methods annotated with @LoggingAspect to log request and response
 * data, and logs exceptions thrown in the GlobalExceptionHandler.
 */
@Aspect
@Component
public class LoggingAdvice {

	private static final Logger log = LoggerFactory.getLogger(LoggingAdvice.class);

	/**
	 * Advice that wraps around method execution to log request and response data.
	 *
	 * @param pjp the join point representing the method execution
	 * @return the result of the method execution
	 * @throws Throwable if the method execution throws an exception
	 */
	@Around("@annotation(com.ford.gpcse.aop.LoggingAspect)")
	public Object logging(ProceedingJoinPoint pjp) throws Throwable {
		var methodSignature = (MethodSignature) pjp.getSignature();
		var className = methodSignature.getDeclaringType().getSimpleName();
		var methodName = methodSignature.getName();
		var requestData = constructData(pjp);
		log.info("{} for {}.{}: Request Data={}", Constants.INITIAL_REQUEST, className, methodName, requestData);
		var proceed = pjp.proceed();
		log.info("{} for {}.{}: Response Data={}", Constants.FINAL_RESPONSE, className, methodName, proceed);
		return proceed;
	}

	/**
	 * Advice that logs exceptions thrown by methods in the GlobalExceptionHandler.
	 *
	 * @param joinPoint the join point representing the method execution
	 * @param ex        the exception thrown
	 */
	@AfterThrowing(pointcut = "execution(* com.ford.gpcse.exception.GlobalExceptionHandler.*(..))", throwing = "ex")
	public void logException(JoinPoint joinPoint, Exception ex) {
		var className = joinPoint.getSignature().getDeclaringTypeName();
		var methodName = joinPoint.getSignature().getName();
		var exceptionMessage = ex.getMessage();
		var exceptionDetails = Arrays.stream(joinPoint.getArgs()).map(String::valueOf)
				.collect(Collectors.joining(",", "[", "]"));
		log.error("Exception in {}.{}: Exception Message={}, Details={}", className, methodName, exceptionMessage,
				exceptionDetails);
	}

	/**
	 * Constructs a string representation of the method arguments.
	 *
	 * @param jp the join point representing the method execution
	 * @return a string representation of the arguments
	 */
	private String constructData(JoinPoint jp) {
		return Arrays.stream(jp.getArgs()).map(String::valueOf).collect(Collectors.joining(",", "[", "]"));
	}
}
