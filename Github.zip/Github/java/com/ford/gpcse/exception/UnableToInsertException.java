package com.ford.gpcse.exception;

public class UnableToInsertException extends RuntimeException {

	private static final long serialVersionUID = 9194098611016945359L;

	public UnableToInsertException(String message) {
		super(message);
	}

	public UnableToInsertException(String message, Throwable cause) {
		super(message, cause);
	}
}