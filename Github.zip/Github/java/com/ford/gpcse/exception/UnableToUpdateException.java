package com.ford.gpcse.exception;

public class UnableToUpdateException extends RuntimeException {

	private static final long serialVersionUID = 2556755886741170772L;

	public UnableToUpdateException(String message) {
		super(message);
	}

	public UnableToUpdateException(String message, Throwable cause) {
		super(message, cause);
	}
}