package com.ford.gpcse.exception;

public class VsemServiceException extends RuntimeException {

	private static final long serialVersionUID = -2846127044703104160L;

	public VsemServiceException(String message) {
		super(message);
	}

	public VsemServiceException(String message, Throwable cause) {
		super(message, cause);
	}

}
