package com.ford.gpcse.exception;

public class ResourceAlreadyExistException extends RuntimeException {

	private static final long serialVersionUID = 3940696391128579964L;

	public ResourceAlreadyExistException(String message) {
		super(message);
	}

	public ResourceAlreadyExistException(String message, Throwable cause) {
		super(message, cause);
	}
}